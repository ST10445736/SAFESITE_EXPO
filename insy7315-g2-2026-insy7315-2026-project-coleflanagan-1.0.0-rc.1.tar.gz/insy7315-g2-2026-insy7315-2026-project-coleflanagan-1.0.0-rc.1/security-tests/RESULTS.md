# Isolated security verification

52 rule checks passed; six migration checks passed. Executed 29 October 2026 using the bundled test entry point against demo-safesite-review in the Firestore Emulator. No live Firebase data was accessed. Kotlin compilation, Android device tests and production attestation were not run here.

- PASS: Unauthenticated profile read denied
- PASS: Inactive user can read own profile
- PASS: Inactive user cannot read site
- PASS: Worker can read own profile
- PASS: Worker cannot list users
- PASS: Worker cannot promote own account
- PASS: Administrator cannot change own role
- PASS: Administrator can create user profile
- PASS: Worker can individually read assigned site
- PASS: Worker cannot query all sites
- PASS: Worker can query own assignments
- PASS: Worker cannot list all assignments
- PASS: Supervisor can review PPE
- PASS: Worker cannot review PPE
- PASS: Incident reporting plus initial event succeeds atomically
- PASS: Forged standalone initial event denied
- PASS: Safety manager transition with event succeeds
- PASS: Safety manager cannot rewrite incident reporter
- PASS: Corrective action and parent status update succeeds
- PASS: Corrective action completion succeeds
- PASS: Worker must not submit to unassigned site
- PASS: Hazard must not close with pending corrective actions
- PASS: Two simultaneous open attendance documents must not be allowed
- PASS: Atomic check-in for an unassigned site denied
- PASS: Atomic check-in with someone else assignment denied
- PASS: Future assignment denied
- PASS: Valid atomic assigned-site check-in succeeds
- PASS: Second check-in while lock held denied
- PASS: Lock cannot be cleared without checkout
- PASS: Checkout cannot leave lock held
- PASS: Atomic checkout and lock release succeeds
- PASS: New check-in after checkout succeeds
- PASS: Cannot remove pending action directly
- PASS: Cannot mark action done without updating parent
- PASS: Tracked completion plus removal succeeds
- PASS: Hazard can close when tracked pending list empty
- PASS: Cannot add corrective action after hazard closed
- PASS: Client cannot enable attendance migration flag
- PASS: Two attendance documents cannot share an acquired lock
- PASS: Concurrent check-in transactions allow only one winner
- PASS: Assigned worker PPE creation succeeds
- PASS: Worker PPE creation for unassigned site denied
- PASS: Assigned worker checklist succeeds
- PASS: Worker checklist at unassigned site denied
- PASS: Assigned worker hazard creation succeeds
- PASS: Worker hazard for unassigned site denied
- PASS: Worker incident for unassigned site denied
- PASS: Supervisor task for assigned worker succeeds
- PASS: Supervisor task for worker at unassigned site denied
- PASS: Forged pending-action ID cannot unblock hazard closure
- PASS: Ended assignment cannot authorise check-in
- PASS: Concurrent hazard closure and action creation cannot leave closed hazard with pending action

Migration checks: dry-run makes no writes; migration preserves history and initialises tracking; completed migration is idempotent; duplicate attendance aborts; closed hazard with pending action aborts; inconsistent existing tracking aborts.
