const {initializeApp,applicationDefault} = require('firebase-admin/app');
const {getFirestore} = require('firebase-admin/firestore');

async function migrate(db,{apply=false}={}) {
  const marker=db.doc('security_migrations/attendance_v1');
  const markerSnapshot=await marker.get();
  if(markerSnapshot.get('ready')===true) {
    console.log('Migration already completed. No changes made.');
    return {alreadyComplete:true};
  }

  const [attendance,hazards,actions,locks]=await Promise.all([
    db.collection('attendance').get(),db.collection('hazards').get(),
    db.collection('correctiveActions').get(),db.collection('attendance_locks').get()
  ]);
  const issues=[];
  const openByWorker=new Map();
  for(const d of attendance.docs) {
    const a=d.data();
    if(a.status==='checked_in') {
      if(typeof a.workerId!=='string'||!a.workerId||a.workerId.includes('/')||typeof a.siteId!=='string'||!a.siteId||!Number.isSafeInteger(a.checkIn)||a.checkIn<=0||a.checkOut!=null) {
        issues.push('Invalid open attendance: '+d.id);continue;
      }
      if(openByWorker.has(a.workerId))issues.push('Duplicate open attendance: '+openByWorker.get(a.workerId).id+' and '+d.id);
      else openByWorker.set(a.workerId,{id:d.id,siteId:a.siteId});
    } else if(a.status!=='checked_out')issues.push('Unknown attendance status: '+d.id);
  }

  const hazardsById=new Map(hazards.docs.map(d=>[d.id,d]));
  const pending=new Map();
  for(const d of actions.docs) {
    const a=d.data();
    if(!hazardsById.has(a.hazardId))issues.push('Corrective action has no parent hazard: '+d.id);
    if(a.status==='pending') {
      if(!pending.has(a.hazardId))pending.set(a.hazardId,[]);
      pending.get(a.hazardId).push(d.id);
    } else if(a.status!=='done')issues.push('Unknown corrective-action status: '+d.id);
  }
  for(const h of hazards.docs) {
    const expected=(pending.get(h.id)||[]).sort();
    if(!['open','in_progress','closed'].includes(h.get('status')))issues.push('Unknown hazard status: '+h.id);
    if(h.get('status')==='closed'&&expected.length)issues.push('Closed hazard has pending actions: '+h.id);
    if(expected.length>2000)issues.push('Hazard exceeds pending-action limit: '+h.id);
    if(h.get('pendingActionIds')!==undefined) {
      const actual=h.get('pendingActionIds');
      if(!Array.isArray(actual)||JSON.stringify([...actual].sort())!==JSON.stringify(expected))issues.push('Existing hazard tracking disagrees with action records: '+h.id);
    }
  }
  if(issues.length) {
    console.error(issues.join('\n'));
    throw Error('Migration stopped. Reconcile these records explicitly; no migration writes were made.');
  }

  const summary={openAttendance:openByWorker.size,legacyHazards:hazards.docs.filter(d=>d.get('pendingActionIds')===undefined).length,apply};
  console.log(JSON.stringify(summary));
  if(!apply) {
    console.log('Dry run only. Publish the matching rules, pause other writers, then rerun with --apply.');
    return summary;
  }

  // Matching rules must already be published. The absent/false marker
  // prevents attendance writes; legacy hazards cannot change actions
  // until their pendingActionIds field is initialised.
  const lockIds=new Set([...openByWorker.keys(),...locks.docs.map(d=>d.id)]);
  const ids=[...lockIds];
  for(let offset=0;offset<ids.length;offset+=400) {
    const batch=db.batch();
    for(const uid of ids.slice(offset,offset+400)) {
      const open=openByWorker.get(uid);
      batch.set(db.doc('attendance_locks/'+uid),{
        workerId:uid,attendanceId:open?.id||'',siteId:open?.siteId||''
      });
    }
    await batch.commit();
  }
  for(const h of hazards.docs) {
    if(h.get('pendingActionIds')!==undefined)continue;
    await db.runTransaction(async tx=>{
      const current=await tx.get(h.ref);
      if(!current.exists)throw Error('Hazard disappeared during migration: '+h.id);
      if(current.get('pendingActionIds')!==undefined)return;
      tx.update(h.ref,{pendingActionIds:(pending.get(h.id)||[]).sort()});
    });
  }
  await marker.set({ready:true,version:1,completedAt:Date.now()});
  console.log('Migration completed. Existing attendance and action history was preserved.');
  return summary;
}

module.exports={migrate};
if(require.main===module) {
  const args=process.argv.slice(2),at=args.indexOf('--project');
  const projectId=at<0?null:args[at+1];
  if(!projectId||projectId.startsWith('--')) {
    console.error('Usage: node migrate-security.cjs --project PROJECT_ID [--apply]');
    process.exitCode=1;
  } else {
    const options={projectId};
    if(!process.env.FIRESTORE_EMULATOR_HOST)options.credential=applicationDefault();
    initializeApp(options);
    migrate(getFirestore(),{apply:args.includes('--apply')})
      .catch(e=>{console.error(e.message);process.exitCode=1;});
  }
}
