# SafeSite

SafeSite is a construction safety management platform developed for the **INSY7315 Work-Integrated Learning (WIL)** project by **Aventra** for **Singo**. It combines an Android application for on-site teams with a web portal for safety officers and administrators.

## Important links

- **Hosted web application:** [https://safesite-dev-26e69.web.app](https://safesite-dev-26e69.web.app)
- **Android demonstration:** [Watch the SafeSite Android application demonstration](youtube_video_link/) (Open the `.rtf` document inside this folder for the direct link)
- **Web demonstration:** https://youtu.be/0-Y_5Drnkhw
- **GitHub repository:** [SafeSite project repository](https://github.com/EMGPSD/insy7315-g2-2026-insy7315-2026-project-coleflanagan)

## Project team

| Group member | Student number |
| --- | --- |
| Thulani Zondo | ST10208003 |
| Ntando Moyake | ST10435247 |
| Unathi Mkhwanazi | ST10454166 |
| Cole Flanagan | ST10454748 |
| Lindokuhle Lutendo Phiri | ST10134187 |
| Alwande Simango | ST10445736 |

## Project overview

The Android application and web portal use the same Firebase Authentication and Cloud Firestore project. Information recorded on site is therefore available in the management portal, while records created through the website remain available in the Android application.

## Main capabilities

| Role | Main functionality |
| --- | --- |
| Worker | Site check-in and check-out, daily safety checklist, PPE submissions, assigned tasks and progress updates |
| Supervisor | Live site headcount, PPE approval, task creation and monitoring, safety checklist review |
| Safety Officer | Hazard reporting, corrective actions, incident lifecycle management, training records and safety KPIs |
| Administrator | People and role management, projects, sites, site assignments, audit history and exports |

## Applications

### Android application

The Android application is designed for day-to-day site operations. It is built with Kotlin and Jetpack Compose and provides role-specific navigation for Workers, Supervisors, Safety Officers and Administrators.

Key technologies:

- Kotlin
- Jetpack Compose
- Material 3
- Firebase Authentication
- Cloud Firestore
- Firebase Storage
- Android Navigation Compose

### Web portal

The web portal provides a management interface for Safety Officers and Administrators. It reads from and writes to the same Firebase collections as the Android application.

Key technologies:

- React
- TypeScript
- Vite
- Tailwind CSS
- Recharts
- Firebase Authentication
- Cloud Firestore
- Firebase Hosting

## Shared Firebase architecture

```text
Android application ──┐
                      ├── Firebase Authentication
Web portal ───────────┤
                      ├── Cloud Firestore
                      └── Firebase Storage

Web portal ────────────── Firebase Hosting
```

The applications share the following Firestore collections:

- `users`
- `projects`
- `sites`
- `site_assignments`
- `attendance`
- `tasks`
- `ppe_submissions`
- `checklist_submissions`
- `hazards`
- `correctiveActions`
- `incidents`
- `incidentEvents`
- `trainingRecords`
- `auditLogs`

## Repository structure

```text
.
├── app/                     # Android application
├── gradle/                  # Android Gradle configuration
├── web/                     # React and Vite web application
│   ├── src/
│   │   ├── components/
│   │   ├── lib/             # Firebase, authentication and data access
│   │   └── pages/
│   ├── firebase.json        # Firebase Hosting configuration
│   ├── .firebaserc          # Firebase project mapping
│   └── package.json
├── youtube_video_link/      # Android emulator demo video link asset
│   └── *.rtf                # RTF document containing the YouTube URL
├── build.gradle.kts
├── settings.gradle.kts
└── README.md
```

## Getting started

### Requirements

- Android Studio with a compatible Android SDK
- JDK 17 or the JDK bundled with Android Studio
- Node.js and npm
- A Firebase project with Authentication, Firestore and Storage configured
- Access to the `safesite-dev-26e69` Firebase project for the deployed team environment

## Running the Android application

1. Clone the repository:

   ```bash
   git clone https://github.com/EMGPSD/insy7315-g2-2026-insy7315-2026-project-coleflanagan.git
   ```

2. Open the repository in Android Studio.
3. Confirm that `app/google-services.json` is available for the intended Firebase environment.
4. Allow Gradle to finish synchronising.
5. Select an emulator or connected Android device.
6. Run the `app` configuration.

To compile the Android Kotlin source from Windows PowerShell:

```powershell
.\gradlew.bat :app:compileDebugKotlin
```

## Running the web application

From the repository root:

```powershell
cd web
npm install
```

Create a local environment file from the provided example:

```powershell
Copy-Item .env.example .env.local
```

Fill in the Firebase web configuration values inside `web/.env.local`:

```env
VITE_FIREBASE_API_KEY=
VITE_FIREBASE_AUTH_DOMAIN=
VITE_FIREBASE_PROJECT_ID=
VITE_FIREBASE_STORAGE_BUCKET=
VITE_FIREBASE_MESSAGING_SENDER_ID=
VITE_FIREBASE_APP_ID=
```

Start the local development server:

```powershell
npm run dev
```

Build the production website:

```powershell
npm run build
```

The production files are generated in `web/dist/`. This directory and `.env.local` are intentionally excluded from Git.

## Deploying the web portal

The web portal is hosted with Firebase Hosting. From the `web` directory:

```powershell
npm run build
npx firebase-tools login
npx firebase-tools deploy --only "hosting"
```

Firebase deploys the current production build to:

[https://safesite-dev-26e69.web.app](https://safesite-dev-26e69.web.app)

## Authentication and authorisation

- Users authenticate with Firebase email and password authentication.
- Application roles are stored in each user’s Firestore `users/{uid}` document.
- Supported roles are `WORKER`, `SUPERVISOR`, `SAFETY_OFFICER` and `ADMIN`.
- The web portal accepts Safety Officer and Administrator accounts.
- Deactivated users are prevented from accessing the portal.
- Firestore Security Rules enforce role permissions at database level.

Do not commit passwords, service-account keys, `.env.local` files or private Firebase credentials.

## Core safety workflows

### Attendance

Workers can check in to and out of an assigned site. Supervisors can view the current live headcount.

### PPE and daily checklists

Workers submit PPE evidence and complete daily safety checks. Supervisors review the corresponding site submissions.

### Tasks

Supervisors create and assign site tasks. Workers can update task progress and attach evidence photographs.

### Hazards and corrective actions

Safety Officers record hazards and assign corrective actions. A hazard cannot be closed while required corrective actions remain incomplete.

### Incident management

Incidents follow a controlled lifecycle:

```text
Reported → Investigating → Actions pending → Closed
```

Status transitions are recorded in the incident timeline and audit history.

### Training records

Training is recorded against workers and sites. Expiry information is used to calculate valid, expiring and expired training records.

### Administration and auditing

Administrators manage users, roles, projects, sites and assignments. Important operations are recorded in the audit history and can be exported for reporting.

## Academic context

Developed by the Aventra project team for Singo as part of the **INSY7315 Work-Integrated Learning project**.
