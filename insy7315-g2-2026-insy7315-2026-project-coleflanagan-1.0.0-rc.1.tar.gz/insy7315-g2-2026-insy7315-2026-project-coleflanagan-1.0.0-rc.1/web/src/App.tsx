import { Navigate, Route, Routes } from "react-router-dom";
import Landing from "./pages/Landing";
import SignIn from "./pages/SignIn";
import Ppe from "./pages/Ppe";
import PortalLayout from "./components/PortalLayout";
import RequireAdmin from "./components/RequireAdmin";
import Dashboard from "./pages/Dashboard";
import Hazards from "./pages/Hazards";
import Incidents from "./pages/Incidents";
import IncidentDetail from "./pages/IncidentDetail";
import Training from "./pages/Training";
import People from "./pages/People";
import Projects from "./pages/Projects";
import Audit from "./pages/Audit";
import Exports from "./pages/Exports";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/portal/sign-in" element={<SignIn />} />
      <Route path="/portal" element={<PortalLayout />}>
        <Route index element={<Dashboard />} />
        <Route path="hazards" element={<Hazards />} />
        <Route path="incidents" element={<Incidents />} />
        <Route path="incidents/:id" element={<IncidentDetail />} />
        <Route path="training" element={<Training />} />
        <Route path="training" element={<Training />} />
        <Route path="ppe" element={<Ppe />} />
        <Route path="people" element={<RequireAdmin><People /></RequireAdmin>} />
        <Route path="projects" element={<RequireAdmin><Projects /></RequireAdmin>} />
        <Route path="audit" element={<RequireAdmin><Audit /></RequireAdmin>} />
        <Route path="exports" element={<Exports />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
