import { useCallback, useEffect, useState } from "react";
import { deleteApp, initializeApp } from "firebase/app";
import { createUserWithEmailAndPassword, getAuth, signOut } from "firebase/auth";
import { collection, doc, getDoc, getDocs, setDoc, updateDoc } from "firebase/firestore";
import { db, firebaseAuth, firebaseConfig } from "./firebase";
import type {
  AuditEntry, AuditList, Dashboard, Hazard, HazardAction, HazardList, Incident,
  IncidentStatus, PeopleList, Person, Project, ProjectList, Role, Severity,
  TrainingList, TrainingRecord, User,
} from "./types";

type Data = Record<string, any>;
type Row = Data & { id: string };
type Init = { method?: string; body?: unknown };
const DAY = 86_400_000;

export class ApiError extends Error {
  constructor(message: string, public status = 400) { super(message); }
}

const text = (value: unknown, fallback = "") => typeof value === "string" ? value : fallback;
const upper = (value: unknown) => text(value).toUpperCase();
const lower = (value: unknown) => text(value).toLowerCase();
const numberValue = (value: unknown): number => {
  if (typeof value === "number") return value;
  if (value && typeof value === "object" && "toMillis" in value) return (value as { toMillis: () => number }).toMillis();
  const parsed = new Date(String(value ?? "")).getTime();
  return Number.isFinite(parsed) ? parsed : 0;
};
const iso = (value: unknown) => new Date(numberValue(value) || 0).toISOString();
const nullableIso = (value: unknown) => numberValue(value) ? new Date(numberValue(value)).toISOString() : null;
const dateMillis = (value: unknown) => {
  if (typeof value === "number") return value;
  const parsed = new Date(`${String(value)}T12:00:00`).getTime();
  return Number.isFinite(parsed) ? parsed : 0;
};

async function rows(name: string): Promise<Row[]> {
  const snapshot = await getDocs(collection(db, name));
  return snapshot.docs.map((item: any) => ({ id: item.id, ...item.data() }));
}

async function row(name: string, id: string): Promise<Row | null> {
  const snapshot = await getDoc(doc(db, name, id));
  return snapshot.exists() ? { id: snapshot.id, ...snapshot.data() } : null;
}

function requireAccount() {
  const account = firebaseAuth.currentUser;
  if (!account) throw new ApiError("Please sign in again.", 401);
  return account;
}

async function currentUser(): Promise<User> {
  const account = requireAccount();
  const profile = await row("users", account.uid);
  if (!profile) throw new ApiError("Your SafeSite profile could not be found.", 403);
  return {
    id: account.uid,
    name: text(profile.fullName, account.email ?? "SafeSite User"),
    email: text(profile.email, account.email ?? ""),
    role: upper(profile.role) as Role,
  };
}

async function requireAdmin() {
  const user = await currentUser();
  if (user.role !== "ADMIN") throw new ApiError("Administrator access is required.", 403);
  return user;
}

async function audit(action: string, entityType: string, entityId: string, summary: string, siteId = "") {
  try {
    const user = await currentUser();
    const ref = doc(collection(db, "auditLogs"));
    await setDoc(ref, {
      id: ref.id, action, entityType, entityId, summary, siteId,
      byUserId: user.id, byName: user.name || user.email, at: Date.now(),
    });
  } catch { /* Logging must never break the real action. */ }
}

const hazardStatus = (value: unknown): Hazard["status"] => {
  if (lower(value) === "in_progress") return "IN_PROGRESS";
  if (lower(value) === "closed") return "CLOSED";
  return "OPEN";
};
const incidentStatus = (value: unknown): IncidentStatus => {
  if (lower(value) === "investigating") return "INVESTIGATING";
  if (lower(value) === "actions_pending") return "ACTIONS";
  if (lower(value) === "closed") return "CLOSED";
  return "REPORTED";
};
const severity = (value: unknown): Severity => {
  const result = upper(value);
  return result === "CRITICAL" || result === "HIGH" || result === "MEDIUM" ? result : "LOW";
};

function mapHazard(item: Row, actions: Row[]): Hazard {
  const matching = actions.filter((action) => action.hazardId === item.id);
  return {
    id: item.id, title: text(item.title), location: text(item.location), category: text(item.category),
    severity: severity(item.severity), status: hazardStatus(item.status), description: text(item.description),
    reportedAt: iso(item.createdAt), closedAt: nullableIso(item.closedAt),
    reportedBy: text(item.reporterName, text(item.reportedBy, "Unknown")),
    actionsTotal: matching.length,
    actionsDone: matching.filter((action) => lower(action.status) === "done").length,
  };
}

function mapAction(item: Row): HazardAction {
  return {
    id: item.id, description: text(item.description), dueOn: iso(item.dueDate).slice(0, 10),
    done: lower(item.status) === "done" ? 1 : 0, doneAt: nullableIso(item.completedAt),
  };
}

function mapIncident(item: Row, events: Row[]): Incident {
  const matching = events.filter((event) => event.incidentId === item.id).sort((a, b) => numberValue(a.at) - numberValue(b.at));
  const timeFor = (status: string) => nullableIso(matching.find((event) => event.toStatus === status)?.at);
  return {
    id: item.id, code: `IN-${item.id.slice(0, 6).toUpperCase()}`, title: text(item.title), type: text(item.type),
    location: text(item.location), description: text(item.description), occurredAt: iso(item.occurredAt || item.createdAt),
    injured: text(item.injuredPerson).trim().length > 0 || lower(item.type) === "injury",
    witnesses: text(item.witnesses), status: incidentStatus(item.status), rootCause: text(item.rootCause) || null,
    findings: text(item.findings) || null, actionsRequired: text(item.actionsRequired) || null,
    investigator: text(item.investigatorName) || null,
    reportedBy: text(item.reporterName, text(item.reportedBy, "Unknown")),
    timeline: {
      reported: timeFor("reported") ?? iso(item.createdAt), investigating: timeFor("investigating"),
      actions: timeFor("actions_pending"), closed: timeFor("closed") ?? nullableIso(item.closedAt),
    },
  };
}

function trainingStatus(item: Row): TrainingRecord["status"] {
  const expires = numberValue(item.expiresAt);
  if (!expires) return "VALID";
  if (expires < Date.now()) return "EXPIRED";
  if (expires - Date.now() <= 30 * DAY) return "EXPIRING_SOON";
  return "VALID";
}

function mapTraining(item: Row): TrainingRecord {
  return {
    id: item.id, worker: text(item.workerName, text(item.workerId, "Unknown worker")),
    course: text(item.courseName), provider: text(item.provider), completedOn: iso(item.completedAt).slice(0, 10),
    expiresOn: numberValue(item.expiresAt) ? iso(item.expiresAt).slice(0, 10) : "Never",
    status: trainingStatus(item),
  };
}

async function activeSiteId(requested: unknown): Promise<string> {
  if (text(requested)) return text(requested);
  const sites = (await rows("sites")).filter((site) => lower(site.status) !== "inactive");
  if (!sites.length) throw new ApiError("Create an active site before adding this record.");
  return sites[0].id;
}

async function addIncidentEvent(incidentId: string, fromStatus: string, toStatus: string, note: string) {
  const user = await currentUser();
  const ref = doc(collection(db, "incidentEvents"));
  await setDoc(ref, {
    id: ref.id, incidentId, fromStatus, toStatus, note,
    byUserId: user.id, byName: user.name, at: Date.now(),
  });
}

async function getHazards(url: URL): Promise<HazardList> {
  const [hazardRows, actionRows] = await Promise.all([rows("hazards"), rows("correctiveActions")]);
  const all = hazardRows.map((item) => mapHazard(item, actionRows)).sort((a, b) => b.reportedAt.localeCompare(a.reportedAt));
  const status = url.searchParams.get("status");
  const severityFilter = url.searchParams.get("severity");
  const search = (url.searchParams.get("q") ?? "").toLowerCase();
  const cutoff = Date.now() - 30 * DAY;
  return {
    items: all.filter((item) => (!status || item.status === status) && (!severityFilter || item.severity === severityFilter) && (!search || `${item.title} ${item.location}`.toLowerCase().includes(search))),
    counts: {
      all: all.length, open: all.filter((item) => item.status === "OPEN").length,
      inProgress: all.filter((item) => item.status === "IN_PROGRESS").length,
      closed: all.filter((item) => item.status === "CLOSED").length,
      closedLast30: all.filter((item) => item.status === "CLOSED" && numberValue(item.closedAt) >= cutoff).length,
    },
  };
}

async function getIncidents(url: URL) {
  const [incidentRows, eventRows] = await Promise.all([rows("incidents"), rows("incidentEvents")]);
  const status = url.searchParams.get("status");
  return {
    items: incidentRows.map((item) => mapIncident(item, eventRows))
      .filter((item) => !status || item.status === status)
      .sort((a, b) => b.occurredAt.localeCompare(a.occurredAt)),
  };
}

async function getTraining(url: URL): Promise<TrainingList> {
  const records = (await rows("trainingRecords")).map(mapTraining).sort((a, b) => a.expiresOn.localeCompare(b.expiresOn));
  const status = url.searchParams.get("status");
  const course = url.searchParams.get("course");
  const expired = records.filter((item) => item.status === "EXPIRED").length;
  return {
    items: records.filter((item) => (!status || item.status === status) && (!course || item.course === course)),
    counts: {
      all: records.length, valid: records.filter((item) => item.status === "VALID").length,
      expiringSoon: records.filter((item) => item.status === "EXPIRING_SOON").length, expired,
    },
    compliance: records.length ? Math.round(((records.length - expired) / records.length) * 100) : 100,
    courses: [...new Set(records.map((item) => item.course).filter(Boolean))].sort(),
  };
}

async function getPeople(): Promise<PeopleList> {
  const [users, assignments, sites] = await Promise.all([rows("users"), rows("site_assignments"), rows("sites")]);
  const siteNames = new Map(sites.map((site) => [site.id, text(site.name)]));
  const people: Person[] = users.map((item) => {
    const role = upper(item.role) as Role;
    const names = assignments.filter((assignment) => assignment.workerId === item.id && !text(assignment.endDate))
      .map((assignment) => siteNames.get(text(assignment.siteId))).filter(Boolean);
    return {
      id: item.id, name: text(item.fullName, text(item.email, "Unnamed user")), email: text(item.email), role,
      active: lower(item.status || "active") === "active",
      sites: role === "ADMIN" || role === "SAFETY_OFFICER" ? "All sites" : names.join(", ") || null,
    };
  }).sort((a, b) => a.name.localeCompare(b.name));
  const count = (role: Role) => people.filter((person) => person.role === role).length;
  return {
    items: people,
    counts: { all: people.length, workers: count("WORKER"), supervisors: count("SUPERVISOR"), safetyOfficers: count("SAFETY_OFFICER"), admins: count("ADMIN") },
  };
}

async function getProjects(): Promise<ProjectList> {
  const [projectRows, siteRows, assignments, hazards] = await Promise.all([rows("projects"), rows("sites"), rows("site_assignments"), rows("hazards")]);
  const items: Project[] = projectRows.map((item) => {
    const projectSites = siteRows.filter((site) => site.projectId === item.id);
    const siteIds = new Set(projectSites.map((site) => site.id));
    const people = new Set(assignments.filter((assignment) => siteIds.has(text(assignment.siteId)) && !text(assignment.endDate)).map((assignment) => assignment.workerId));
    return {
      id: item.id, name: text(item.name), client: text(item.clientName), status: upper(item.status || "active") as Project["status"],
      startedOn: text(item.startDate),
      sites: projectSites.map((site) => ({ id: site.id, name: text(site.name), address: text(site.address) })),
      peopleAssigned: people.size,
      openHazards: hazards.filter((hazard) => siteIds.has(text(hazard.siteId)) && lower(hazard.status) !== "closed").length,
    };
  }).sort((a, b) => a.name.localeCompare(b.name));
  return {
    items,
    counts: {
      all: items.length, active: items.filter((item) => item.status === "ACTIVE").length,
      onHold: items.filter((item) => item.status === "ON_HOLD").length,
      completed: items.filter((item) => item.status === "COMPLETED").length,
    },
  };
}

const categoryOf = (value: unknown) => text(value) ? text(value)[0].toUpperCase() + text(value).slice(1).toLowerCase() : "Other";

async function getAudit(url: URL): Promise<AuditList> {
  const category = url.searchParams.get("category");
  const all: AuditEntry[] = (await rows("auditLogs")).map((item) => ({
    id: item.id, at: iso(item.at), category: categoryOf(item.entityType),
    action: text(item.action).replaceAll("_", " "), summary: text(item.summary), actor: text(item.byName) || null,
  })).sort((a, b) => b.at.localeCompare(a.at));
  const counts: Record<string, number> = { all: all.length };
  all.forEach((item) => { counts[item.category] = (counts[item.category] ?? 0) + 1; });
  return { items: all.filter((item) => !category || item.category === category), counts };
}

async function getDashboard(url: URL): Promise<Dashboard> {
  const days = Math.min(Number(url.searchParams.get("days")) || 30, 3650);
  const [hazards, incidents, training, attendance, actions] = await Promise.all([
    rows("hazards"), rows("incidents"), rows("trainingRecords"), rows("attendance"), rows("correctiveActions"),
  ]);
  const lastInjuryMs = Math.max(0, ...incidents.filter((item) => text(item.injuredPerson).trim() || lower(item.type) === "injury").map((item) => numberValue(item.occurredAt)));
  const highRisk = hazards.filter((item) => lower(item.status) !== "closed" && ["HIGH", "CRITICAL"].includes(upper(item.severity))).length;
  const overdueHazardIds = new Set(actions.filter((item) => lower(item.status) === "pending" && numberValue(item.dueDate) < Date.now()).map((item) => item.hazardId));
  const trainingExpired = training.filter((item) => trainingStatus(item) === "EXPIRED").length;
  const weekCount = Math.min(Math.max(Math.ceil(days / 7), 1), 12);
  const chart = Array.from({ length: weekCount }, (_, index) => {
    const weeksAgo = weekCount - index - 1;
    const from = Date.now() - (weeksAgo + 1) * 7 * DAY;
    const to = Date.now() - weeksAgo * 7 * DAY;
    return {
      label: weeksAgo === 0 ? "This wk" : `${weeksAgo}w ago`,
      reported: hazards.filter((item) => numberValue(item.createdAt) >= from && numberValue(item.createdAt) < to).length,
      closed: hazards.filter((item) => numberValue(item.closedAt) >= from && numberValue(item.closedAt) < to).length,
    };
  });
  const hazardAttention: Dashboard["attention"] = hazards.filter((item) => lower(item.status) !== "closed" && ["HIGH", "CRITICAL"].includes(upper(item.severity)))
    .map((item) => ({ type: "Hazard", id: item.id, title: text(item.title), detail: text(item.location), severity: severity(item.severity), at: iso(item.createdAt) }));
  const incidentAttention: Dashboard["attention"] = incidents.filter((item) => lower(item.status) !== "closed")
    .map((item) => ({ type: "Incident", id: item.id, title: text(item.title), detail: `Reported by ${text(item.reporterName, "Unknown")}`, severity: text(item.injuredPerson).trim() ? "HIGH" : "MEDIUM", at: iso(item.createdAt) }));
  const priority = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };
  return {
    days, daysSinceInjury: lastInjuryMs ? Math.floor((Date.now() - lastInjuryMs) / DAY) : null,
    lastInjury: lastInjuryMs ? new Date(lastInjuryMs).toISOString().slice(0, 10) : null,
    onSite: attendance.filter((item) => lower(item.status) === "checked_in" && !numberValue(item.checkOut)).length,
    highRisk, overdue: hazards.filter((item) => overdueHazardIds.has(item.id) && lower(item.status) !== "closed").length,
    openHazards: hazards.filter((item) => lower(item.status) !== "closed").length,
    openIncidents: incidents.filter((item) => lower(item.status) !== "closed").length,
    trainingCompliance: training.length ? Math.round(((training.length - trainingExpired) / training.length) * 100) : 100,
    chart,
    attention: [...hazardAttention, ...incidentAttention].sort((a, b) => priority[a.severity] - priority[b.severity] || b.at.localeCompare(a.at)).slice(0, 6),
  };
}

export async function api<T = unknown>(path: string, init: Init = {}): Promise<T> {
  requireAccount();
  const url = new URL(path, "https://safesite.local");
  const method = (init.method ?? (init.body ? "POST" : "GET")).toUpperCase();
  const body = (init.body ?? {}) as Data;
  const segments = url.pathname.split("/").filter(Boolean);
  try {
    if (method === "GET" && url.pathname === "/dashboard") return await getDashboard(url) as T;
    if (method === "GET" && url.pathname === "/hazards") return await getHazards(url) as T;
    if (method === "GET" && url.pathname === "/incidents") return await getIncidents(url) as T;
    if (method === "GET" && url.pathname === "/training") return await getTraining(url) as T;
    if (method === "GET" && url.pathname === "/people") return await getPeople() as T;
    if (method === "GET" && url.pathname === "/projects") return await getProjects() as T;
    if (method === "GET" && url.pathname === "/audit") return await getAudit(url) as T;

    if (method === "GET" && segments[0] === "hazards" && segments.length === 2) {
      const [item, actions] = await Promise.all([row("hazards", segments[1]), rows("correctiveActions")]);
      if (!item) throw new ApiError("Hazard not found.", 404);
      return { ...mapHazard(item, actions), actions: actions.filter((action) => action.hazardId === segments[1]).map(mapAction) } as T;
    }
    if (method === "POST" && url.pathname === "/hazards") {
      const user = await currentUser();
      if (text(body.title).trim().length < 3) throw new ApiError("Please give the hazard a title.");
      const siteId = await activeSiteId(body.siteId);
      const ref = doc(collection(db, "hazards"));
      await setDoc(ref, {
        id: ref.id, siteId, title: text(body.title).trim(), description: text(body.description).trim(), category: text(body.category),
        severity: upper(body.severity), location: text(body.location).trim(), photoUrl: null, reportedBy: user.id,
        reporterName: user.name, status: "open", createdAt: Date.now(), closedAt: null,
      });
      await audit("HAZARD_REPORTED", "hazard", ref.id, `Hazard reported: ${text(body.title)} (${upper(body.severity)})`, siteId);
      return { id: ref.id } as T;
    }
    if (method === "POST" && segments[0] === "hazards" && segments[2] === "actions") {
      const hazardId = segments[1];
      const item = await row("hazards", hazardId);
      if (!item) throw new ApiError("Hazard not found.", 404);
      if (lower(item.status) === "closed") throw new ApiError("This hazard is already closed.", 409);
      const user = await currentUser();
      const ref = doc(collection(db, "correctiveActions"));
      await setDoc(ref, {
        id: ref.id, hazardId, description: text(body.description).trim(), assignedTo: text(body.assignedTo),
        dueDate: dateMillis(body.dueOn), status: "pending", createdBy: user.id, createdAt: Date.now(), completedAt: null,
      });
      await updateDoc(doc(db, "hazards", hazardId), { status: "in_progress" });
      await audit("ACTION_ADDED", "hazard", hazardId, `Corrective action on '${text(item.title)}': ${text(body.description)}`, text(item.siteId));
      return { id: ref.id } as T;
    }
    if (method === "PATCH" && segments[0] === "hazards" && segments[2] === "actions" && segments[3]) {
      await updateDoc(doc(db, "correctiveActions", segments[3]), body.done ? { status: "done", completedAt: Date.now() } : { status: "pending", completedAt: null });
      if (body.done) await audit("ACTION_COMPLETED", "hazard", segments[1], "Corrective action completed");
      return { ok: true } as T;
    }
    if (method === "POST" && segments[0] === "hazards" && segments[2] === "close") {
      const actions = (await rows("correctiveActions")).filter((item) => item.hazardId === segments[1]);
      if (!actions.length) throw new ApiError("Add at least one corrective action before closing.", 409);
      const remaining = actions.filter((item) => lower(item.status) !== "done").length;
      if (remaining) throw new ApiError(`${remaining} corrective action(s) still open.`, 409);
      const item = await row("hazards", segments[1]);
      if (!item) throw new ApiError("Hazard not found.", 404);
      await updateDoc(doc(db, "hazards", segments[1]), { status: "closed", closedAt: Date.now() });
      await audit("HAZARD_CLOSED", "hazard", segments[1], `Hazard closed: ${text(item.title)}`, text(item.siteId));
      return { ok: true } as T;
    }

    if (method === "GET" && segments[0] === "incidents" && segments.length === 2) {
      const [item, events] = await Promise.all([row("incidents", segments[1]), rows("incidentEvents")]);
      if (!item) throw new ApiError("Incident not found.", 404);
      return mapIncident(item, events) as T;
    }
    if (method === "POST" && url.pathname === "/incidents") {
      const user = await currentUser();
      const siteId = await activeSiteId(body.siteId);
      const now = Date.now();
      const ref = doc(collection(db, "incidents"));
      await setDoc(ref, {
        id: ref.id, siteId, title: text(body.title).trim(), description: text(body.description).trim(), type: text(body.type, "Near miss"),
        severity: body.injured ? "SERIOUS" : "MINOR", location: text(body.location), injuredPerson: body.injured ? "Injury reported" : "",
        witnesses: text(body.witnesses), occurredAt: numberValue(body.occurredAt) || now, reportedBy: user.id, reporterName: user.name,
        status: "reported", investigatorName: "", rootCause: "", findings: "", actionsRequired: "", closingNote: "", createdAt: now, closedAt: null,
      });
      await addIncidentEvent(ref.id, "", "reported", "Incident reported");
      await audit("INCIDENT_REPORTED", "incident", ref.id, `Incident '${text(body.title)}' → Reported`, siteId);
      return { id: ref.id } as T;
    }
    if (segments[0] === "incidents" && segments[2]) {
      const incidentId = segments[1];
      const action = segments[2];
      const item = await row("incidents", incidentId);
      if (!item) throw new ApiError("Incident not found.", 404);
      const status = lower(item.status);
      const user = await currentUser();
      if (method === "POST" && action === "investigate") {
        if (status !== "reported") throw new ApiError("Investigation has already started.", 409);
        await updateDoc(doc(db, "incidents", incidentId), { status: "investigating", investigatorName: user.name });
        await addIncidentEvent(incidentId, "reported", "investigating", `Investigation started by ${user.name}`);
        await audit("INCIDENT_INVESTIGATING", "incident", incidentId, `Incident '${text(item.title)}' → Investigating`, text(item.siteId));
        return { ok: true } as T;
      }
      if (method === "PUT" && action === "draft") {
        if (status !== "investigating") throw new ApiError("Incident is not being investigated.", 409);
        await updateDoc(doc(db, "incidents", incidentId), { rootCause: text(body.rootCause), findings: text(body.findings), actionsRequired: text(body.actionsRequired) });
        return { ok: true } as T;
      }
      if (method === "POST" && action === "findings") {
        if (status !== "investigating") throw new ApiError("Findings can only be recorded while investigating.", 409);
        if (text(body.rootCause).trim().length < 3 || text(body.actionsRequired).trim().length < 3) throw new ApiError("Root cause and actions required are mandatory.");
        await updateDoc(doc(db, "incidents", incidentId), { status: "actions_pending", rootCause: text(body.rootCause), findings: text(body.findings), actionsRequired: text(body.actionsRequired) });
        await addIncidentEvent(incidentId, "investigating", "actions_pending", `Findings recorded. Root cause: ${text(body.rootCause)}`);
        await audit("INCIDENT_ACTIONS_PENDING", "incident", incidentId, `Incident '${text(item.title)}' → Actions pending`, text(item.siteId));
        return { ok: true } as T;
      }
      if (method === "POST" && action === "close") {
        if (status !== "actions_pending") throw new ApiError("Record findings before closing.", 409);
        const note = text(body.closingNote, "Actions completed and incident closed from web portal.");
        await updateDoc(doc(db, "incidents", incidentId), { status: "closed", closingNote: note, closedAt: Date.now() });
        await addIncidentEvent(incidentId, "actions_pending", "closed", `Closed: ${note}`);
        await audit("INCIDENT_CLOSED", "incident", incidentId, `Incident '${text(item.title)}' → Closed`, text(item.siteId));
        return { ok: true } as T;
      }
    }

    if (method === "POST" && url.pathname === "/training") {
      const user = await currentUser();
      const worker = await row("users", text(body.userId));
      if (!worker) throw new ApiError("Worker not found.", 404);
      const siteId = await activeSiteId(body.siteId);
      const ref = doc(collection(db, "trainingRecords"));
      await setDoc(ref, {
        id: ref.id, siteId, workerId: worker.id, workerName: text(worker.fullName, text(worker.email)), courseName: text(body.course),
        provider: text(body.provider), certificateNumber: text(body.certificateNumber), completedAt: dateMillis(body.completedOn),
        expiresAt: body.expiresOn ? dateMillis(body.expiresOn) : null, recordedBy: user.id, createdAt: Date.now(),
      });
      await audit("TRAINING_RECORDED", "training", ref.id, `${text(body.course)} recorded for ${text(worker.fullName)}`, siteId);
      return { id: ref.id } as T;
    }

    if (method === "POST" && url.pathname === "/people") {
      await requireAdmin();
      const secondary = initializeApp(firebaseConfig, `create-user-${Date.now()}`);
      try {
        const secondaryAuth = getAuth(secondary);
        const credential = await createUserWithEmailAndPassword(secondaryAuth, text(body.email).trim(), text(body.password));
        await setDoc(doc(db, "users", credential.user.uid), {
          id: credential.user.uid, fullName: text(body.name).trim(), email: text(body.email).trim(), role: upper(body.role), status: "active",
        });
        await signOut(secondaryAuth);
        await audit("USER_CREATED", "user", credential.user.uid, `Account created for ${text(body.name)} (${text(body.email)}) as ${upper(body.role)}`);
        return { id: credential.user.uid } as T;
      } finally { await deleteApp(secondary); }
    }
    if (method === "PATCH" && segments[0] === "people" && segments[1]) {
      const admin = await requireAdmin();
      if (admin.id === segments[1]) throw new ApiError("You cannot change your own role or status.", 409);
      const target = await row("users", segments[1]);
      if (!target) throw new ApiError("User not found.", 404);
      const updates: Data = {};
      if (body.role) updates.role = upper(body.role);
      if (typeof body.active === "boolean") updates.status = body.active ? "active" : "inactive";
      await updateDoc(doc(db, "users", segments[1]), updates);
      if (body.role) await audit("USER_ROLE_CHANGED", "user", segments[1], `${text(target.fullName)} role changed to ${upper(body.role)}`);
      if (typeof body.active === "boolean") await audit(body.active ? "USER_ACTIVATED" : "USER_DEACTIVATED", "user", segments[1], `${text(target.fullName)} ${body.active ? "activated" : "deactivated"}`);
      return { ok: true } as T;
    }

    if (method === "POST" && url.pathname === "/projects") {
      await requireAdmin();
      const ref = doc(collection(db, "projects"));
      await setDoc(ref, { id: ref.id, name: text(body.name).trim(), clientName: text(body.client).trim(), status: "active", startDate: text(body.startedOn) });
      await audit("PROJECT_CREATED", "project", ref.id, `Project created: ${text(body.name)} for ${text(body.client)}`);
      return { id: ref.id } as T;
    }
    if (method === "POST" && segments[0] === "projects" && segments[2] === "sites") {
      await requireAdmin();
      const ref = doc(collection(db, "sites"));
      await setDoc(ref, { id: ref.id, projectId: segments[1], name: text(body.name).trim(), address: text(body.address).trim(), status: "active" });
      await audit("SITE_CREATED", "site", ref.id, `Site '${text(body.name)}' added`, ref.id);
      return { id: ref.id } as T;
    }
    throw new ApiError(`Unsupported operation: ${method} ${url.pathname}`, 404);
  } catch (error) {
    if (error instanceof ApiError) throw error;
    throw new ApiError(error instanceof Error ? error.message : "Something went wrong.");
  }
}

const csvValue = (value: unknown): string => {
  const text = String(value ?? "");

  // Check past leading whitespace/control characters for formulas.
  const formulaCandidate = text.replace(/^[\s\u0000-\u001f]+/, "");

  const needsProtection =
    /^[=+\-@]/.test(formulaCandidate) ||
    /^[\t\r\n]/.test(text);

  const safeText = needsProtection ? `'${text}` : text;

  return `"${safeText.replaceAll('"', '""')}"`;
};
export async function downloadCsv(kind: string) {
  let headers: string[] = [];
  let output: unknown[][] = [];
  if (kind === "hazards") {
    const data = await api<HazardList>("/hazards");
    headers = ["Title", "Location", "Category", "Severity", "Status", "Reported", "Reported by"];
    output = data.items.map((item) => [item.title, item.location, item.category, item.severity, item.status, item.reportedAt, item.reportedBy]);
  } else if (kind === "incidents") {
    const data = await api<{ items: Incident[] }>("/incidents");
    headers = ["Code", "Title", "Type", "Location", "Occurred", "Injured", "Status", "Reported by"];
    output = data.items.map((item) => [item.code, item.title, item.type, item.location, item.occurredAt, item.injured, item.status, item.reportedBy]);
  } else if (kind === "training") {
    const data = await api<TrainingList>("/training");
    headers = ["Worker", "Course", "Provider", "Completed", "Expires", "Status"];
    output = data.items.map((item) => [item.worker, item.course, item.provider, item.completedOn, item.expiresOn, item.status]);
  } else if (kind === "audit") {
    const data = await api<AuditList>("/audit");
    headers = ["At", "Category", "Action", "Summary", "Actor"];
    output = data.items.map((item) => [item.at, item.category, item.action, item.summary, item.actor]);
  } else throw new ApiError("Unknown export type.");
  const csv = [headers, ...output].map((line) => line.map(csvValue).join(",")).join("\r\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const anchor = document.createElement("a");
  anchor.href = URL.createObjectURL(blob);
  anchor.download = `safesite-${kind}-${new Date().toISOString().slice(0, 10)}.csv`;
  anchor.click();
  URL.revokeObjectURL(anchor.href);
}

export function useApi<T>(path: string) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let live = true;
    setLoading(true);
    api<T>(path).then((result) => { if (live) { setData(result); setError(null); } })
      .catch((reason: Error) => { if (live) setError(reason.message); })
      .finally(() => { if (live) setLoading(false); });
    return () => { live = false; };
  }, [path, tick]);
  const reload = useCallback(() => setTick((value) => value + 1), []);
  return { data, error, loading, reload };
}
