import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { onAuthStateChanged, signInWithEmailAndPassword, signOut, type User as FirebaseUser } from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import { db, firebaseAuth } from "./firebase";
import type { Role, User } from "./types";

interface AuthState { user: User | null; ready: boolean; login: (email: string, password: string) => Promise<void>; logout: () => Promise<void> }
const Ctx = createContext<AuthState>(null!);
export const useAuth = () => useContext(Ctx);

async function loadUser(account: FirebaseUser): Promise<User> {
  const snapshot = await getDoc(doc(db, "users", account.uid));
  if (!snapshot.exists()) throw new Error("Your Firebase account does not have a SafeSite user profile.");
  const data = snapshot.data();
  const role = String(data.role ?? "").toUpperCase() as Role;
  if (!(["SAFETY_OFFICER", "ADMIN"] as Role[]).includes(role)) throw new Error("The web portal is available only to Safety Officers and Administrators.");
  if (String(data.status ?? "active").toLowerCase() !== "active") throw new Error("This SafeSite account has been deactivated.");
  return { id: account.uid, name: data.fullName || account.email || "SafeSite User", email: data.email || account.email || "", role };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);
  useEffect(() => onAuthStateChanged(firebaseAuth, async (account: FirebaseUser | null) => {
    try { setUser(account ? await loadUser(account) : null); }
    catch { setUser(null); await signOut(firebaseAuth); }
    finally { setReady(true); }
  }), []);
  const login = async (email: string, password: string) => {
    const credential = await signInWithEmailAndPassword(firebaseAuth, email.trim(), password);
    try { setUser(await loadUser(credential.user)); }
    catch (error) { await signOut(firebaseAuth); throw error; }
  };
  const logout = async () => { await signOut(firebaseAuth); setUser(null); };
  return <Ctx.Provider value={{ user, ready, login, logout }}>{children}</Ctx.Provider>;
}
