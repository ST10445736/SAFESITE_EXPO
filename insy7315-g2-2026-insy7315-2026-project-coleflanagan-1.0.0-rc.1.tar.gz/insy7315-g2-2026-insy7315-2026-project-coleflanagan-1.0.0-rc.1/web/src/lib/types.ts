export type Role =
  | "WORKER"
  | "SUPERVISOR"
  | "SAFETY_OFFICER"
  | "ADMIN";

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
}

export type Severity = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";

export interface Hazard {
  id: string;
  title: string;
  location: string;
  category: string;
  severity: Severity;
  status: "OPEN" | "IN_PROGRESS" | "CLOSED";
  description: string;
  reportedAt: string;
  closedAt: string | null;
  reportedBy: string;
  actionsTotal: number;
  actionsDone: number;
}

export interface HazardAction {
  id: string;
  description: string;
  dueOn: string;
  done: 0 | 1;
  doneAt: string | null;
}

export interface HazardList {
  items: Hazard[];
  counts: {
    all: number;
    open: number;
    inProgress: number;
    closed: number;
    closedLast30: number;
  };
}

export type IncidentStatus =
  | "REPORTED"
  | "INVESTIGATING"
  | "ACTIONS"
  | "CLOSED";

export interface Incident {
  id: string;
  code: string;
  title: string;
  type: string;
  location: string;
  description: string;
  occurredAt: string;
  injured: boolean;
  witnesses: string;
  status: IncidentStatus;
  rootCause: string | null;
  findings: string | null;
  actionsRequired: string | null;
  investigator: string | null;
  reportedBy: string;
  timeline: {
    reported: string;
    investigating: string | null;
    actions: string | null;
    closed: string | null;
  };
}

export interface TrainingRecord {
  id: string;
  worker: string;
  course: string;
  provider: string;
  completedOn: string;
  expiresOn: string;
  status: "VALID" | "EXPIRING_SOON" | "EXPIRED";
}

export interface TrainingList {
  items: TrainingRecord[];
  compliance: number;
  courses: string[];
  counts: {
    all: number;
    valid: number;
    expiringSoon: number;
    expired: number;
  };
}

export interface Person {
  id: string;
  name: string;
  email: string;
  role: Role;
  active: boolean;
  sites: string | null;
}

export interface PeopleList {
  items: Person[];
  counts: {
    all: number;
    workers: number;
    supervisors: number;
    safetyOfficers: number;
    admins: number;
  };
}

export interface ProjectSite {
  id: string;
  name: string;
  address: string;
}

export interface Project {
  id: string;
  name: string;
  client: string;
  status: "ACTIVE" | "ON_HOLD" | "COMPLETED";
  startedOn: string;
  sites: ProjectSite[];
  peopleAssigned: number;
  openHazards: number;
}

export interface ProjectList {
  items: Project[];
  counts: {
    all: number;
    active: number;
    onHold: number;
    completed: number;
  };
}

export interface AuditEntry {
  id: string;
  at: string;
  category: string;
  action: string;
  summary: string;
  actor: string | null;
}

export interface AuditList {
  items: AuditEntry[];
  counts: Record<string, number>;
}

export interface Dashboard {
  days: number;
  daysSinceInjury: number | null;
  lastInjury: string | null;
  onSite: number;
  highRisk: number;
  overdue: number;
  openHazards: number;
  openIncidents: number;
  trainingCompliance: number;
  chart: {
    label: string;
    reported: number;
    closed: number;
  }[];
  attention: {
    type: "Hazard" | "Incident";
    id: string;
    title: string;
    detail: string;
    severity: Severity;
    at: string;
  }[];
}