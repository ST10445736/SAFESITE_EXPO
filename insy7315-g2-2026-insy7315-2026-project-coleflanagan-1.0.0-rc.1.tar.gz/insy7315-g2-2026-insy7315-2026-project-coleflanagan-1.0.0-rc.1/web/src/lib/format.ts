export const fmtDate = (iso: string) => {
  const date = new Date(iso);
  return Number.isNaN(date.getTime()) ? iso || "–" : date.toLocaleDateString("en-ZA", { day: "numeric", month: "short", year: "numeric" });
};
export const fmtDateTime = (iso: string) =>
  new Date(iso).toLocaleString("en-ZA", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit", hour12: false });
export const titleCase = (s: string) => s.toLowerCase().replace(/_/g, " ").replace(/^\w/, (c) => c.toUpperCase());
export const ROLE_LABEL = { WORKER: "Worker", SUPERVISOR: "Supervisor", SAFETY_OFFICER: "Safety Officer", ADMIN: "Admin" } as const;
export const initials = (name: string) => name.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();
