import { NavLink, Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../lib/auth";
import { ROLE_LABEL } from "../lib/format";
import { Avatar, Icon, Loading, type IconName } from "./ui";
import { Logo } from "./Logo";
import SafeAiChat from "./SafeAiChat";
import { useApi } from "../lib/api";
import type { Dashboard } from "../lib/types";

type Item = { to: string; label: string; icon: IconName; end?: boolean; badge?: number };

export default function PortalLayout() {
  const { user, ready, logout } = useAuth();
  const stats = useApi<Dashboard>("/dashboard");
  if (!ready) return <Loading />;
  if (!user) return <Navigate to="/portal/sign-in" replace />;

  const admin = user.role === "ADMIN";
  const sections: { title: string; items: Item[] }[] = [
    { title: "Overview", items: [{ to: "/portal", label: "Dashboard", icon: "dashboard", end: true }] },
    { title: "Safety", items: [
      { to: "/portal/hazards", label: "Hazards", icon: "hazard", badge: stats.data?.openHazards },
      { to: "/portal/incidents", label: "Incidents", icon: "incident", badge: stats.data?.openIncidents },
      { to: "/portal/training", label: "Training", icon: "training" },
      { to: "/portal/ppe", label: "PPE Review", icon: "ppe" },
    ] },
    ...(admin ? [
      { title: "Manage", items: [
        { to: "/portal/people", label: "People", icon: "people" as IconName },
        { to: "/portal/projects", label: "Projects & sites", icon: "projects" as IconName },
      ] },
      { title: "Compliance", items: [{ to: "/portal/audit", label: "Audit history", icon: "audit" as IconName }] },
    ] : []),
    { title: "Reports", items: [{ to: "/portal/exports", label: "Exports", icon: "reports" }] },
  ];

  return (
    <div className="flex min-h-screen">
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-line bg-surface p-5 md:flex">
        <div className="mb-8"><Logo height={40} /><p className="mt-1 text-xs font-medium text-ink-2">{ROLE_LABEL[user.role]} portal</p></div>
        <nav className="flex-1 space-y-6 overflow-y-auto" aria-label="Main">
          {sections.map((s) => (
            <div key={s.title}>
              <p className="mb-1.5 px-3 text-xs font-bold text-ink-3">{s.title}</p>
              {s.items.map((i) => (
                <NavLink key={i.to} to={i.to} end={i.end}
                  className={({ isActive }) => `flex items-center gap-3 rounded-[12px] px-3 py-2.5 text-[14px] font-medium transition-colors ${isActive ? "bg-olive-pale text-olive-dark" : "text-ink-2 hover:bg-canvas-alt"}`}>
                  <Icon name={i.icon} size={20} /><span className="flex-1">{i.label}</span>
                  {!!i.badge && <span className="rounded-full bg-canvas-alt px-2 text-xs font-bold text-ink-2">{i.badge}</span>}
                </NavLink>
              ))}
            </div>
          ))}
        </nav>
        <div className="mt-4 flex items-center gap-3 border-t border-line pt-4">
          <Avatar name={user.name} />
          <div className="min-w-0 flex-1"><p className="truncate text-sm font-bold">{user.name}</p><p className="text-xs text-ink-2">{ROLE_LABEL[user.role]}</p></div>
          <button onClick={logout} className="rounded-lg px-2 py-1 text-xs font-bold text-ink-2 hover:bg-canvas-alt">Sign out</button>
        </div>
      </aside>

      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between border-b border-line bg-surface px-4 py-3 md:hidden">
          <Logo height={34} />
          <button onClick={logout} className="text-sm font-bold text-ink-2">Sign out</button>
        </div>
        <nav aria-label="Mobile" className="flex gap-1 overflow-x-auto border-b border-line bg-surface px-3 py-2 md:hidden">
          {sections.flatMap((s) => s.items).map((i) => (
            <NavLink key={i.to} to={i.to} end={i.end} className={({ isActive }) => `whitespace-nowrap rounded-full px-3 py-1.5 text-sm font-medium ${isActive ? "bg-olive-pale text-olive-dark" : "text-ink-2"}`}>{i.label}</NavLink>
          ))}
        </nav>
        <main className="mx-auto max-w-6xl p-5 md:p-8"><Outlet /></main>
      </div>
      <SafeAiChat />
    </div>
  );
}
