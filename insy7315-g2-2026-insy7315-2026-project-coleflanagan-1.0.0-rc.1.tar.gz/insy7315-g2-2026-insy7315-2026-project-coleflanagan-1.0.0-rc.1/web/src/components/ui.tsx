import { useState, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes } from "react";
import { titleCase } from "../lib/format";

/* ---------- Icon: brand SVGs inherit text colour via currentColor ---------- */
const icons = import.meta.glob("../assets/icons/*.svg", { query: "?raw", import: "default", eager: true }) as Record<string, string>;
export type IconName = "audit" | "check-in" | "dashboard" | "hazard" | "incident" | "more" | "people" | "ppe" | "projects" | "reports" | "safety" | "sites" | "tasks" | "training";
export function Icon({ name, size = 20, className = "" }: { name: IconName; size?: number; className?: string }) {
  const svg = icons[`../assets/icons/${name}.svg`] ?? "";
  return <span aria-hidden className={`inline-flex shrink-0 ${className}`} style={{ width: size, height: size }}
    dangerouslySetInnerHTML={{ __html: svg.replace(/width="24"/, 'width="100%"').replace(/height="24"/, 'height="100%"') }} />;
}

/* ---------- Buttons ---------- */
type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "secondary" | "danger" | "ghost" };
export function Button({ variant = "primary", className = "", ...p }: BtnProps) {
  const styles = {
    primary: "bg-olive text-white hover:bg-olive-light active:bg-olive-dark",
    secondary: "bg-surface text-ink border border-line hover:bg-canvas-alt",
    danger: "bg-danger text-white hover:opacity-90",
    ghost: "text-ink-2 hover:bg-canvas-alt",
  }[variant];
  return <button {...p} className={`inline-flex items-center justify-center gap-2 rounded-[12px] px-4 py-2.5 text-sm font-bold transition-colors disabled:cursor-not-allowed disabled:opacity-50 ${styles} ${className}`} />;
}

/* ---------- Cards & stats ---------- */
export const Card = ({ children, className = "" }: { children: ReactNode; className?: string }) =>
  <section className={`rounded-[18px] border border-line bg-surface ${className}`}>{children}</section>;

export function StatCard({ label, value, note, tone = "ink" }: { label: string; value: ReactNode; note?: ReactNode; tone?: "ink" | "ok" | "warn" | "danger" | "navy" }) {
  const color = { ink: "text-ink", ok: "text-ok", warn: "text-warn-dark", danger: "text-danger", navy: "text-navy" }[tone];
  return (
    <Card className="p-5">
      <p className="text-sm text-ink-2">{label}</p>
      <p className={`mt-1 text-4xl font-extrabold tracking-tight ${color}`}>{value}</p>
      {note && <p className="mt-1 text-sm text-ink-2">{note}</p>}
    </Card>
  );
}

/* ---------- Badges: always a text label, never colour alone ---------- */
const TONES = {
  neutral: "bg-canvas-alt text-ink-2", ok: "bg-ok-light text-ok", warn: "bg-warn-light text-warn-dark",
  danger: "bg-danger-light text-danger", navy: "bg-[#E8EEF6] text-navy", olive: "bg-olive-pale text-olive-dark",
};
export function Badge({ tone = "neutral", children }: { tone?: keyof typeof TONES; children: ReactNode }) {
  return <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-bold ${TONES[tone]}`}>{children}</span>;
}
const SEVERITY_TONE = { CRITICAL: "danger", HIGH: "warn", MEDIUM: "navy", LOW: "neutral" } as const;
export const SeverityBadge = ({ value }: { value: keyof typeof SEVERITY_TONE }) => <Badge tone={SEVERITY_TONE[value]}>{titleCase(value)}</Badge>;
const STATUS_TONE: Record<string, keyof typeof TONES> = {
  OPEN: "warn", IN_PROGRESS: "navy", CLOSED: "ok", VALID: "ok", EXPIRING_SOON: "warn", EXPIRED: "danger",
  REPORTED: "warn", INVESTIGATING: "navy", ACTIONS: "olive", ACTIVE: "ok", ON_HOLD: "warn", COMPLETED: "neutral",
};
export const StatusBadge = ({ value }: { value: string }) => <Badge tone={STATUS_TONE[value] ?? "neutral"}>{titleCase(value)}</Badge>;

/* ---------- Filter chips ---------- */
export function Chips<T extends string>({ value, onChange, options }: { value: T; onChange: (v: T) => void; options: { value: T; label: string; count?: number }[] }) {
  return (
    <div className="flex flex-wrap gap-2" role="group">
      {options.map((o) => {
        const on = o.value === value;
        return (
          <button key={o.value} onClick={() => onChange(o.value)} aria-pressed={on}
            className={`rounded-full border px-4 py-1.5 text-[13px] font-medium transition-colors ${on ? "border-olive bg-olive-pale text-olive-dark" : "border-line bg-surface text-ink-2 hover:bg-canvas-alt"}`}>
            {o.label}{o.count !== undefined && <span className="ml-1.5 text-ink-3">{o.count}</span>}
          </button>
        );
      })}
    </div>
  );
}

/* ---------- Table ---------- */
export const Table = ({ children }: { children: ReactNode }) =>
  <div className="overflow-x-auto"><table className="w-full min-w-[640px] text-left text-sm">{children}</table></div>;
export const Th = ({ children }: { children?: ReactNode }) =>
  <th className="border-b border-line px-5 py-3 text-xs font-bold text-ink-3">{children}</th>;
export const Td = ({ children, className = "" }: { children?: ReactNode; className?: string }) =>
  <td className={`border-b border-line-soft px-5 py-3.5 align-top ${className}`}>{children}</td>;

/* ---------- Page chrome ---------- */
export function PageHeader({ crumb, title, actions }: { crumb?: ReactNode; title: string; actions?: ReactNode }) {
  return (
    <header className="flex flex-wrap items-end justify-between gap-3 pb-6">
      <div>{crumb && <p className="text-sm text-ink-2">{crumb}</p>}<h1 className="text-2xl font-bold">{title}</h1></div>
      {actions}
    </header>
  );
}
export const Loading = () => <p className="p-6 text-sm text-ink-2" role="status">Loading…</p>;
export const ErrorNote = ({ message }: { message: string }) =>
  <p role="alert" className="rounded-[12px] bg-danger-light px-4 py-3 text-sm font-medium text-danger">{message}</p>;
export const Empty = ({ children }: { children: ReactNode }) => <p className="px-5 py-10 text-center text-sm text-ink-2">{children}</p>;

/* ---------- Form fields ---------- */
const fieldCls = "w-full rounded-[12px] border border-line bg-surface px-3.5 py-2.5 text-sm placeholder:text-ink-3 focus:border-navy";
export function Field({ label, required, hint, children }: { label: string; required?: boolean; hint?: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium">{label}{required && <span className="text-danger" aria-hidden> *</span>}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-ink-2">{hint}</span>}
    </label>
  );
}
export const Input = (p: InputHTMLAttributes<HTMLInputElement>) => <input {...p} className={`${fieldCls} ${p.className ?? ""}`} />;
export const Textarea = (p: TextareaHTMLAttributes<HTMLTextAreaElement>) => <textarea rows={3} {...p} className={`${fieldCls} ${p.className ?? ""}`} />;
export const Select = (p: SelectHTMLAttributes<HTMLSelectElement>) => <select {...p} className={`${fieldCls} ${p.className ?? ""}`} />;

/* ---------- Avatar ---------- */
export const Avatar = ({ name }: { name: string }) =>
  <span aria-hidden className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-olive-pale text-xs font-bold text-olive-dark">{name.split(" ").map((p) => p[0]).slice(0, 2).join("")}</span>;

/* ---------- Simple modal ---------- */
export function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-night/50 p-4" onClick={onClose}>
      <div role="dialog" aria-modal aria-label={title} className="w-full max-w-md rounded-[20px] bg-surface p-6 shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-bold">{title}</h2>
          <button onClick={onClose} aria-label="Close" className="rounded-lg px-2 py-1 text-ink-2 hover:bg-canvas-alt">✕</button></div>
        {children}
      </div>
    </div>
  );
}

/** Small helper for forms that call the API */
export function useAction() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const run = async (fn: () => Promise<unknown>) => {
    setBusy(true); setError(null);
    try { await fn(); return true; } catch (e) { setError((e as Error).message); return false; } finally { setBusy(false); }
  };
  return { busy, error, run, setError };
}
