/** Always use the supplied artwork. Never retype the wordmark (brand rule). */
export function Logo({ onDark = false, height = 32 }: { onDark?: boolean; height?: number }) {
  return <img src={`/brand/safesite-wordmark-${onDark ? "dark" : "light"}-background-1200.png`} alt="SafeSite" style={{ height }} className="w-auto" />;
}
