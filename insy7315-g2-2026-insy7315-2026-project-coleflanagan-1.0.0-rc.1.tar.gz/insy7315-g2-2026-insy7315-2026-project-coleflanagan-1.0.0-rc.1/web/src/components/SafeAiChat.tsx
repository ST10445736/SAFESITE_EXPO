import { useEffect, useRef, useState } from "react";
import type { ChatSession } from "firebase/ai";
import { startSafeAiChat } from "../lib/ai";

type Msg = { from: "user" | "ai"; text: string };

const SUGGESTIONS = ["How do I check in?", "How does PPE approval work?", "How do I close a hazard?"];

export default function SafeAiChat() {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Msg[]>([
    { from: "ai", text: "Hi, I'm SafeAI. Ask me anything about how SafeSite works." },
  ]);
  const chat = useRef<ChatSession | null>(null);
  const bottom = useRef<HTMLDivElement>(null);

  useEffect(() => { bottom.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, open]);

  async function send(text: string) {
    const question = text.trim();
    if (!question || busy) return;
    setInput("");
    setMessages((m) => [...m, { from: "user", text: question }]);
    setBusy(true);
    try {
      chat.current ??= startSafeAiChat();
      const result = await chat.current.sendMessage(question);
      setMessages((m) => [...m, { from: "ai", text: result.response.text() }]);
    } catch (e) {
      console.error("SafeAI error", e);
      setMessages((m) => [...m, { from: "ai", text: "SafeAI is unavailable right now. Please check your connection or ask your supervisor." }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      {!open && (
        <button
          onClick={() => setOpen(true)}
          aria-label="Open SafeAI help"
          className="fixed bottom-5 right-5 z-40 grid h-14 w-14 place-items-center rounded-full bg-olive text-base font-extrabold text-white shadow-lg hover:bg-olive-light"
        >
          AI
        </button>
      )}
      {open && (
        <div role="dialog" aria-label="SafeAI help"
          className="fixed bottom-5 right-5 z-40 flex h-[520px] w-[380px] max-w-[calc(100vw-2.5rem)] flex-col overflow-hidden rounded-[20px] border border-line bg-surface shadow-xl">
          <div className="flex items-center justify-between bg-olive px-4 py-3 text-white">
            <div>
              <p className="font-bold">SafeAI</p>
              <p className="text-xs opacity-80">Help with SafeSite</p>
            </div>
            <button onClick={() => setOpen(false)} aria-label="Close" className="rounded-lg px-2 py-1 hover:bg-white/10">✕</button>
          </div>

          <div className="flex-1 space-y-2 overflow-y-auto p-3">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.from === "user" ? "justify-end" : "justify-start"}`}>
                <p className={`max-w-[85%] whitespace-pre-wrap rounded-[14px] px-3 py-2 text-sm ${m.from === "user" ? "bg-olive text-white" : "bg-canvas-alt text-ink"}`}>{m.text}</p>
              </div>
            ))}
            {busy && <p className="px-1 text-xs text-ink-2" role="status">SafeAI is typing…</p>}
            {messages.length === 1 && (
              <div className="flex flex-wrap gap-2 pt-1">
                {SUGGESTIONS.map((s) => (
                  <button key={s} onClick={() => send(s)}
                    className="rounded-full border border-line bg-surface px-3 py-1.5 text-xs font-medium text-ink-2 hover:bg-canvas-alt">{s}</button>
                ))}
              </div>
            )}
            <div ref={bottom} />
          </div>

          <form onSubmit={(e) => { e.preventDefault(); send(input); }} className="flex gap-2 border-t border-line p-3">
            <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask SafeAI…"
              className="min-w-0 flex-1 rounded-[12px] border border-line bg-surface px-3 py-2 text-sm focus:border-navy" />
            <button type="submit" disabled={busy || !input.trim()}
              className="rounded-[12px] bg-olive px-4 py-2 text-sm font-bold text-white disabled:opacity-50">Send</button>
          </form>
        </div>
      )}
    </>
  );
}