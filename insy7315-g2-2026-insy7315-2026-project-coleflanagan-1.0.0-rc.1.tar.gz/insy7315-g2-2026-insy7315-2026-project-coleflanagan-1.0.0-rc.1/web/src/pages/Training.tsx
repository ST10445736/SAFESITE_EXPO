import { useState } from "react";
import { api, useApi } from "../lib/api";
import type { PeopleList, ProjectList, TrainingList } from "../lib/types";
import { fmtDate } from "../lib/format";
import { Avatar, Button, Card, Chips, Empty, ErrorNote, Field, Input, Loading, Modal, PageHeader, Select, StatCard, StatusBadge, Table, Td, Th, useAction } from "../components/ui";

export default function Training() {
  const [status, setStatus] = useState("");
  const [course, setCourse] = useState("");
  const qs = new URLSearchParams({ ...(status && { status }), ...(course && { course }) }).toString();
  const { data, error, loading, reload } = useApi<TrainingList>(`/training?${qs}`);
  const [adding, setAdding] = useState(false);
  return (
    <>
      <PageHeader crumb="Safety" title="Training Records" actions={<Button onClick={() => setAdding(true)}>Record training</Button>} />
      {data && <div className="mb-5 grid gap-4 sm:grid-cols-3">
        <StatCard label="Compliance" tone="ok" value={`${data.compliance}%`} />
        <StatCard label="Valid" value={data.counts.valid} />
        <StatCard label="Needs renewal" tone="warn" value={data.counts.expiringSoon + data.counts.expired} note={`${data.counts.expiringSoon} expiring soon, ${data.counts.expired} expired`} />
      </div>}
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <Chips value={status} onChange={setStatus} options={[
          { value: "", label: "All", count: data?.counts.all }, { value: "VALID", label: "Valid", count: data?.counts.valid },
          { value: "EXPIRING_SOON", label: "Expiring soon", count: data?.counts.expiringSoon }, { value: "EXPIRED", label: "Expired", count: data?.counts.expired },
        ]} />
        <Select aria-label="Course" value={course} onChange={(e) => setCourse(e.target.value)} className="!w-auto">
          <option value="">Course: Any</option>{data?.courses.map((c) => <option key={c}>{c}</option>)}
        </Select>
      </div>
      {error && <ErrorNote message={error} />}
      <Card>
        {loading && !data ? <Loading /> : (
          <Table>
            <thead><tr><Th>Worker</Th><Th>Course</Th><Th>Provider</Th><Th>Completed</Th><Th>Expires</Th><Th>Status</Th></tr></thead>
            <tbody>{data?.items.map((t) => (
              <tr key={t.id}><Td><span className="flex items-center gap-3"><Avatar name={t.worker} /><b>{t.worker}</b></span></Td>
                <Td>{t.course}</Td><Td>{t.provider}</Td><Td>{fmtDate(t.completedOn)}</Td><Td>{fmtDate(t.expiresOn)}</Td><Td><StatusBadge value={t.status} /></Td></tr>
            ))}</tbody>
          </Table>
        )}
        {data && !data.items.length && <Empty>No training records match.</Empty>}
      </Card>
      {adding && <RecordTraining onClose={() => setAdding(false)} onDone={() => { setAdding(false); reload(); }} />}
    </>
  );
}

function RecordTraining({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const people = useApi<PeopleList>("/people");
  const projects = useApi<ProjectList>("/projects");
  const sites = projects.data?.items.flatMap((project) =>
    project.sites.map((site) => ({ ...site, projectName: project.name })),
  ) ?? [];
  const act = useAction();
  const [f, setF] = useState({ siteId: "", userId: "", course: "", provider: "", completedOn: "", expiresOn: "" });
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  return (
    <Modal title="Record training" onClose={onClose}>
      <form className="space-y-3" onSubmit={async (e) => { e.preventDefault(); if (await act.run(() => api("/training", { body: f }))) onDone(); }}>
        <Field label="Site" required>
          <Select required value={f.siteId} onChange={set("siteId")}>
            <option value="">Choose a site…</option>
            {sites.map((site) => <option key={site.id} value={site.id}>{site.name} — {site.projectName}</option>)}
          </Select>
        </Field>
        {projects.error && <ErrorNote message={projects.error} />}
        <Field label="Worker" required><Select required value={f.userId} onChange={set("userId")}><option value="">Choose…</option>{people.data?.items.filter((p) => p.active).map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</Select></Field>
        <Field label="Course" required><Input required value={f.course} onChange={set("course")} /></Field>
        <Field label="Provider" required><Input required value={f.provider} onChange={set("provider")} /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Completed" required><Input required type="date" value={f.completedOn} onChange={set("completedOn")} /></Field>
          <Field label="Expires" required><Input required type="date" value={f.expiresOn} onChange={set("expiresOn")} /></Field>
        </div>
        {act.error && <ErrorNote message={act.error} />}
        <Button type="submit" disabled={act.busy} className="w-full">Save record</Button>
      </form>
    </Modal>
  );
}
