import { useState, type FormEvent } from "react";
import { useSearchParams } from "react-router-dom";
import { api, useApi } from "../lib/api";
import type { Hazard, HazardAction, HazardList, ProjectList } from "../lib/types";
import { fmtDate, fmtDateTime } from "../lib/format";
import { Button, Card, Chips, ErrorNote, Field, Input, Loading, Modal, PageHeader, Select, SeverityBadge, StatCard, StatusBadge, Table, Td, Textarea, Th, Empty, useAction } from "../components/ui";

const CATEGORIES = ["Electrical", "Excavation", "Working at height", "Fire", "Housekeeping", "Plant & vehicles", "Other"];

export default function Hazards() {
  const [params, setParams] = useSearchParams();
  const [status, setStatus] = useState("");
  const [severity, setSeverity] = useState("");
  const [q, setQ] = useState("");
  const [reporting, setReporting] = useState(false);
  const qs = new URLSearchParams({ ...(status && { status }), ...(severity && { severity }), ...(q && { q }) }).toString();
  const { data, error, loading, reload } = useApi<HazardList>(`/hazards?${qs}`);
  const openId = params.get("id");

  return (
    <>
      <PageHeader crumb="Safety" title="Hazard Register" actions={<Button onClick={() => setReporting(true)}>Report hazard</Button>} />
      {data && (
        <div className="mb-5 grid gap-4 sm:grid-cols-3">
          <StatCard label="Open" value={data.counts.open} />
          <StatCard label="In progress" tone="warn" value={data.counts.inProgress} />
          <StatCard label="Closed (30 days)" tone="ok" value={data.counts.closedLast30} />
        </div>
      )}
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <Chips value={status} onChange={setStatus} options={[
          { value: "", label: "All", count: data?.counts.all }, { value: "OPEN", label: "Open", count: data?.counts.open },
          { value: "IN_PROGRESS", label: "In progress", count: data?.counts.inProgress }, { value: "CLOSED", label: "Closed", count: data?.counts.closed },
        ]} />
        <div className="flex gap-2">
          <Select aria-label="Severity" value={severity} onChange={(e) => setSeverity(e.target.value)} className="!w-auto">
            <option value="">Severity: Any</option>{["CRITICAL", "HIGH", "MEDIUM", "LOW"].map((s) => <option key={s} value={s}>{s[0] + s.slice(1).toLowerCase()}</option>)}
          </Select>
          <Input aria-label="Search hazards" placeholder="Search hazards" value={q} onChange={(e) => setQ(e.target.value)} className="!w-56" />
        </div>
      </div>

      {error && <ErrorNote message={error} />}
      <Card>
        {loading && !data ? <Loading /> : (
          <Table>
            <thead><tr><Th>Hazard</Th><Th>Category</Th><Th>Severity</Th><Th>Reported</Th><Th>Actions</Th><Th>Status</Th></tr></thead>
            <tbody>
              {data?.items.map((h) => (
                <tr key={h.id} onClick={() => setParams({ id: String(h.id) })} className="cursor-pointer hover:bg-canvas">
                  <Td><button className="text-left font-bold hover:underline" onClick={(e) => { e.stopPropagation(); setParams({ id: String(h.id) }); }}>{h.title}</button>
                    <div className="text-xs text-ink-2">{h.location}</div></Td>
                  <Td>{h.category}</Td><Td><SeverityBadge value={h.severity} /></Td>
                  <Td>{fmtDateTime(h.reportedAt)}<div className="text-xs text-ink-2">{h.reportedBy}</div></Td>
                  <Td>{h.actionsDone} of {h.actionsTotal} done</Td><Td><StatusBadge value={h.status} /></Td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
        {data && !data.items.length && <Empty>No hazards match these filters.</Empty>}
      </Card>

      {openId && <HazardDrawer id={openId} onClose={() => setParams({})} onChanged={reload} />}
      {reporting && <ReportHazard onClose={() => setReporting(false)} onDone={() => { setReporting(false); reload(); }} />}
    </>
  );
}

function HazardDrawer({ id, onClose, onChanged }: { id: string; onClose: () => void; onChanged: () => void }) {
  const { data, error, reload } = useApi<Hazard & { actions: HazardAction[] }>(`/hazards/${id}`);
  const act = useAction();
  const [desc, setDesc] = useState("");
  const [due, setDue] = useState("");
  const refresh = () => { reload(); onChanged(); };

  const add = async (e: FormEvent) => {
    e.preventDefault();
    if (await act.run(() => api(`/hazards/${id}/actions`, { body: { description: desc, dueOn: due } }))) { setDesc(""); setDue(""); refresh(); }
  };
  const toggle = async (a: HazardAction) => { if (await act.run(() => api(`/hazards/${id}/actions/${a.id}`, { method: "PATCH", body: { done: !a.done } }))) refresh(); };
  const close = async () => { if (await act.run(() => api(`/hazards/${id}/close`, { method: "POST", body: {} }))) refresh(); };

  const remaining = data ? data.actions.filter((a) => !a.done).length : 0;
  return (
    <div className="fixed inset-0 z-40 flex justify-end bg-night/40" onClick={onClose}>
      <aside role="dialog" aria-label="Hazard detail" className="h-full w-full max-w-lg overflow-y-auto bg-surface p-6 shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between gap-4">
          <h2 className="text-xl font-bold">{data?.title ?? "Hazard"}</h2>
          <button onClick={onClose} aria-label="Close" className="rounded-lg px-2 py-1 text-ink-2 hover:bg-canvas-alt">✕</button>
        </div>
        {error && <ErrorNote message={error} />}
        {data && (
          <div className="mt-4 space-y-5">
            <div className="flex flex-wrap gap-2"><SeverityBadge value={data.severity} /><StatusBadge value={data.status} /></div>
            <dl className="grid grid-cols-2 gap-3 text-sm">
              <div><dt className="text-ink-2">Location</dt><dd className="font-medium">{data.location}</dd></div>
              <div><dt className="text-ink-2">Category</dt><dd className="font-medium">{data.category}</dd></div>
              <div><dt className="text-ink-2">Reported</dt><dd className="font-medium">{fmtDateTime(data.reportedAt)}</dd></div>
              <div><dt className="text-ink-2">Reported by</dt><dd className="font-medium">{data.reportedBy}</dd></div>
            </dl>
            {data.description && <p className="text-sm text-ink-2">{data.description}</p>}

            <div>
              <h3 className="mb-2 font-bold">Corrective actions ({data.actionsDone} of {data.actionsTotal} done)</h3>
              {!data.actions.length && <p className="text-sm text-ink-2">No actions yet. Add one so the hazard can be fixed and closed.</p>}
              <ul className="space-y-2">
                {data.actions.map((a) => (
                  <li key={a.id} className="flex items-start gap-3 rounded-[12px] border border-line p-3">
                    <input type="checkbox" checked={!!a.done} disabled={data.status === "CLOSED" || act.busy} onChange={() => toggle(a)} aria-label={`Mark done: ${a.description}`} className="mt-1 h-4 w-4 accent-[#4A6741]" />
                    <div className="text-sm"><p className={a.done ? "text-ink-2 line-through" : "font-medium"}>{a.description}</p>
                      <p className="text-xs text-ink-2">Due {fmtDate(a.dueOn)}{a.doneAt && ` · done ${fmtDate(a.doneAt)}`}</p></div>
                  </li>
                ))}
              </ul>
            </div>

            {data.status !== "CLOSED" && (
              <form onSubmit={add} className="space-y-3 rounded-[12px] bg-canvas p-4">
                <Field label="New corrective action"><Input required minLength={3} value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="What must be done?" /></Field>
                <Field label="Due date"><Input required type="date" value={due} onChange={(e) => setDue(e.target.value)} /></Field>
                <Button type="submit" variant="secondary" disabled={act.busy}>Add action</Button>
              </form>
            )}
            {act.error && <ErrorNote message={act.error} />}
            {data.status !== "CLOSED" ? (
              <div>
                <Button onClick={close} disabled={act.busy || remaining > 0 || !data.actions.length} className="w-full">Close hazard</Button>
                {(remaining > 0 || !data.actions.length) && <p className="mt-2 text-xs text-ink-2">A hazard can't be closed until it has actions and every action is done.</p>}
              </div>
            ) : <p className="text-sm font-medium text-ok">Closed {data.closedAt && fmtDate(data.closedAt)}</p>}
          </div>
        )}
      </aside>
    </div>
  );
}

function ReportHazard({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const act = useAction();
  const projects = useApi<ProjectList>("/projects");
  const sites = projects.data?.items.flatMap((project) =>
    project.sites.map((site) => ({ ...site, projectName: project.name })),
  ) ?? [];
  const [f, setF] = useState({ siteId: "", title: "", location: "", category: CATEGORIES[0], severity: "MEDIUM", description: "" });
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  return (
    <Modal title="Report a hazard" onClose={onClose}>
      <form className="space-y-3" onSubmit={async (e) => { e.preventDefault(); if (await act.run(() => api("/hazards", { body: f }))) onDone(); }}>
        <Field label="Site" required>
          <Select required value={f.siteId} onChange={set("siteId")}>
            <option value="">Choose a site…</option>
            {sites.map((site) => <option key={site.id} value={site.id}>{site.name} — {site.projectName}</option>)}
          </Select>
        </Field>
        {projects.error && <ErrorNote message={projects.error} />}
        <Field label="What is the hazard?" required><Input required minLength={3} value={f.title} onChange={set("title")} /></Field>
        <Field label="Where?" required><Input required value={f.location} onChange={set("location")} placeholder="e.g. Block A, ground floor" /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Category"><Select value={f.category} onChange={set("category")}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</Select></Field>
          <Field label="Severity"><Select value={f.severity} onChange={set("severity")}>{["LOW", "MEDIUM", "HIGH", "CRITICAL"].map((s) => <option key={s} value={s}>{s[0] + s.slice(1).toLowerCase()}</option>)}</Select></Field>
        </div>
        <Field label="Details"><Textarea value={f.description} onChange={set("description")} /></Field>
        {act.error && <ErrorNote message={act.error} />}
        <Button type="submit" disabled={act.busy} className="w-full">Report hazard</Button>
      </form>
    </Modal>
  );
}
