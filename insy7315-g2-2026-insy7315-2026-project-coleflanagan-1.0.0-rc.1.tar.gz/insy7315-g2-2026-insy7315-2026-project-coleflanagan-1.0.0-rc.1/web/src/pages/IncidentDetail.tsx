import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { api, useApi } from "../lib/api";
import type { Incident, IncidentStatus } from "../lib/types";
import { fmtDateTime } from "../lib/format";
import { Button, Card, ErrorNote, Field, Loading, PageHeader, StatusBadge, Textarea, useAction } from "../components/ui";

const STEPS: { key: IncidentStatus; label: string; time: keyof Incident["timeline"] }[] = [
  { key: "REPORTED", label: "Reported", time: "reported" }, { key: "INVESTIGATING", label: "Investigating", time: "investigating" },
  { key: "ACTIONS", label: "Actions", time: "actions" }, { key: "CLOSED", label: "Closed", time: "closed" },
];

export default function IncidentDetail() {
  const { id } = useParams();
  const { data: i, error, reload } = useApi<Incident>(`/incidents/${id}`);
  const act = useAction();
  const [form, setForm] = useState({ rootCause: "", findings: "", actionsRequired: "" });
  const [saved, setSaved] = useState(false);

  useEffect(() => { if (i) setForm({ rootCause: i.rootCause ?? "", findings: i.findings ?? "", actionsRequired: i.actionsRequired ?? "" }); }, [i?.id, i?.status]);

  if (error) return <ErrorNote message={error} />;
  if (!i) return <Loading />;
  const current = STEPS.findIndex((s) => s.key === i.status);
  const post = async (path: string, body: unknown = {}, method = "POST") => { if (await act.run(() => api(`/incidents/${id}/${path}`, { method, body }))) reload(); };

  return (
    <>
      <PageHeader crumb={<><Link to="/portal/incidents" className="hover:underline">Incidents</Link> / {i.code}</>} title={i.title} />
      <div className="space-y-5">
        <Card className="p-6">
          <ol className="grid grid-cols-4 gap-2">
            {STEPS.map((s, n) => {
              const done = n < current || i.status === "CLOSED";
              const now = n === current && i.status !== "CLOSED";
              return (
                <li key={s.key} className="flex flex-col items-center text-center" aria-current={now ? "step" : undefined}>
                  <span className={`grid h-9 w-9 place-items-center rounded-full border-2 text-sm font-bold ${done ? "border-ok bg-ok-light text-ok" : now ? "border-olive bg-olive-pale text-olive-dark" : "border-line text-ink-3"}`}>{done ? "✓" : n + 1}</span>
                  <span className="mt-2 text-sm font-bold">{s.label}</span>
                  <span className="text-xs text-ink-2">{i.timeline[s.time] ? fmtDateTime(i.timeline[s.time]!) : "–"}</span>
                </li>
              );
            })}
          </ol>
        </Card>

        <Card className="p-6">
          <h2 className="mb-2 font-bold">What happened</h2>
          <p className="text-sm text-ink-2">{i.description}</p>
          <dl className="mt-5 grid gap-4 text-sm sm:grid-cols-4">
            {[["Type", i.type], ["Location", i.location], ["Occurred", fmtDateTime(i.occurredAt)], ["Injured", i.injured ? "Yes" : "Nobody"], ["Witnesses", i.witnesses || "–"], ["Reported by", i.reportedBy], ["Investigator", i.investigator ?? "Not assigned"]].map(([k, v]) => (
              <div key={k}><dt className="text-ink-2">{k}</dt><dd className="font-bold">{v}</dd></div>
            ))}
            <div><dt className="text-ink-2">Stage</dt><dd><StatusBadge value={i.status} /></dd></div>
          </dl>
        </Card>

        {act.error && <ErrorNote message={act.error} />}

        {i.status === "REPORTED" && (
          <Card className="flex items-center justify-between gap-4 p-6">
            <div><h2 className="font-bold">Next step: start the investigation</h2><p className="text-sm text-ink-2">You will be recorded as the investigator.</p></div>
            <Button onClick={() => post("investigate")} disabled={act.busy}>Start investigation</Button>
          </Card>
        )}

        {i.status === "INVESTIGATING" && (
          <Card className="p-6">
            <div className="mb-4 flex items-center justify-between"><h2 className="font-bold">Next step: record findings</h2><span className="text-sm text-ink-2">Moves the incident to Actions</span></div>
            <div className="space-y-4">
              <Field label="Root cause" required><Textarea value={form.rootCause} onChange={(e) => setForm({ ...form, rootCause: e.target.value })} /></Field>
              <Field label="Findings"><Textarea placeholder="Describe what the investigation found" value={form.findings} onChange={(e) => setForm({ ...form, findings: e.target.value })} /></Field>
              <Field label="Actions required" required><Textarea placeholder="List what must change before this can close" value={form.actionsRequired} onChange={(e) => setForm({ ...form, actionsRequired: e.target.value })} /></Field>
              <div className="flex items-center justify-end gap-3">
                {saved && <span className="text-sm text-ok" role="status">Draft saved</span>}
                <Button variant="secondary" disabled={act.busy} onClick={async () => { if (await act.run(() => api(`/incidents/${id}/draft`, { method: "PUT", body: form }))) { setSaved(true); setTimeout(() => setSaved(false), 2000); } }}>Save draft</Button>
                <Button disabled={act.busy || form.rootCause.trim().length < 3 || form.actionsRequired.trim().length < 3} onClick={() => post("findings", form)}>Submit findings</Button>
              </div>
            </div>
          </Card>
        )}

        {(i.status === "ACTIONS" || i.status === "CLOSED") && (
          <Card className="p-6">
            <h2 className="mb-3 font-bold">Findings</h2>
            <dl className="space-y-3 text-sm">
              <div><dt className="text-ink-2">Root cause</dt><dd className="font-medium">{i.rootCause}</dd></div>
              {i.findings && <div><dt className="text-ink-2">Findings</dt><dd>{i.findings}</dd></div>}
              <div><dt className="text-ink-2">Actions required</dt><dd>{i.actionsRequired}</dd></div>
            </dl>
            {i.status === "ACTIONS" && <div className="mt-5 flex justify-end"><Button onClick={() => post("close")} disabled={act.busy}>Close incident</Button></div>}
          </Card>
        )}
      </div>
    </>
  );
}
