import { Link } from "react-router-dom";
import { Logo } from "../components/Logo";
import { Icon, type IconName } from "../components/ui";

// TODO: replace with the real sales / contact address
const DEMO_LINK = `mailto:${import.meta.env.VITE_CONTACT_EMAIL ?? "hello@example.com"}?subject=SafeSite%20demo%20request`;

const FEATURES: { icon: IconName; title: string; text: string }[] = [
  { icon: "check-in", title: "Check-in & headcount", text: "Workers check in and out at their assigned site. Supervisors see a live headcount, so everyone is accounted for in an emergency." },
  { icon: "tasks", title: "Daily safety checklists", text: "Pre-start checklists submitted from the site and reviewed by the supervisor, with incomplete items flagged." },
  { icon: "hazard", title: "Hazards & corrective actions", text: "Report a hazard in seconds. Assign fixes with due dates. A hazard can't be closed until every action is done." },
  { icon: "incident", title: "Incident lifecycle", text: "Reported, investigated, actions, closed. Every step is enforced in order and recorded on the timeline." },
];
const ROLES = [
  { tag: "Mobile app", name: "Worker / Subcontractor", items: ["Check in and out of site", "Submit daily safety checklist", "Upload PPE photos", "View and update assigned tasks"] },
  { tag: "App + portal", name: "Site Supervisor", items: ["Live headcount per site", "Review checklists", "Approve or reject PPE", "Create and assign tasks"] },
  { tag: "Web portal", name: "Safety Officer", items: ["Safety dashboard and KPIs", "Hazard register", "Incident investigations", "Training records"] },
  { tag: "Web portal", name: "Administrator", items: ["People and roles", "Projects and sites", "Full audit history", "One-click exports"] },
];
const STEPS = [
  { name: "Set up your sites", text: "Admins create projects, add sites and invite people with the right role. Accounts are ready in minutes." },
  { name: "Work safely every day", text: "Workers check in, complete the daily checklist and verify PPE before starting. Hazards are reported the moment they're seen." },
  { name: "Review and report", text: "Safety officers investigate incidents, close out hazards and export records for clients and auditors." },
];

export default function Landing() {
  return (
    <div className="bg-surface">
      <header className="sticky top-0 z-30 border-b border-line bg-surface/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-3">
          <Link to="/" aria-label="SafeSite home" className="flex items-center gap-3"><Logo height={40} /><span className="hidden text-xs text-ink-2 sm:block">by Singo Investment Holdings</span></Link>
          <nav aria-label="Site" className="hidden gap-7 text-sm font-medium text-ink-2 md:flex">
            {["features", "roles", "how-it-works", "compliance"].map((id) => <a key={id} href={`#${id}`} className="hover:text-ink">{id === "how-it-works" ? "How it works" : id[0].toUpperCase() + id.slice(1)}</a>)}
          </nav>
          <div className="flex items-center gap-2">
            <Link to="/portal/sign-in" className="rounded-[12px] px-4 py-2 text-sm font-bold text-ink hover:bg-canvas-alt">Portal sign in</Link>
            <a href={DEMO_LINK} className="hidden rounded-[12px] bg-olive px-4 py-2 text-sm font-bold text-white hover:bg-olive-light sm:block">Request a demo</a>
          </div>
        </div>
      </header>

      <section className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-16 lg:grid-cols-[1.1fr_0.9fr] lg:py-24">
        <div>
          <p className="mb-4 text-sm font-bold text-olive-dark">Built for South African construction sites</p>
          <h1 className="text-5xl font-extrabold leading-[1.05] tracking-tight sm:text-6xl">Every worker on site. Every hazard closed out.</h1>
          <p className="mt-6 max-w-xl text-lg text-ink-2">SafeSite brings attendance, daily safety checklists, PPE, hazards, incidents and training into one app for workers on the ground and one portal for the people who keep them safe.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href={DEMO_LINK} className="rounded-[14px] bg-olive px-6 py-3 font-bold text-white hover:bg-olive-light">Request a demo</a>
            <a href="#how-it-works" className="rounded-[14px] border border-line px-6 py-3 font-bold hover:bg-canvas-alt">See how it works</a>
          </div>
          <dl className="mt-10 flex flex-wrap gap-x-10 gap-y-4">
            {[["4 roles", "one shared system"], ["100%", "audit trail"], ["Android + Web", "site to office"]].map(([a, b]) => <div key={a}><dt className="text-xl font-extrabold">{a}</dt><dd className="text-sm text-ink-2">{b}</dd></div>)}
          </dl>
        </div>
        <div className="rounded-[24px] border border-line bg-canvas p-5 shadow-sm" aria-hidden>
          <p className="mb-3 text-sm font-bold">Needs attention</p>
          {[["Exposed wiring at DB board", "Block A, ground floor", "Critical", "bg-danger-light text-danger"], ["Unbarricaded excavation", "North boundary trench", "High", "bg-warn-light text-warn-dark"], ["Loose scaffolding plank", "Block B, level 2", "Closed", "bg-ok-light text-ok"]].map(([t, l, s, c]) => (
            <div key={t} className="mb-2 flex items-center justify-between rounded-[14px] border border-line bg-surface p-4">
              <div><p className="text-sm font-bold">{t}</p><p className="text-xs text-ink-2">{l}</p></div>
              <span className={`rounded-full px-2.5 py-0.5 text-xs font-bold ${c}`}>{s}</span>
            </div>
          ))}
          <div className="mt-3 grid grid-cols-2 gap-2">
            <div className="rounded-[14px] border border-line bg-surface p-4"><p className="text-3xl font-extrabold text-ok">42</p><p className="text-xs text-ink-2">days since last injury</p></div>
            <div className="rounded-[14px] border border-line bg-surface p-4"><p className="text-3xl font-extrabold text-navy">94%</p><p className="text-xs text-ink-2">training compliance</p></div>
          </div>
        </div>
      </section>

      <section id="features" className="scroll-mt-20 bg-canvas py-20">
        <div className="mx-auto max-w-6xl px-5">
          <h2 className="max-w-xl text-4xl font-extrabold tracking-tight">One system from the gate to the boardroom</h2>
          <p className="mt-3 max-w-xl text-ink-2">Workers use the Android app on site. Supervisors, safety officers and administrators get the full picture in the web portal.</p>
          <div className="mt-10 grid gap-4 sm:grid-cols-2">
            {FEATURES.map((f) => (
              <div key={f.title} className="rounded-[18px] border border-line bg-surface p-6">
                <span className="grid h-11 w-11 place-items-center rounded-[12px] bg-olive-pale text-olive-dark"><Icon name={f.icon} size={22} /></span>
                <h3 className="mt-4 text-lg font-bold">{f.title}</h3><p className="mt-1 text-ink-2">{f.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="roles" className="scroll-mt-20 py-20">
        <div className="mx-auto max-w-6xl px-5">
          <h2 className="max-w-xl text-4xl font-extrabold tracking-tight">The right tools for every person on site</h2>
          <p className="mt-3 text-ink-2">Each role sees exactly what they need and nothing they shouldn't.</p>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {ROLES.map((r) => (
              <div key={r.name} className="rounded-[18px] border border-line p-6">
                <p className="text-sm font-bold text-navy">{r.tag}</p><h3 className="mt-1 text-lg font-bold">{r.name}</h3>
                <ul className="mt-4 space-y-2 text-sm text-ink-2">{r.items.map((i) => <li key={i} className="flex gap-2"><span className="font-bold text-olive">✓</span>{i}</li>)}</ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="how-it-works" className="scroll-mt-20 bg-canvas py-20">
        <div className="mx-auto max-w-6xl px-5">
          <h2 className="text-4xl font-extrabold tracking-tight">From site gate to safety report</h2>
          <ol className="mt-10 grid gap-8 md:grid-cols-3">
            {STEPS.map((s, n) => (
              <li key={s.name} className="border-t-4 border-olive pt-4"><p className="text-sm font-bold text-olive-dark">Step {n + 1}</p><h3 className="mt-1 text-xl font-bold">{s.name}</h3><p className="mt-2 text-ink-2">{s.text}</p></li>
            ))}
          </ol>
        </div>
      </section>

      <section id="compliance" className="scroll-mt-20 py-20">
        <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 lg:grid-cols-2">
          <div>
            <h2 className="text-4xl font-extrabold tracking-tight">Every action, on the record</h2>
            <ul className="mt-8 space-y-5">
              {[["Full audit trail", "Who did what, to what, and when, across hazards, incidents, training, people and sites."], ["Rules that can't be skipped", "Hazards stay open until actions are done. Incidents move through every stage in order."], ["Export in one click", "Download the audit log, hazard register, incident register or training records as CSV."]].map(([t, d]) => (
                <li key={t} className="flex gap-3"><span className="mt-0.5 font-bold text-olive">✓</span><div><p className="font-bold">{t}</p><p className="text-ink-2">{d}</p></div></li>
              ))}
            </ul>
          </div>
          <div className="rounded-[20px] border border-line bg-canvas p-5" aria-hidden>
            <p className="mb-2 text-sm font-bold">Audit history</p>
            {[["Hazard closed", "text-warn-dark"], ["Incident closed", "text-danger"], ["Training recorded", "text-ok"], ["Assignment started", "text-navy"], ["Role changed", "text-olive-dark"]].map(([a, c]) => <p key={a} className={`border-t border-line py-3 text-sm font-bold ${c}`}>{a}</p>)}
          </div>
        </div>
      </section>

      <section className="bg-night px-5 py-20 text-center text-white">
        <h2 className="mx-auto max-w-2xl text-4xl font-extrabold tracking-tight">Ready to make every site a SafeSite?</h2>
        <p className="mx-auto mt-3 max-w-lg text-white/70">See the app and the portal working together on your own projects.</p>
        <a href={DEMO_LINK} className="mt-8 inline-block rounded-[14px] bg-olive px-7 py-3 font-bold text-white hover:bg-olive-light">Request a demo</a>
      </section>

      <footer className="bg-night px-5 pb-10 text-white/70">
        <div className="mx-auto max-w-6xl border-t border-white/10 pt-8">
          <Logo onDark height={28} />
          <p className="mt-3 max-w-sm text-sm">Construction site safety management for workers, supervisors, safety officers and administrators.</p>
          <p className="mt-8 text-xs">© {new Date().getFullYear()} Singo Investment Holdings. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
