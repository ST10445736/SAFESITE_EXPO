import { useState } from "react";
import { api, useApi } from "../lib/api";
import type { ProjectList } from "../lib/types";
import { fmtDate } from "../lib/format";
import { Button, Card, Chips, Empty, ErrorNote, Field, Input, Loading, Modal, PageHeader, StatusBadge, useAction } from "../components/ui";

export default function Projects() {
  const [status, setStatus] = useState("");
  const { data, error, loading, reload } = useApi<ProjectList>("/projects");
  const [modal, setModal] = useState<null | { kind: "project" } | { kind: "site"; projectId: string }>(null);
  const rows = data?.items.filter((p) => !status || p.status === status) ?? [];
  return (
    <>
      <PageHeader crumb="Manage" title="Projects & Sites" actions={<Button onClick={() => setModal({ kind: "project" })}>New project</Button>} />
      <div className="mb-4"><Chips value={status} onChange={setStatus} options={[
        { value: "", label: "All", count: data?.counts.all }, { value: "ACTIVE", label: "Active", count: data?.counts.active },
        { value: "ON_HOLD", label: "On hold", count: data?.counts.onHold }, { value: "COMPLETED", label: "Completed", count: data?.counts.completed },
      ]} /></div>
      {error && <ErrorNote message={error} />}
      {loading && !data && <Loading />}
      <div className="space-y-4">
        {rows.map((p) => (
          <Card key={p.id} className="p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div><h2 className="text-lg font-bold">{p.name}</h2><p className="text-sm text-ink-2">{p.client} · started {fmtDate(p.startedOn)}</p></div>
              <StatusBadge value={p.status} />
            </div>
            <p className="mt-3 text-sm"><b>{p.sites.length}</b> {p.sites.length === 1 ? "site" : "sites"} · <b>{p.peopleAssigned}</b> people assigned · <b className={p.openHazards ? "text-danger" : ""}>{p.openHazards}</b> open {p.openHazards === 1 ? "hazard" : "hazards"}</p>
            <ul className="mt-3 divide-y divide-line-soft border-t border-line-soft text-sm">
              {p.sites.map((s) => <li key={s.id} className="py-2"><b>{s.name}</b>{s.address && <span className="text-ink-2"> · {s.address}</span>}</li>)}
            </ul>
            <Button variant="secondary" className="mt-3" onClick={() => setModal({ kind: "site", projectId: p.id })}>Add site</Button>
          </Card>
        ))}
        {data && !rows.length && <Empty>No projects here.</Empty>}
      </div>
      {modal && <ProjectModal modal={modal} onClose={() => setModal(null)} onDone={() => { setModal(null); reload(); }} />}
    </>
  );
}

function ProjectModal({ modal, onClose, onDone }: { modal: { kind: "project" } | { kind: "site"; projectId: string }; onClose: () => void; onDone: () => void }) {
  const act = useAction();
  const [f, setF] = useState({ name: "", client: "", startedOn: new Date().toISOString().slice(0, 10), address: "" });
  const isSite = modal.kind === "site";
  return (
    <Modal title={isSite ? "Add a site" : "New project"} onClose={onClose}>
      <form className="space-y-3" onSubmit={async (e) => {
        e.preventDefault();
        const call = isSite ? api(`/projects/${modal.projectId}/sites`, { body: { name: f.name, address: f.address } }) : api("/projects", { body: { name: f.name, client: f.client, startedOn: f.startedOn } });
        if (await act.run(() => call)) onDone();
      }}>
        <Field label={isSite ? "Site name" : "Project name"} required><Input required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
        {isSite ? <Field label="Address"><Input value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} /></Field> : <>
          <Field label="Client" required><Input required value={f.client} onChange={(e) => setF({ ...f, client: e.target.value })} /></Field>
          <Field label="Start date" required><Input required type="date" value={f.startedOn} onChange={(e) => setF({ ...f, startedOn: e.target.value })} /></Field></>}
        {act.error && <ErrorNote message={act.error} />}
        <Button type="submit" disabled={act.busy} className="w-full">Save</Button>
      </form>
    </Modal>
  );
}
