import { useEffect, useState } from "react";
import { getApp } from "firebase/app";
import { collection, getDocs, getFirestore } from "firebase/firestore";
import { Badge, Card, Chips, Empty, ErrorNote, Loading, PageHeader } from "../components/ui";
import "../lib/firebase";

type Row = {
  id: string; workerName: string; photoUrl: string; status: string;
  aiVerdict: string; aiReason: string; submittedAt: number;
};

const VERDICT = {
  compliant: { label: "AI: PPE looks compliant", tone: "ok" },
  non_compliant: { label: "AI: PPE issue spotted", tone: "danger" },
  unclear: { label: "AI: photo unclear", tone: "warn" },
} as const;

export default function Ppe() {
  const [rows, setRows] = useState<Row[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const db = getFirestore(getApp());
        const [ppe, users] = await Promise.all([getDocs(collection(db, "ppe_submissions")), getDocs(collection(db, "users"))]);
        const names = new Map(users.docs.map((d) => [d.id, String(d.data().fullName ?? d.data().email ?? "Worker")]));
        const list = ppe.docs.map((d) => {
          const x = d.data();
          return {
            id: d.id, workerName: names.get(String(x.workerId)) ?? "Worker", photoUrl: String(x.photoUrl ?? ""),
            status: String(x.status ?? "pending"), aiVerdict: String(x.aiVerdict ?? ""), aiReason: String(x.aiReason ?? ""),
            submittedAt: Number(x.submittedAt ?? x.createdAt ?? 0),
          };
        }).sort((a, b) => b.submittedAt - a.submittedAt);
        setRows(list);
      } catch (e) {
        setError((e as Error).message);
      }
    })();
  }, []);

  const flagged = (r: Row) => r.aiVerdict === "non_compliant" || r.aiVerdict === "unclear";
  const shown = (rows ?? []).filter((r) => !filter || (filter === "flagged" ? flagged(r) : r.aiVerdict === filter));
  const count = (f: (r: Row) => boolean) => (rows ?? []).filter(f).length;

  return (
    <>
      <PageHeader crumb="Safety" title="PPE Review" />
      <p className="mb-4 text-sm text-ink-2">AI pre-screens each PPE photo. It is advisory only: supervisors make the final approve or reject decision in the app.</p>
      <div className="mb-4">
        <Chips value={filter} onChange={setFilter} options={[
          { value: "", label: "All", count: rows?.length },
          { value: "flagged", label: "AI flagged", count: count(flagged) },
          { value: "compliant", label: "Looks compliant", count: count((r) => r.aiVerdict === "compliant") },
        ]} />
      </div>
      {error && <ErrorNote message={error} />}
      {!rows && !error && <Loading />}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {shown.map((r) => {
          const v = VERDICT[r.aiVerdict as keyof typeof VERDICT];
          return (
            <Card key={r.id} className="overflow-hidden">
              {r.photoUrl && <img src={r.photoUrl} alt={`PPE photo from ${r.workerName}`} className="h-48 w-full object-cover" />}
              <div className="space-y-2 p-4">
                <div className="flex items-center justify-between gap-2">
                  <b>{r.workerName}</b>
                  <Badge tone={r.status === "approved" ? "ok" : r.status === "rejected" ? "danger" : "warn"}>{r.status}</Badge>
                </div>
                <Badge tone={v ? v.tone : "neutral"}>{v ? v.label : "AI check unavailable"}</Badge>
                {r.aiReason && <p className="text-sm text-ink-2">{r.aiReason}</p>}
                {r.submittedAt > 0 && <p className="text-xs text-ink-3">{new Date(r.submittedAt).toLocaleString()}</p>}
              </div>
            </Card>
          );
        })}
      </div>
      {rows && !shown.length && <Empty>No PPE submissions match.</Empty>}
    </>
  );
}