import { useState } from "react";
import { downloadCsv } from "../lib/api";
import { Button, Card, ErrorNote, PageHeader } from "../components/ui";
import { useAuth } from "../lib/auth";

const ALL = [
  { kind: "hazards", title: "Hazard register", text: "Every hazard with severity, status and who reported it." },
  { kind: "incidents", title: "Incident register", text: "All incidents with stage, root cause and injury flag." },
  { kind: "training", title: "Training records", text: "Courses, providers and expiry dates per worker." },
  { kind: "audit", title: "Audit log", text: "Who did what, to what, and when.", admin: true },
];

export default function Exports() {
  const { user } = useAuth();
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  return (
    <>
      <PageHeader crumb="Reports" title="Exports" />
      {error && <ErrorNote message={error} />}
      <div className="grid gap-4 sm:grid-cols-2">
        {ALL.filter((e) => !e.admin || user?.role === "ADMIN").map((e) => (
          <Card key={e.kind} className="flex flex-col justify-between gap-4 p-5">
            <div><h2 className="font-bold">{e.title}</h2><p className="mt-1 text-sm text-ink-2">{e.text}</p></div>
            <Button variant="secondary" className="self-start" disabled={busy === e.kind}
              onClick={async () => { setBusy(e.kind); setError(null); try { await downloadCsv(e.kind); } catch (x) { setError((x as Error).message); } finally { setBusy(null); } }}>
              {busy === e.kind ? "Preparing…" : "Download CSV"}
            </Button>
          </Card>
        ))}
      </div>
    </>
  );
}
