import { useState } from "react";
import { Link } from "react-router-dom";
import { api, useApi } from "../lib/api";
import type { Incident, ProjectList } from "../lib/types";
import { fmtDateTime } from "../lib/format";
import { Button, Card, Chips, Empty, ErrorNote, Field, Input, Loading, Modal, PageHeader, Select, StatusBadge, Table, Td, Textarea, Th, useAction } from "../components/ui";

export default function Incidents() {
  const [status, setStatus] = useState("");
  const { data, error, loading, reload } = useApi<{ items: Incident[] }>(`/incidents${status ? `?status=${status}` : ""}`);
  const [adding, setAdding] = useState(false);
  return (
    <>
      <PageHeader crumb="Safety" title="Incidents" actions={<Button onClick={() => setAdding(true)}>Report incident</Button>} />
      <div className="mb-4"><Chips value={status} onChange={setStatus} options={[
        { value: "", label: "All" }, { value: "REPORTED", label: "Reported" }, { value: "INVESTIGATING", label: "Investigating" }, { value: "ACTIONS", label: "Actions" }, { value: "CLOSED", label: "Closed" },
      ]} /></div>
      {error && <ErrorNote message={error} />}
      <Card>
        {loading && !data ? <Loading /> : (
          <Table>
            <thead><tr><Th>Incident</Th><Th>Type</Th><Th>Occurred</Th><Th>Injury</Th><Th>Stage</Th></tr></thead>
            <tbody>
              {data?.items.map((i) => (
                <tr key={i.id} className="hover:bg-canvas">
                  <Td><Link to={`/portal/incidents/${i.id}`} className="font-bold hover:underline">{i.title}</Link><div className="text-xs text-ink-2">{i.code} · {i.location}</div></Td>
                  <Td>{i.type}</Td><Td>{fmtDateTime(i.occurredAt)}</Td><Td>{i.injured ? "Yes" : "No"}</Td><Td><StatusBadge value={i.status} /></Td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
        {data && !data.items.length && <Empty>No incidents here.</Empty>}
      </Card>
      {adding && <ReportIncident onClose={() => setAdding(false)} onDone={() => { setAdding(false); reload(); }} />}
    </>
  );
}

function ReportIncident({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const act = useAction();
  const projects = useApi<ProjectList>("/projects");
  const sites = projects.data?.items.flatMap((project) =>
    project.sites.map((site) => ({ ...site, projectName: project.name })),
  ) ?? [];
  const [f, setF] = useState({ siteId: "", title: "", type: "Near miss", location: "", description: "", occurredAt: new Date().toISOString().slice(0, 16), witnesses: "", injured: false });
  return (
    <Modal title="Report an incident" onClose={onClose}>
      <form className="space-y-3" onSubmit={async (e) => {
        e.preventDefault();
        if (await act.run(() => api("/incidents", { body: { ...f, occurredAt: new Date(f.occurredAt).toISOString() } }))) onDone();
      }}>
        <Field label="Site" required>
          <Select required value={f.siteId} onChange={(e) => setF({ ...f, siteId: e.target.value })}>
            <option value="">Choose a site…</option>
            {sites.map((site) => <option key={site.id} value={site.id}>{site.name} — {site.projectName}</option>)}
          </Select>
        </Field>
        {projects.error && <ErrorNote message={projects.error} />}
        <Field label="Title" required><Input required minLength={3} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Type"><Input value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })} /></Field>
          <Field label="Occurred" required><Input required type="datetime-local" value={f.occurredAt} onChange={(e) => setF({ ...f, occurredAt: e.target.value })} /></Field>
        </div>
        <Field label="Location" required><Input required value={f.location} onChange={(e) => setF({ ...f, location: e.target.value })} /></Field>
        <Field label="What happened?" required><Textarea required minLength={5} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
        <Field label="Witnesses"><Input value={f.witnesses} onChange={(e) => setF({ ...f, witnesses: e.target.value })} /></Field>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.injured} onChange={(e) => setF({ ...f, injured: e.target.checked })} className="h-4 w-4 accent-[#4A6741]" /> Someone was injured</label>
        {act.error && <ErrorNote message={act.error} />}
        <Button type="submit" disabled={act.busy} className="w-full">Report incident</Button>
      </form>
    </Modal>
  );
}
