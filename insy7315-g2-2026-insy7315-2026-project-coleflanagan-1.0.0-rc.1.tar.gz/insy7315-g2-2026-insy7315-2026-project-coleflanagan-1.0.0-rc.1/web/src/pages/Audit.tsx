import { useState } from "react";
import { useApi } from "../lib/api";
import type { AuditList } from "../lib/types";
import { fmtDateTime } from "../lib/format";
import { Badge, Card, Chips, Empty, ErrorNote, Loading, PageHeader, Table, Td, Th } from "../components/ui";

const TONE = { Hazard: "warn", Incident: "danger", Training: "ok", User: "olive", Project: "navy", Assignment: "navy", Export: "neutral" } as const;

export default function Audit() {
  const [cat, setCat] = useState("");
  const { data, error, loading } = useApi<AuditList>(`/audit${cat ? `?category=${cat}` : ""}`);
  const cats = ["Hazard", "Incident", "Training", "User", "Project", "Assignment", "Export"];
  return (
    <>
      <PageHeader crumb="Compliance" title="Audit History" />
      <div className="mb-4"><Chips value={cat} onChange={setCat} options={[{ value: "", label: "All", count: data?.counts.all }, ...cats.map((c) => ({ value: c, label: c, count: data?.counts[c] ?? 0 }))]} /></div>
      {error && <ErrorNote message={error} />}
      <Card>
        {loading && !data ? <Loading /> : (
          <Table>
            <thead><tr><Th>When</Th><Th>Action</Th><Th>Summary</Th><Th>By</Th></tr></thead>
            <tbody>{data?.items.map((a) => (
              <tr key={a.id}><Td className="whitespace-nowrap">{fmtDateTime(a.at)}</Td>
                <Td><Badge tone={TONE[a.category as keyof typeof TONE] ?? "neutral"}>{a.action}</Badge></Td><Td>{a.summary}</Td><Td>{a.actor ?? "System"}</Td></tr>
            ))}</tbody>
          </Table>
        )}
        {data && !data.items.length && <Empty>Nothing recorded yet.</Empty>}
      </Card>
    </>
  );
}
