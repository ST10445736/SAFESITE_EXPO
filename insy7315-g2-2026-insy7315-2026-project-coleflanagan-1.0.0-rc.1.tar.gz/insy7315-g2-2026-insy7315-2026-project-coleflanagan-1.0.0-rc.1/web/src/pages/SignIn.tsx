import { useState, type FormEvent } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../lib/auth";
import { Logo } from "../components/Logo";
import {
  Button,
  ErrorNote,
  Field,
  Input,
  useAction,
} from "../components/ui";

export default function SignIn() {
  const { user, login } = useAuth();
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { busy, error, run } = useAction();

  if (user) return <Navigate to="/portal" replace />;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (await run(() => login(email, password))) {
      nav("/portal");
    }
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="flex flex-col justify-center px-6 py-12 sm:px-16">
        <div className="mx-auto w-full max-w-sm">
          <Logo height={48} />

          <h1 className="mt-10 text-2xl font-bold">
            Sign in to the web portal
          </h1>

          <p className="mt-1 text-sm text-ink-2">
            For Safety Officers and Administrators.
          </p>

          <form onSubmit={submit} className="mt-8 space-y-4">
            <Field label="Email">
              <Input
                type="email"
                required
                autoComplete="username"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@singo.co.za"
              />
            </Field>

            <Field label="Password">
              <Input
                type="password"
                required
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </Field>

            {error && <ErrorNote message={error} />}

            <Button
              type="submit"
              disabled={busy}
              className="w-full"
            >
              {busy ? "Signing in…" : "Sign in"}
            </Button>
          </form>
        </div>
      </div>

      <div className="relative hidden flex-col justify-end bg-night p-14 text-white lg:flex">
        <img
          src="/brand/singo-elephant-mark-transparent.png"
          alt=""
          className="absolute right-10 top-10 w-40 opacity-90"
        />

        <h2 className="max-w-md text-4xl font-extrabold leading-tight tracking-tight">
          Safety oversight for every site, from one desk.
        </h2>

        <p className="mt-4 max-w-md text-white/70">
          Hazards, incidents, training, people and projects.
          Everything your workers record on site, ready for review.
        </p>
      </div>
    </div>
  );
}