import { useState } from "react";
import { api, useApi } from "../lib/api";
import type { PeopleList, Role } from "../lib/types";
import { ROLE_LABEL } from "../lib/format";
import { useAuth } from "../lib/auth";
import { Avatar, Badge, Button, Card, Chips, Empty, ErrorNote, Field, Input, Loading, Modal, PageHeader, Select, Table, Td, Th, useAction } from "../components/ui";

const ROLES: Role[] = ["WORKER", "SUPERVISOR", "SAFETY_OFFICER", "ADMIN"];

export default function People() {
  const { user } = useAuth();
  const [role, setRole] = useState("");
  const { data, error, loading, reload } = useApi<PeopleList>("/people");
  const [adding, setAdding] = useState(false);
  const act = useAction();
  const rows = data?.items.filter((p) => !role || p.role === role) ?? [];
  const patch = async (id: string, body: object) => { if (await act.run(() => api(`/people/${id}`, { method: "PATCH", body }))) reload(); };

  return (
    <>
      <PageHeader crumb="Manage" title="People" actions={<Button onClick={() => setAdding(true)}>Add person</Button>} />
      <div className="mb-4"><Chips value={role} onChange={setRole} options={[
        { value: "", label: "All", count: data?.counts.all }, { value: "WORKER", label: "Workers", count: data?.counts.workers },
        { value: "SUPERVISOR", label: "Supervisors", count: data?.counts.supervisors }, { value: "SAFETY_OFFICER", label: "Safety Officers", count: data?.counts.safetyOfficers },
        { value: "ADMIN", label: "Admins", count: data?.counts.admins },
      ]} /></div>
      {(error || act.error) && <ErrorNote message={(error || act.error)!} />}
      <Card>
        {loading && !data ? <Loading /> : (
          <Table>
            <thead><tr><Th>Name</Th><Th>Role</Th><Th>Site</Th><Th>Status</Th></tr></thead>
            <tbody>{rows.map((p) => {
              const me = p.id === user?.id;
              return (
                <tr key={p.id}>
                  <Td><span className="flex items-center gap-3"><Avatar name={p.name} /><span><b>{p.name}{me && " (you)"}</b><br /><span className="text-xs text-ink-2">{p.email}</span></span></span></Td>
                  <Td>{me ? <Badge tone="olive">{ROLE_LABEL[p.role]}</Badge> :
                    <Select aria-label={`Role for ${p.name}`} value={p.role} onChange={(e) => patch(p.id, { role: e.target.value })} className="!w-auto !py-1.5">{ROLES.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}</Select>}</Td>
                  <Td>{p.sites ?? "–"}</Td>
                  <Td>{me ? <Badge tone="ok">Active</Badge> :
                    <button onClick={() => patch(p.id, { active: !p.active })} className="rounded-full focus-visible:outline-offset-4" aria-label={p.active ? `Deactivate ${p.name}` : `Activate ${p.name}`}>
                      <Badge tone={p.active ? "ok" : "neutral"}>{p.active ? "Active" : "Inactive"}</Badge></button>}</Td>
                </tr>
              );
            })}</tbody>
          </Table>
        )}
        {data && !rows.length && <Empty>No people in this group.</Empty>}
      </Card>
      {adding && <AddPerson onClose={() => setAdding(false)} onDone={() => { setAdding(false); reload(); }} />}
    </>
  );
}

function AddPerson({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const act = useAction();
  const [f, setF] = useState({ name: "", email: "", password: "", role: "WORKER" });
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  return (
    <Modal title="Add a person" onClose={onClose}>
      <form className="space-y-3" onSubmit={async (e) => { e.preventDefault(); if (await act.run(() => api("/people", { body: f }))) onDone(); }}>
        <Field label="Full name" required><Input required value={f.name} onChange={set("name")} /></Field>
        <Field label="Email" required><Input required type="email" value={f.email} onChange={set("email")} /></Field>
        <Field label="Temporary password" required hint="At least 8 characters. They should change it after first sign in."><Input required minLength={8} type="text" value={f.password} onChange={set("password")} /></Field>
        <Field label="Role"><Select value={f.role} onChange={set("role")}>{ROLES.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}</Select></Field>
        {act.error && <ErrorNote message={act.error} />}
        <Button type="submit" disabled={act.busy} className="w-full">Create account</Button>
      </form>
    </Modal>
  );
}
