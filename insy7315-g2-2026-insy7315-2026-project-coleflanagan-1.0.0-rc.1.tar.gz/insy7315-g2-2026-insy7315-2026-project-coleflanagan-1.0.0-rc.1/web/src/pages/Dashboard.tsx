import { useState } from "react";
import { Link } from "react-router-dom";
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { useApi } from "../lib/api";
import type { Dashboard as D } from "../lib/types";
import { Card, Chips, ErrorNote, Loading, PageHeader, SeverityBadge, StatCard, Table, Td, Th } from "../components/ui";
import { useAuth } from "../lib/auth";

const RANGES = [{ value: "7", label: "7 days" }, { value: "30", label: "30 days" }, { value: "90", label: "90 days" }, { value: "3650", label: "All time" }];

export default function Dashboard() {
  const { user } = useAuth();
  const [days, setDays] = useState("30");
  const { data, error, loading } = useApi<D>(`/dashboard?days=${days}`);

  return (
    <>
      <PageHeader crumb="Overview" title="Safety Dashboard" />
      <p className="-mt-3 mb-5 text-sm text-ink-2">Welcome back, {user?.name.split(" ")[0]}.</p>
      <Chips value={days} onChange={setDays} options={RANGES} />
      <div className="mt-5 space-y-5">
        {error && <ErrorNote message={error} />}
        {loading && !data && <Loading />}
        {data && (
          <>
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              <StatCard label="Days since last injury" tone="ok" value={data.daysSinceInjury ?? "–"} note={data.lastInjury ? `Last: ${data.lastInjury}` : "No injuries recorded"} />
              <StatCard label="On site now" value={data.onSite} note="Checked in today" />
              <StatCard label="High-risk open hazards" tone="danger" value={data.highRisk} note={`${data.overdue} with overdue actions`} />
              <StatCard label="Training compliance" tone="navy" value={`${data.trainingCompliance}%`} note="Records not expired" />
            </div>

            <Card className="p-5">
              <h2 className="mb-4 font-bold">Hazards reported vs closed</h2>
              <div className="h-64" role="img" aria-label="Bar chart of hazards reported and closed per week">
                <ResponsiveContainer>
                  <BarChart data={data.chart} margin={{ left: -20 }}>
                    <CartesianGrid vertical={false} stroke="#E5E3DF" />
                    <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={12} />
                    <YAxis allowDecimals={false} tickLine={false} axisLine={false} fontSize={12} />
                    <Tooltip cursor={{ fill: "#F7F6F4" }} />
                    <Legend iconType="circle" />
                    <Bar dataKey="reported" name="Reported" fill="#1C3557" radius={[6, 6, 0, 0]} />
                    <Bar dataKey="closed" name="Closed" fill="#4A6741" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Card>

            <Card>
              <h2 className="p-5 pb-3 font-bold">Needs attention</h2>
              <Table>
                <thead><tr><Th>Item</Th><Th>Type</Th><Th>Severity</Th></tr></thead>
                <tbody>
                  {data.attention.map((a) => (
                    <tr key={`${a.type}${a.id}`} className="hover:bg-canvas">
                      <Td><Link to={a.type === "Hazard" ? `/portal/hazards?id=${a.id}` : `/portal/incidents/${a.id}`} className="font-bold hover:underline">{a.title}</Link>
                        <div className="text-xs text-ink-2">{a.detail}</div></Td>
                      <Td>{a.type}</Td><Td><SeverityBadge value={a.severity} /></Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </Card>
          </>
        )}
      </div>
    </>
  );
}
