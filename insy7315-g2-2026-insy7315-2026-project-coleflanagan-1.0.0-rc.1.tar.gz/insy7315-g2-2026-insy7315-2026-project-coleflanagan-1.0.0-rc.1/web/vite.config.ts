import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  // In development, /api requests go to the Express server so there are no CORS issues
  server: { proxy: { "/api": "http://localhost:4000" } },
});
