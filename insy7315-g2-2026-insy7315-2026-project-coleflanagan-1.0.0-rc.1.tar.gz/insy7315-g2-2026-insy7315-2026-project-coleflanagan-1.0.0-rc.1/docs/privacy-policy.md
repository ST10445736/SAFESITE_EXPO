# SafeSite Privacy Policy

Last updated: 29 October 2026

SafeSite is a workplace safety and site management application provided by Aventra. This policy explains how information is handled when you use SafeSite.

## Information we process

Depending on your role and use of the app, SafeSite processes:

- Account information, including your name, email address, account identifier, role and account status.
- Project and site assignments, attendance and check-in/check-out times.
- Safety checklist answers, tasks, progress updates and submitted photographs.
- PPE photographs, automated assessment results and supervisor decisions.
- Hazard reports, corrective actions and incident reports.
- Training records and expiry dates.
- Administrative activity and audit records.
- Messages you send to the SafeAI assistant.
- Technical information processed by our service providers to authenticate users, operate the service and help prevent abuse.

Incident reports may contain injury information and details about witnesses or other people involved. Submit only information necessary for the safety record.

## Why we use information

We use this information to manage account access, site assignments, attendance, work activities, training and safety reviews; investigate hazards and incidents; maintain organisational records; and protect the service against misuse.

## Photographs and AI features

You can take a photograph or select an image using your device’s system picker. SafeSite receives the image you choose to submit; it does not require access to your entire photo library.

Submitted photographs are stored with the relevant application records.

When you submit a PPE photograph, the photograph is also sent to Google’s Gemini service through Firebase AI Logic for an automated PPE assessment. Messages submitted to SafeAI are processed by Google’s Gemini service to generate responses.

AI results can be incorrect. PPE assessments are advisory, and an authorised reviewer makes the final approval or rejection decision. SafeAI does not replace workplace procedures, professional advice or emergency services.

Do not include passwords or unnecessary personal or sensitive information in AI messages or photographs.

## Storage and access

SafeSite uses Google Firebase services for authentication and storage of application records, and Google services for AI processing and application integrity checks.

Workers have access to records permitted for their accounts. Authorised supervisors, safety officers and administrators can access records permitted by their roles. Staff access may include records across the organisation.

Authorised users may export records for legitimate organisational purposes. The organisation receiving an export is responsible for protecting that copy.

## Service providers and disclosures

Information is processed by Google and Firebase to provide the application’s authentication, database, AI and security services. Their processing may involve infrastructure outside South Africa.

Information may also be disclosed where necessary to comply with applicable law or respond to a lawful request.

## Security

We use authentication, role-based access rules and validation controls to restrict access and protect records. No application, network or storage system can guarantee complete security.

Keep your login details confidential, sign out of shared devices and report suspected unauthorised access to us.

## Retention

We retain personal information only for as long as reasonably necessary to provide SafeSite and meet applicable workplace safety, legal, contractual and dispute-resolution requirements.

Retention depends on the record type and the reason it is needed. When information is no longer required, we will delete it or remove identifying details.

Deactivating an account or uninstalling the app does not automatically delete historical records.

## Access, correction and deletion requests

You may request access to, correction of, or deletion of your personal information and request deletion of your SafeSite account.

Email info@aventra.co.za or info@colsec.co with the subject “SafeSite privacy request”. Include the email address associated with your account and describe your request. Do not send your password.

Requests are handled by Aventra’s designated SafeSite administrator. We may ask for information reasonably necessary to verify your identity.

When an account deletion request is approved, we will delete the account and associated personal information, except records that must be retained for a legitimate legal or regulatory reason. If an exception applies, we will explain which information is retained and why. Account deactivation alone is not account deletion.

## Changes to this policy

We may update this policy when SafeSite’s features or information-handling practices change. The current version will show its last-updated date. Material changes will be communicated through an appropriate channel.

## Contact

Organisation: Aventra  
Primary privacy and support email: info@aventra.co.za  
Alternative contact: info@colsec.co