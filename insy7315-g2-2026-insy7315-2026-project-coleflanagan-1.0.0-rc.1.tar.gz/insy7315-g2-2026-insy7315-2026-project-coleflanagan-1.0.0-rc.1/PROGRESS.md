# SafeSite — Build Progress

Last updated: 26 Sep 2026 by Lindokuhle

## ✅ Done

- Android Studio project set up, GitHub connected
- Firebase project (`safesite-dev`) connected — Auth, Firestore, Storage SDKs wired in
- Email/password sign-in working (`AuthManager`)
- Role model + Role Selection screen (Worker / Supervisor / Safety Officer / Admin)
- Navigation skeleton — every screen from the doc's "Roles at a glance" table is tappable and reachable (as placeholder stubs)
- Core data models written: AppUser, WorkerProfile, Project, Site, SiteAssignment, Attendance
- `AttendanceRepository` written — check in, check out, get open attendance, get site headcount
- SafeSite UI redesign started from approved Figma prototype
- SafeSite design system implemented in Compose:
  - branded colour palette
  - typography hierarchy
  - fixed SafeSite theme instead of dynamic Material You colours
- New branded Welcome screen added with Singo / SafeSite identity
- Welcome screen connected as the app start destination
- Role Selection screen redesigned to match SafeSite visual identity
- Role Selection navigation connected to role-specific sign-in routes
- Sign-In screen redesigned while preserving existing Firebase authentication
- Sign-In screen now includes:
  - role-specific heading
  - branded SafeSite / Singo header
  - styled email and password fields
  - password show / hide control
  - loading state
  - authentication error state
  - change-role navigation
- Navigation route naming cleaned up so role selection, sign-in and sign-out routes use the same route definition
- UI redesign work isolated on `feature` branch for later merge into `main`
- **Hazard reporting** (`HazardRepository`) — built and tested end-to-end:
  - Report Hazard form (category, severity, location)
  - Hazard Register with open / in progress / closed counts and filters
  - Hazard Detail with corrective actions (assignee, due date, overdue flag, mark done)
  - Rule enforced: a hazard cannot be closed while any corrective action is pending
- **Incident reporting** (`IncidentRepository`) — built and tested end-to-end:
  - Report Incident form (type, severity, injured person, witnesses)
  - Incident Register with per-stage counts and filters
  - Enforced lifecycle: Reported → Investigating → Actions pending → Closed (steps cannot be skipped)
  - Every status change logged to `incidentEvents` and shown as a timeline
- **Training records** (`TrainingRepository`) — built and tested end-to-end:
  - Record training against a worker (picked from `users` or typed), course, provider, certificate number
  - Completed date picker + validity (no expiry / 1 / 2 / 3 years)
  - Status worked out automatically: Valid / Expiring soon (≤ 30 days) / Expired
  - Register sorted soonest-expiring first, with counts, filters and delete
- **Safety Dashboard / KPI reports** (`DashboardRepository`) — built and tested:
  - Days since last injury, workers on site now
  - Hazard KPIs: reported, open, high-risk open, overdue actions, closure rate, avg days to close
  - Incident KPIs: reported, still open, injuries, near misses, breakdown by type
  - Training compliance %
  - Period filter (7 / 30 / 90 days / all time) and shareable text report
- **Admin: People** (`AdminRepository`) — built and tested:
  - List, search and filter users by role
  - Create accounts from inside the app (real Firebase Auth login) without signing the admin out
  - Change role, activate / deactivate (admin cannot change or deactivate themselves)
  - Roles stored as `WORKER` / `SUPERVISOR` / `SAFETY_OFFICER` / `ADMIN` to match the `Role` enum
- **Admin: Projects & Sites** (`ProjectRepository`) — built and tested:
  - Create projects (name, client, start date) and set status Active / On hold / Completed
  - Add sites under a project, activate / deactivate, move a site to another project
  - Assign people to sites and end assignments (kept as history in `site_assignments`)
  - `Project` model gained a `name` field
- **Audit history + export** (`AuditLogger`, `ExportRepository`) — built and tested:
  - Every key action writes to `auditLogs` (who, what, when, readable summary)
  - Covers hazards, corrective actions, incidents, training, users, projects, sites and assignments
  - Audit History screen (Admin → Reports) with type filters and search
  - CSV export via Android "Save as": audit log, hazard register, incident register, training records
- Safety Officer + Admin feature work isolated on `safety-officer-features` branch (off `main`)

## Task split

### Lindokuhle — Worker + Supervisor flows (FR01–FR10, US01–US10)

- [x] Attendance repository
- [x] Check-In screen (Worker)
- [x] Supervisor Headcount screen
- [x] Daily Safety Checklist (Worker submit + Supervisor review)
- [x] PPE submission + approval (Worker upload + Supervisor queue)
- [x] Tasks — create/assign/update/photos (My Tasks + Task Board)
- [x] Basic worker profile / site assignment screen

### Cole — Safety Officer + Admin flows (FR11–FR18, US11–US15)

- [x] Hazard reporting + corrective actions
- [x] Incident reporting + full lifecycle
- [x] Training records
- [x] Safety Dashboard / KPI reports
- [x] Admin: manage people / projects / sites
- [x] Audit history + export

### Cole — UI / UX implementation

- [x] SafeSite Compose theme and design system
- [x] Branded Welcome screen
- [x] Redesigned Role Selection screen
- [x] Redesigned Sign-In screen
- [x] Welcome → Role Selection → Sign-In navigation flow
- [ ] Worker dashboard + bottom navigation
- [ ] Worker feature screens redesigned to match Figma
- [ ] Supervisor dashboard + bottom navigation
- [ ] Supervisor feature screens redesigned to match Figma
- [ ] Safety Officer UI implementation
- [ ] Admin UI implementation
- [ ] Shared reusable Compose components
- [ ] Final responsive layout / visual polish across all roles

### Cole — UI / UX implementation

- [x] SafeSite Compose theme and design system
- [x] Branded Welcome screen
- [x] Redesigned Role Selection screen
- [x] Redesigned Sign-In screen
- [x] Welcome → Role Selection → Sign-In navigation flow
- [ ] Worker dashboard + bottom navigation
- [ ] Worker feature screens redesigned to match Figma
- [ ] Supervisor dashboard + bottom navigation
- [ ] Supervisor feature screens redesigned to match Figma
- [ ] Safety Officer UI implementation
- [ ] Admin UI implementation
- [ ] Shared reusable Compose components
- [ ] Final responsive layout / visual polish across all roles

### Shared (either/together, once both feature sets exist)

- [ ] Verify authenticated user's actual role from Firestore before allowing access to a role area
  - Current role selection is for testing only
  - Selecting a role currently determines the UI route but does not confirm that the authenticated user has that role in the database
  - Same fix should block users whose `status` is `inactive`
- [ ] Firestore Security Rules (doc section 8)
- [ ] Cloud Functions for validation/notifications
- [ ] Separate `safesite-test` / `safesite-prod` Firebase projects
- [ ] Merge `safety-officer-features` into `main`
- [ ] Merge completed `feature` UI branch into `main` after testing
- [ ] Full integration / regression testing after UI and backend features are combined

## Screens ready for restyling

All Safety Officer and Admin screens are functional but use plain Material 3 styling.
They live on `safety-officer-features` and are ready to be restyled to the SafeSite design system:

| Role | Area | Screens (package) |
|---|---|---|
| Safety Officer | Dashboard | `SafetyDashboardScreen` (`ui.dashboard`) |
| Safety Officer | Hazards | `HazardRegisterScreen`, `ReportHazardScreen`, `HazardDetailScreen` (`ui.hazard`) |
| Safety Officer | Incidents | `IncidentRegisterScreen`, `ReportIncidentScreen`, `IncidentDetailScreen` (`ui.incident`) |
| Safety Officer | Training | `TrainingRegisterScreen`, `AddTrainingScreen` (`ui.training`) |
| Admin | People | `PeopleScreen`, `AddPersonScreen` (`ui.admin`) |
| Admin | Projects | `ProjectsScreen`, `ProjectDetailScreen`, `SiteDetailScreen` (`ui.admin`) |
| Admin | Reports | `AuditScreen` (`ui.admin`) |

- Business logic lives in the repositories, so restyling the screens won't affect behaviour
- Shared colour helpers to swap for design-system tokens: `severityColor`, `incidentSeverityColor`, `trainingStatusColor`, `projectStatusColor`
- New dependency added: `androidx.compose.material:material-icons-core`
- `SafeSiteNavGraph.kt` changed on both branches — expect a merge conflict there; keep the Welcome/route changes from `feature` and add the new Safety Officer / Admin routes and branches from `safety-officer-features`
- `PROGRESS.md` will also conflict on merge — keep this version (it already includes the UI/UX checklist)

## Current UI flow

Welcome
→ Role Selection
→ Role-specific Sign-In
→ Existing role hub / feature navigation

Next UI milestone:
- replace the generic post-login role hub with the proper Figma-based role dashboards, beginning with Worker

## Known issues / work in progress

- Role selection does not currently enforce the authenticated user's real database role
- An authenticated user can currently select a different role for testing and be routed to that role's UI
- Deactivated users can still sign in until the role/status check is added
- This must be fixed before the app can be considered secure or production-ready
- Some role areas still route to placeholder screens (Supervisor More, Safety Officer More, Admin Dashboard, Admin More)
- Safety Officer and Admin screens use plain Material 3 styling; they still need restyling to the SafeSite design system
- Worker / Supervisor / Safety Officer screens still use the hardcoded test site (`test-site-001`) instead of the user's assigned site
- Audit logging only covers actions from 26 Sep 2026 onwards; earlier test data has no audit entries
- UI redesign (`feature`) and Safety Officer features (`safety-officer-features`) are on separate branches and have not yet been merged into `main`

## Test account

- `worker@safesite.test` — used for testing all roles until the role check is in place

## Rough completion estimate

- Foundation / infrastructure: ~80%
- Worker + Supervisor core functionality: ~70%
- Safety Officer + Admin functionality: ~95%
- UI / UX redesign: ~20–25%
- **Overall against full doc scope: ~55%**
