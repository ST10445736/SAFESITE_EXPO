package com.example.comaventrasafesite

import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory

internal object AppCheckSetup {

    fun install(
        app: FirebaseApp = FirebaseApp.getInstance()
    ) {
        FirebaseAppCheck.getInstance(app)
            .installAppCheckProviderFactory(
                PlayIntegrityAppCheckProviderFactory.getInstance()
            )
    }
}