package com.example.comaventrasafesite.model

data class Project(
    val id: String = "",
    val name: String = "",
    val clientName: String = "",
    val status: String = "active",   // active / on_hold / completed
    val startDate: String = ""       // yyyy-MM-dd
)