package com.example.comaventrasafesite.ui.admin

import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.AuditLog
import com.example.comaventrasafesite.repository.ExportRepository
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private val AuditGreen = Color(0xFF496F42)
private val AuditLightGreen = Color(0xFFEAF2E8)
private val AuditBackground = Color(0xFFF7F8F6)
private val AuditTextSecondary = Color(0xFF667085)
private const val AuditLimit = 1000L

private fun auditDate(millis: Long): String {
    if (millis <= 0L) return "Date unavailable"

    return SimpleDateFormat(
        "dd MMM yyyy, HH:mm",
        Locale.US
    ).apply {
        timeZone = TimeZone.getTimeZone("Africa/Johannesburg")
    }.format(Date(millis)) + " SAST"
}

private fun auditTypeColor(type: String): Color =
    when (type.lowercase(Locale.ROOT)) {
        "hazard" -> Color(0xFFF28C28)
        "incident" -> Color(0xFFC94C4C)
        "training" -> Color(0xFF4F7C47)
        "user" -> Color(0xFF7651A6)
        "project" -> Color(0xFF3F72AF)
        "site" -> Color(0xFF337A85)
        else -> Color(0xFF6B7280)
    }

private fun auditLabel(value: String): String =
    value.replace("_", " ")
        .lowercase(Locale.ROOT)
        .replaceFirstChar { it.uppercase() }
        .ifBlank { "Other" }

private fun exportFailure(error: Exception): String {
    Log.e("SafeSiteExport", "Export failed", error)

    return when ((error as? FirebaseFirestoreException)?.code) {
        FirebaseFirestoreException.Code.PERMISSION_DENIED ->
            "Your account does not have permission to export these records."

        FirebaseFirestoreException.Code.UNAVAILABLE ->
            "The server is unavailable. Check your connection and try again."

        else ->
            "The export could not be completed. Please try again."
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuditScreen(onBack: () -> Unit) {
    val repository = remember { ExportRepository() }
    val loader = rememberScreenLoader()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    var logs by remember { mutableStateOf<List<AuditLog>>(emptyList()) }
    var refreshKey by remember { mutableIntStateOf(0) }
    var selectedType by rememberSaveable { mutableStateOf<String?>(null) }
    var searchQuery by rememberSaveable { mutableStateOf("") }

    var showExportDialog by remember { mutableStateOf(false) }
    var isExporting by remember { mutableStateOf(false) }
    var pendingCsv by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }

    LaunchedEffect(refreshKey) {
        loader.run {
            val loadedLogs = repository.getAuditLogs(AuditLimit)
            logs = loadedLogs.sortedByDescending { it.at }
        }
    }

    val dataReady = !loader.isLoading && loader.errorMessage == null

    val filteredLogs = logs.filter { log ->
        val matchesType =
            selectedType == null ||
                    log.entityType.equals(selectedType, ignoreCase = true)

        val matchesSearch =
            searchQuery.isBlank() ||
                    listOf(
                        log.summary,
                        log.byName,
                        log.action,
                        log.entityType,
                        log.siteId,
                        log.entityId
                    ).any { it.contains(searchQuery, ignoreCase = true) }

        matchesType && matchesSearch
    }

    val saveLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        val csv = pendingCsv
        pendingCsv = null

        when {
            uri == null -> {
                isExporting = false
                message = "Export cancelled."
                isError = false
            }

            csv == null -> {
                isExporting = false
                message =
                    "The prepared export is no longer available. Please export again."
                isError = true
            }

            else -> {
                isExporting = true

                scope.launch {
                    try {
                        withContext(Dispatchers.IO) {
                            val stream = context.contentResolver
                                .openOutputStream(uri, "wt")
                                ?: error("The selected file could not be opened.")

                            stream.use {
                                it.write(csv.toByteArray(Charsets.UTF_8))
                                it.flush()
                            }
                        }

                        message = "Export saved successfully."
                        isError = false
                    } catch (error: CancellationException) {
                        throw error
                    } catch (error: Exception) {
                        Log.e("SafeSiteExport", "Could not save CSV", error)
                        message =
                            "The file could not be saved. It may be incomplete; please export again."
                        isError = true
                    } finally {
                        isExporting = false
                    }
                }
            }
        }
    }

    fun exportCsv(
        fileName: String,
        buildCsv: suspend () -> String
    ) {
        if (isExporting) return

        showExportDialog = false
        isExporting = true
        message = null
        isError = false

        scope.launch {
            var pickerOpened = false

            try {
                val csv = withTimeoutOrNull(30_000L) {
                    withContext(Dispatchers.Default) {
                        buildCsv()
                    }
                }

                if (csv == null) {
                    message =
                        "Preparing the export took too long. Check your connection and try again."
                    isError = true
                    return@launch
                }

                pendingCsv = csv

                val today = SimpleDateFormat(
                    "yyyy-MM-dd",
                    Locale.US
                ).apply {
                    timeZone = TimeZone.getTimeZone("Africa/Johannesburg")
                }.format(Date())

                saveLauncher.launch("safesite-$fileName-$today.csv")
                pickerOpened = true
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                message = exportFailure(error)
                isError = true
            } finally {
                if (!pickerOpened) {
                    pendingCsv = null
                    isExporting = false
                }
            }
        }
    }

    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            shape = RoundedCornerShape(22.dp),
            title = {
                Text(
                    "Export SafeSite data",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "Exports can contain personal and safety information. Save them somewhere secure.",
                        style = MaterialTheme.typography.bodyMedium
                    )

                    ExportOption(
                        title = "Current audit results",
                        description =
                            "${filteredLogs.size} filtered entries from the latest $AuditLimit",
                        enabled = dataReady
                    ) {
                        val selectedLogs = filteredLogs.toList()
                        exportCsv("audit-log") {
                            repository.auditCsv(selectedLogs)
                        }
                    }

                    ExportOption(
                        title = "Hazard register",
                        description = "All hazard records your account can access"
                    ) {
                        exportCsv("hazards") { repository.hazardsCsv() }
                    }

                    ExportOption(
                        title = "Incident register",
                        description = "All incident records your account can access"
                    ) {
                        exportCsv("incidents") { repository.incidentsCsv() }
                    }

                    ExportOption(
                        title = "Training records",
                        description = "All training records your account can access"
                    ) {
                        exportCsv("training") { repository.trainingCsv() }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showExportDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    Scaffold(
        containerColor = AuditBackground,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            "Audit history",
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            "Latest $AuditLimit recorded changes",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        enabled = !loader.isLoading && !isExporting,
                        onClick = {
                            message = null
                            refreshKey++
                        }
                    ) {
                        Icon(
                            Icons.Default.Refresh,
                            contentDescription = "Refresh"
                        )
                    }

                    TextButton(
                        enabled = !isExporting,
                        onClick = { showExportDialog = true }
                    ) {
                        if (isExporting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                "Export",
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = AuditGreen,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            message?.let { currentMessage ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = if (isError) {
                        MaterialTheme.colorScheme.errorContainer
                    } else {
                        AuditLightGreen
                    }
                ) {
                    Text(
                        currentMessage,
                        modifier = Modifier.padding(14.dp),
                        color = if (isError) {
                            MaterialTheme.colorScheme.onErrorContainer
                        } else {
                            AuditGreen
                        }
                    )
                }
            }

            when {
                loader.isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = AuditGreen)
                    }
                }

                loader.errorMessage != null -> {
                    ScreenLoadError(
                        message = loader.errorMessage
                            ?: "Audit history could not be loaded.",
                        onRetry = { refreshKey++ },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                else -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            AuditSummary(logs)
                        }

                        item {
                            Text(
                                "Counts and filters apply to the latest ${logs.size} loaded entries.",
                                style = MaterialTheme.typography.bodySmall,
                                color = AuditTextSecondary
                            )
                        }

                        item {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("Search audit history") },
                                placeholder = {
                                    Text("Person, action or description")
                                },
                                singleLine = true,
                                leadingIcon = {
                                    Icon(
                                        Icons.Default.Search,
                                        contentDescription = null
                                    )
                                },
                                trailingIcon = {
                                    if (searchQuery.isNotBlank()) {
                                        IconButton(
                                            onClick = { searchQuery = "" }
                                        ) {
                                            Icon(
                                                Icons.Default.Close,
                                                contentDescription = "Clear search"
                                            )
                                        }
                                    }
                                },
                                shape = RoundedCornerShape(14.dp)
                            )
                        }

                        item {
                            AuditFilters(
                                logs = logs,
                                selectedType = selectedType,
                                onTypeSelected = { selectedType = it }
                            )
                        }

                        if (filteredLogs.isEmpty()) {
                            item {
                                EmptyAuditState(
                                    hasFilters =
                                        searchQuery.isNotBlank() ||
                                                selectedType != null,
                                    onClearFilters = {
                                        searchQuery = ""
                                        selectedType = null
                                    }
                                )
                            }
                        } else {
                            item {
                                Text(
                                    "${filteredLogs.size} audit entries",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = AuditTextSecondary
                                )
                            }

                            items(
                                items = filteredLogs,
                                key = { it.id }
                            ) { log ->
                                AuditLogCard(log)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AuditSummary(logs: List<AuditLog>) {
    val people = logs.map {
        it.byUserId.ifBlank { it.byName }
    }.filter { it.isNotBlank() }.distinct().size

    val areas = logs.map {
        it.entityType.lowercase(Locale.ROOT)
    }.filter { it.isNotBlank() }.distinct().size

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 18.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            listOf(
                logs.size to "Events",
                people to "People",
                areas to "Areas"
            ).forEach { (count, label) ->
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        count.toString(),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = AuditGreen
                    )
                    Text(
                        label,
                        style = MaterialTheme.typography.labelMedium,
                        color = AuditTextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun AuditFilters(
    logs: List<AuditLog>,
    selectedType: String?,
    onTypeSelected: (String?) -> Unit
) {
    val types = (
            listOf(
                "hazard",
                "incident",
                "training",
                "user",
                "project",
                "site",
                "assignment"
            ) + logs.map { it.entityType.lowercase(Locale.ROOT) }
            ).filter { it.isNotBlank() }.distinct()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        FilterChip(
            selected = selectedType == null,
            onClick = { onTypeSelected(null) },
            label = { Text("All (${logs.size})") },
            colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = AuditGreen,
                selectedLabelColor = Color.White
            )
        )

        types.forEach { type ->
            val count = logs.count {
                it.entityType.equals(type, ignoreCase = true)
            }

            FilterChip(
                selected = selectedType == type,
                onClick = { onTypeSelected(type) },
                label = { Text("${auditLabel(type)} ($count)") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = auditTypeColor(type),
                    selectedLabelColor = Color.White
                )
            )
        }
    }
}

@Composable
private fun AuditLogCard(log: AuditLog) {
    val typeColor = auditTypeColor(log.entityType)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Surface(
                modifier = Modifier.size(42.dp),
                shape = CircleShape,
                color = typeColor.copy(alpha = 0.13f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        auditLabel(log.entityType).take(1),
                        color = typeColor,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(7.dp),
                    color = typeColor
                ) {
                    Text(
                        auditLabel(log.entityType),
                        modifier = Modifier.padding(
                            horizontal = 8.dp,
                            vertical = 3.dp
                        ),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Text(
                    auditDate(log.at),
                    style = MaterialTheme.typography.labelSmall,
                    color = AuditTextSecondary
                )

                Text(
                    log.action.takeIf { it.isNotBlank() }
                        ?.let { auditLabel(it) }
                        ?: "Activity recorded",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    log.summary.ifBlank {
                        "No additional details were recorded."
                    },
                    style = MaterialTheme.typography.bodyMedium
                )

                HorizontalDivider(color = Color(0xFFE2E6E0))

                Text(
                    "Performed by ${log.byName.ifBlank { "Unknown user" }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = AuditTextSecondary
                )
            }
        }
    }
}

@Composable
private fun EmptyAuditState(
    hasFilters: Boolean,
    onClearFilters: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 32.dp, horizontal = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(
            Icons.Default.Search,
            contentDescription = null,
            tint = AuditGreen,
            modifier = Modifier.size(36.dp)
        )

        Text(
            if (hasFilters) "No matching activity" else "No audit activity yet",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Text(
            if (hasFilters) {
                "Try another search term or remove the filter."
            } else {
                "Recorded system activity will appear here."
            },
            style = MaterialTheme.typography.bodyMedium,
            color = AuditTextSecondary
        )

        if (hasFilters) {
            TextButton(onClick = onClearFilters) {
                Text("Clear filters")
            }
        }
    }
}

@Composable
private fun ExportOption(
    title: String,
    description: String,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                description,
                style = MaterialTheme.typography.bodySmall,
                color = AuditTextSecondary
            )
        }
    }
}