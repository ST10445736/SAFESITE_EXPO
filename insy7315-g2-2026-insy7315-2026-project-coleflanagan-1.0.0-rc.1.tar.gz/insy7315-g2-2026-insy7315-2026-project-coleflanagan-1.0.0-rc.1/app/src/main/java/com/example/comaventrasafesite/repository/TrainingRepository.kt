package com.example.comaventrasafesite.repository

import com.example.comaventrasafesite.model.Role
import com.example.comaventrasafesite.model.TrainingRecord
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import com.google.firebase.firestore.Transaction
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Calendar
import java.util.TimeZone

data class WorkerOption(
    val id: String,
    val name: String
)

class TrainingRepository {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val training = db.collection("trainingRecords")

    companion object {
        const val VALID = "valid"
        const val EXPIRING = "expiring"
        const val EXPIRED = "expired"

        private const val WARNING_DAYS = 30
        private const val SITE_TIME_ZONE = "Africa/Johannesburg"

        private val managementRoles = setOf(
            Role.SAFETY_OFFICER.name,
            Role.ADMIN.name
        )

        private fun calendarAt(
            millis: Long
        ): Calendar {
            return Calendar.getInstance(
                TimeZone.getTimeZone(SITE_TIME_ZONE)
            ).apply {
                timeInMillis = millis
            }
        }

        fun startOfDay(
            millis: Long
        ): Long {
            return calendarAt(millis).apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }.timeInMillis
        }

        fun endOfDay(
            millis: Long
        ): Long {
            return calendarAt(startOfDay(millis)).apply {
                add(Calendar.DAY_OF_MONTH, 1)
            }.timeInMillis - 1L
        }

        fun completionFromPicker(
            pickerMillis: Long
        ): Long {
            val selectedDate = Calendar.getInstance(
                TimeZone.getTimeZone("UTC")
            ).apply {
                timeInMillis = pickerMillis
            }

            return Calendar.getInstance(
                TimeZone.getTimeZone(SITE_TIME_ZONE)
            ).apply {
                clear()

                set(
                    selectedDate.get(Calendar.YEAR),
                    selectedDate.get(Calendar.MONTH),
                    selectedDate.get(Calendar.DAY_OF_MONTH),
                    0,
                    0,
                    0
                )
            }.timeInMillis
        }

        fun pickerFromCompletion(
            completionMillis: Long
        ): Long {
            val completedDate = calendarAt(completionMillis)

            return Calendar.getInstance(
                TimeZone.getTimeZone("UTC")
            ).apply {
                clear()

                set(
                    completedDate.get(Calendar.YEAR),
                    completedDate.get(Calendar.MONTH),
                    completedDate.get(Calendar.DAY_OF_MONTH),
                    0,
                    0,
                    0
                )
            }.timeInMillis
        }

        fun expiryAfterYears(
            completedAt: Long,
            years: Int
        ): Long {
            require(years > 0) {
                "Choose a valid training validity period."
            }

            val expiryDate = calendarAt(
                startOfDay(completedAt)
            ).apply {
                add(Calendar.YEAR, years)
            }.timeInMillis

            return endOfDay(expiryDate)
        }

        fun statusOf(
            record: TrainingRecord,
            now: Long = System.currentTimeMillis()
        ): String {
            val expiry = record.expiresAt ?: return VALID
            val expiryEnd = endOfDay(expiry)

            if (now > expiryEnd) {
                return EXPIRED
            }

            val warningStarts = calendarAt(
                startOfDay(expiry)
            ).apply {
                add(
                    Calendar.DAY_OF_MONTH,
                    -WARNING_DAYS
                )
            }.timeInMillis

            return if (now >= warningStarts) {
                EXPIRING
            } else {
                VALID
            }
        }

        fun label(
            status: String
        ): String = when (status) {
            VALID -> "Valid"
            EXPIRING -> "Expiring soon"
            EXPIRED -> "Expired"
            else -> status
        }
    }

    suspend fun getRecordsForSite(
        siteId: String
    ): List<TrainingRecord> {
        require(siteId.isNotBlank()) {
            "An assigned site is required."
        }

        val snapshot = training
            .whereEqualTo("siteId", siteId)
            .get(Source.SERVER)
            .await()

        return snapshot.documents
            .mapNotNull { document ->
                document.toObject(TrainingRecord::class.java)
                    ?.copy(id = document.id)
            }
            .sortedBy {
                it.expiresAt ?: Long.MAX_VALUE
            }
    }

    suspend fun getWorkers(): List<WorkerOption> {
        check(auth.currentUser != null) {
            "Please sign in again."
        }

        val snapshot = db.collection("users")
            .whereEqualTo(
                "role",
                Role.WORKER.name
            )
            .get(Source.SERVER)
            .await()

        return snapshot.documents
            .filter { document ->
                document.getString("status") == "active"
            }
            .map { document ->
                WorkerOption(
                    id = document.id,
                    name = document.getString("fullName")
                        ?.takeIf { it.isNotBlank() }
                        ?: document.getString("email")
                            ?.takeIf { it.isNotBlank() }
                        ?: "Unnamed worker"
                )
            }
            .sortedBy {
                it.name.lowercase()
            }
    }

    suspend fun canManageTraining(): Boolean {
        val account = auth.currentUser
            ?: error("Please sign in again.")

        val profile = db.collection("users")
            .document(account.uid)
            .get(Source.SERVER)
            .await()

        check(
            profile.exists() &&
                    profile.getString("status") == "active"
        ) {
            "Your account is unavailable or inactive. Please sign in again."
        }

        check(auth.currentUser?.uid == account.uid) {
            "Your signed-in account has changed. Please sign in again."
        }

        return profile.getString("role") in managementRoles
    }

    suspend fun addRecord(
        record: TrainingRecord
    ): Result<String> {
        return try {
            val account = auth.currentUser
                ?: error("Please sign in again.")

            require(record.siteId.isNotBlank()) {
                "An assigned site is required."
            }

            require(record.workerName.isNotBlank()) {
                "Choose or enter a worker."
            }

            require(record.workerName.trim().length <= 200) {
                "Keep the worker name under 200 characters."
            }

            require(record.courseName.isNotBlank()) {
                "Enter the course name."
            }

            require(record.courseName.trim().length <= 200) {
                "Keep the course name under 200 characters."
            }

            require(
                record.provider.length <= 200 &&
                        record.certificateNumber.length <= 200
            ) {
                "Keep the provider and certificate fields under 200 characters."
            }

            require(record.completedAt > 0L) {
                "Choose the course completion date."
            }

            val completionDate = startOfDay(record.completedAt)

            require(
                completionDate <= startOfDay(
                    System.currentTimeMillis()
                )
            ) {
                "The completion date cannot be in the future."
            }

            val expiry = record.expiresAt?.let {
                endOfDay(it)
            }

            require(
                expiry == null ||
                        startOfDay(expiry) > completionDate
            ) {
                "Expiry must be after the completion date."
            }

            val reference = training.document()
            val now = System.currentTimeMillis()

            val savedRecord = db.runTransaction { transaction ->
                requireManager(
                    transaction = transaction,
                    userId = account.uid
                )

                val verifiedWorkerName = if (
                    record.workerId.isNotBlank()
                ) {
                    val workerProfile = transaction.get(
                        db.collection("users")
                            .document(record.workerId)
                    )

                    check(
                        workerProfile.exists() &&
                                workerProfile.getString("role") ==
                                Role.WORKER.name &&
                                workerProfile.getString("status") == "active"
                    ) {
                        "The selected worker account is unavailable. " +
                                "Refresh the worker list and choose again."
                    }

                    workerProfile.getString("fullName")
                        ?.takeIf { it.isNotBlank() }
                        ?: workerProfile.getString("email")
                            ?.takeIf { it.isNotBlank() }
                        ?: record.workerName.trim()
                } else {
                    record.workerName.trim()
                }

                val saved = record.copy(
                    id = reference.id,
                    workerName = verifiedWorkerName,
                    courseName = record.courseName.trim(),
                    provider = record.provider.trim(),
                    certificateNumber = record.certificateNumber.trim(),
                    completedAt = completionDate,
                    expiresAt = expiry,
                    recordedBy = account.uid,
                    createdAt = now
                )

                transaction.set(
                    reference,
                    saved
                )

                saved
            }.await()

            logAudit(
                action = "TRAINING_RECORDED",
                recordId = reference.id,
                record = savedRecord,
                summary = "${savedRecord.courseName} recorded for " +
                        savedRecord.workerName
            )

            Result.success(reference.id)
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Result.failure(error)
        }
    }

    suspend fun deleteRecord(
        recordId: String
    ): Result<Unit> {
        return try {
            require(recordId.isNotBlank()) {
                "The training record could not be identified."
            }

            val account = auth.currentUser
                ?: error("Please sign in again.")

            val reference = training.document(recordId)

            val removedRecord = db.runTransaction { transaction ->
                requireManager(
                    transaction = transaction,
                    userId = account.uid
                )

                val current = transaction
                    .get(reference)
                    .toObject(TrainingRecord::class.java)
                    ?: error(
                        "This training record has already been removed. Refresh the list."
                    )

                transaction.delete(reference)

                current
            }.await()

            logAudit(
                action = "TRAINING_DELETED",
                recordId = recordId,
                record = removedRecord,
                summary = "Deleted ${removedRecord.courseName} " +
                        "for ${removedRecord.workerName}"
            )

            Result.success(Unit)
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Result.failure(error)
        }
    }

    private fun requireManager(
        transaction: Transaction,
        userId: String
    ) {
        check(auth.currentUser?.uid == userId) {
            "Your signed-in account has changed. Please sign in again."
        }

        val profile = transaction.get(
            db.collection("users").document(userId)
        )

        check(
            profile.exists() &&
                    profile.getString("status") == "active" &&
                    profile.getString("role") in managementRoles
        ) {
            "An active Safety Officer or Administrator account " +
                    "is required to manage training."
        }
    }

    private suspend fun logAudit(
        action: String,
        recordId: String,
        record: TrainingRecord,
        summary: String
    ) {
        withTimeoutOrNull(3_000L) {
            AuditLogger.log(
                action = action,
                entityType = "training",
                entityId = recordId,
                summary = summary,
                siteId = record.siteId
            )
        }
    }
}