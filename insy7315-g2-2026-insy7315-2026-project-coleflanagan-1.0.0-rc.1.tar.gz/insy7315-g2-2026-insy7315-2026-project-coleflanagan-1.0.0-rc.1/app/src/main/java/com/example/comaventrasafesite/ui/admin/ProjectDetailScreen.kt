package com.example.comaventrasafesite.ui.admin

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.Project
import com.example.comaventrasafesite.model.Site
import com.example.comaventrasafesite.repository.ProjectRepository
import com.example.comaventrasafesite.ui.shared.SafeSiteListTopBar
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import kotlinx.coroutines.launch

@Composable
fun ProjectDetailScreen(
    projectId: String,
    onBack: () -> Unit,
    onOpenSite: (String) -> Unit
) {
    val repository = remember { ProjectRepository() }
    val loader = rememberScreenLoader()
    val actions = remember(projectId) { ProjectActionState() }
    val scope = rememberCoroutineScope()

    var project by remember(projectId) { mutableStateOf<Project?>(null) }
    var sites by remember(projectId) { mutableStateOf<List<Site>>(emptyList()) }
    var refreshKey by remember { mutableIntStateOf(0) }

    var showAdd by rememberSaveable(projectId) { mutableStateOf(false) }
    var siteName by rememberSaveable(projectId) { mutableStateOf("") }
    var siteAddress by rememberSaveable(projectId) { mutableStateOf("") }
    var pendingStatus by remember { mutableStateOf<String?>(null) }

    val ready = !loader.isLoading &&
            loader.errorMessage == null && project != null

    BackHandler(enabled = actions.busy) {}

    suspend fun reload() {
        loader.run {
            val loadedProject = repository.getProject(projectId)
            val loadedSites = if (loadedProject != null) {
                repository.getAllSites().filter { it.projectId == projectId }
            } else {
                emptyList()
            }

            project = loadedProject
            sites = loadedSites
        }
    }

    LaunchedEffect(projectId, refreshKey) { reload() }

    if (showAdd) {
        ProjectFormDialog(
            title = "Add project site",
            busy = actions.busy,
            error = actions.message.takeIf { actions.isError },
            onDismiss = { showAdd = false },
            saveLabel = "Add site",
            onSave = {
                scope.launch {
                    actions.run(
                        successMessage = "Site added successfully.",
                        reload = { reload() },
                        onSuccess = {
                            showAdd = false
                            siteName = ""
                            siteAddress = ""
                        },
                        action = {
                            repository.createSite(projectId, siteName, siteAddress)
                        }
                    )
                }
            }
        ) {
            OutlinedTextField(
                value = siteName,
                onValueChange = { siteName = it },
                label = { Text("Site name") },
                singleLine = true,
                enabled = !actions.busy,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = siteAddress,
                onValueChange = { siteAddress = it },
                label = { Text("Site address") },
                minLines = 2,
                maxLines = 4,
                enabled = !actions.busy,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }

    pendingStatus?.let { status ->
        ProjectFormDialog(
            title = "Change project status?",
            busy = actions.busy,
            error = null,
            onDismiss = { pendingStatus = null },
            saveLabel = "Confirm",
            onSave = {
                pendingStatus = null
                scope.launch {
                    actions.run(
                        successMessage =
                            "Project status changed to ${ProjectRepository.label(status)}.",
                        reload = { reload() },
                        action = {
                            repository.setProjectStatus(projectId, status)
                        }
                    )
                }
            }
        ) {
            Text("Set this project to ${ProjectRepository.label(status)}?")

            if (status != "active") {
                Text(
                    "New sites and assignments will be blocked. Linked site workflows will no longer treat this project as active."
                )
            }
        }
    }

    Scaffold(
        containerColor = Color(0xFFF7F8F6),
        topBar = {
            SafeSiteListTopBar(
                title = "Project details",
                subtitle = when {
                    loader.isLoading -> "Loading project…"
                    loader.errorMessage != null -> "Project unavailable"
                    else -> project?.name.orEmpty()
                },
                actionLabel = "Add site",
                onBack = { if (!actions.busy) onBack() },
                onCreate = {
                    actions.clear()
                    showAdd = true
                },
                createEnabled =
                    ready && !actions.busy && project?.status == "active",
                onRefresh = if (!loader.isLoading && !actions.busy) {
                    { refreshKey++ }
                } else null,
                containerColor = Color(0xFF496F42),
                contentColor = Color.White
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            when {
                loader.isLoading -> ProjectWaiting()

                loader.errorMessage != null -> ScreenLoadError(
                    message = loader.errorMessage.orEmpty(),
                    onRetry = { refreshKey++ },
                    modifier = Modifier.fillMaxSize()
                )

                project == null -> {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            "Project not found",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text("This project no longer exists.")
                        Button(onClick = onBack) { Text("Return to projects") }
                    }
                }

                else -> {
                    val current = project ?: return@Scaffold

                    LazyColumn(
                        contentPadding = PaddingValues(20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item { ProjectMessage(actions) }

                        if (actions.busy) {
                            item {
                                LinearProgressIndicator(
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }

                        item {
                            ProjectPanel(current.name.ifBlank { "Unnamed project" }) {
                                Text(
                                    current.clientName.ifBlank { "No client recorded" }
                                )
                                Text(
                                    "Start date: ${current.startDate.ifBlank { "Not specified" }}"
                                )
                                StatusBadge(current.status)
                            }
                        }

                        item {
                            ProjectPanel("Project status") {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    ProjectRepository.PROJECT_STATUSES.forEach { status ->
                                        FilterChip(
                                            selected = current.status == status,
                                            enabled = !actions.busy,
                                            onClick = {
                                                if (status != current.status) {
                                                    pendingStatus = status
                                                }
                                            },
                                            label = {
                                                Text(ProjectRepository.label(status))
                                            }
                                        )
                                    }
                                }

                                if (current.status != "active") {
                                    Text(
                                        "Activate this project before adding sites.",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }

                        item {
                            Text(
                                "Project sites (${sites.size})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (sites.isEmpty()) {
                            item {
                                ProjectPanel("No sites yet") {
                                    Text(
                                        "Use Add site in the header while the project is active."
                                    )
                                }
                            }
                        }

                        items(sites, key = { it.id }) { site ->
                            ProjectSiteCard(
                                site = site,
                                enabled = !actions.busy,
                                onClick = { onOpenSite(site.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}