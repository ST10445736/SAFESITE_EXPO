package com.example.comaventrasafesite.ui.dashboard

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.repository.DashboardRepository
import com.example.comaventrasafesite.repository.SafetyKpis
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import java.util.Locale

private val dashboardPeriods = listOf(
    "7 days" to 7,
    "30 days" to 30,
    "90 days" to 90,
    "All time" to null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SafetyDashboardScreen(
    siteId: String,
    siteName: String,
    onBack: () -> Unit,
    onOpenHazards: () -> Unit,
    onOpenIncidents: () -> Unit,
    onOpenTraining: () -> Unit
) {
    val repository = remember { DashboardRepository() }
    val loader = rememberScreenLoader()
    val context = LocalContext.current

    var periodDays by rememberSaveable(siteId) {
        mutableStateOf<Int?>(30)
    }
    var kpis by remember(siteId) {
        mutableStateOf<SafetyKpis?>(null)
    }
    var refreshKey by remember { mutableIntStateOf(0) }

    LaunchedEffect(siteId, periodDays, refreshKey) {
        kpis = null

        loader.run {
            kpis = repository.getKpis(siteId, periodDays)
        }
    }

    val current = kpis
    val ready = !loader.isLoading &&
            loader.errorMessage == null &&
            current != null &&
            current.periodDays == periodDays

    fun shareReport() {
        if (!ready) return
        val report = kpis ?: return

        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "SafeSite Safety Report")
                putExtra(
                    Intent.EXTRA_TEXT,
                    repository.buildReportText(report, siteName)
                )
            }

            context.startActivity(
                Intent.createChooser(intent, "Share safety report")
            )
        } catch (error: Exception) {
            Toast.makeText(
                context,
                "The share menu could not be opened.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            "Safety dashboard",
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            siteName.ifBlank { "Assigned site" },
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        enabled = !loader.isLoading,
                        onClick = {
                            kpis = null
                            refreshKey++
                        }
                    ) {
                        Icon(
                            Icons.Default.Refresh,
                            contentDescription = "Refresh dashboard"
                        )
                    }

                    IconButton(
                        enabled = ready,
                        onClick = ::shareReport
                    ) {
                        Icon(
                            Icons.Default.Share,
                            contentDescription = "Share safety report"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor =
                        MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor =
                        MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    dashboardPeriods.forEach { (label, days) ->
                        FilterChip(
                            selected = periodDays == days,
                            enabled = !loader.isLoading,
                            onClick = {
                                if (periodDays != days) {
                                    kpis = null
                                    periodDays = days
                                }
                            },
                            label = { Text(label) }
                        )
                    }
                }
            }

            when {
                loader.isLoading || (
                        loader.errorMessage == null && current == null
                        ) -> {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 48.dp),
                            horizontalAlignment =
                                androidx.compose.ui.Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator()
                            Text("Loading safety data…")
                        }
                    }
                }

                loader.errorMessage != null -> {
                    item {
                        ScreenLoadError(
                            message = loader.errorMessage.orEmpty(),
                            onRetry = {
                                kpis = null
                                refreshKey++
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                current != null -> {
                    item {
                        Text(
                            "Refreshed ${DashboardRepository.timestamp(current.generatedAt)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            "Period filters apply to dated events. Open records, training and attendance show the current snapshot.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    item {
                        DashboardPanel("Site overview") {
                            Text(
                                "Days since last recorded injury",
                                style = MaterialTheme.typography.labelLarge
                            )
                            Text(
                                current.daysSinceLastInjury?.toString()
                                    ?: "No dated injury recorded",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold
                            )
                            HorizontalDivider()
                            Text(
                                "${current.onSiteNow} on site at refresh",
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    item {
                        DashboardSection(
                            title = "Hazards",
                            onViewAll = onOpenHazards
                        )
                    }

                    item {
                        DashboardMetricRow(
                            leftLabel = "Reported in period",
                            leftValue = current.hazardsReported.toString(),
                            rightLabel = "Closed in period",
                            rightValue = current.hazardsClosed.toString(),
                            onClick = onOpenHazards
                        )
                    }

                    item {
                        DashboardMetricRow(
                            leftLabel = "Open now",
                            leftValue = current.hazardsOpen.toString(),
                            rightLabel = "In progress now",
                            rightValue = current.hazardsInProgress.toString(),
                            onClick = onOpenHazards
                        )
                    }

                    item {
                        DashboardMetricRow(
                            leftLabel = "High-risk not closed",
                            leftValue = current.highRiskOpen.toString(),
                            rightLabel = "Overdue actions",
                            rightValue = current.overdueActions.toString(),
                            onClick = onOpenHazards
                        )
                    }

                    item {
                        DashboardPanel("Closure and corrective actions") {
                            Text(
                                "Reported hazards now closed: " +
                                        if (current.hazardsReported == 0) {
                                            "N/A"
                                        } else {
                                            "${current.hazardClosureRate}%"
                                        }
                            )
                            Text(
                                "This percentage follows hazards reported in the selected period.",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                "Average closure time: " +
                                        (
                                                current.avgDaysToClose?.let {
                                                    String.format(
                                                        Locale.US,
                                                        "%.1f days",
                                                        it
                                                    )
                                                } ?: "N/A"
                                                )
                            )
                            Text(
                                "Average time uses hazards closed in the selected period.",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                "${current.pendingActions} corrective actions pending"
                            )

                            if (current.undatedHazardClosures > 0) {
                                Text(
                                    "${current.undatedHazardClosures} closed hazards have missing or invalid closure dates. They are excluded from dated closure metrics.",
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }

                    item {
                        DashboardSection(
                            title = "Incidents",
                            onViewAll = onOpenIncidents
                        )
                    }

                    item {
                        DashboardMetricRow(
                            leftLabel = "Reported in period",
                            leftValue = current.incidentsReported.toString(),
                            rightLabel = "Still open now",
                            rightValue = current.incidentsOpen.toString(),
                            onClick = onOpenIncidents
                        )
                    }

                    item {
                        DashboardMetricRow(
                            leftLabel = "Injuries in period",
                            leftValue = current.injuries.toString(),
                            rightLabel = "Near misses in period",
                            rightValue = current.nearMisses.toString(),
                            onClick = onOpenIncidents
                        )
                    }

                    item {
                        Text(
                            "Injuries and near misses use the occurrence date.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (current.incidentsByType.isNotEmpty()) {
                        item {
                            DashboardPanel("Reported incidents by type") {
                                val maximum =
                                    current.incidentsByType.values
                                        .maxOrNull()
                                        ?.coerceAtLeast(1)
                                        ?: 1

                                current.incidentsByType.entries
                                    .sortedByDescending { it.value }
                                    .forEach { (type, count) ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement =
                                                Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                type,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Text(
                                                count.toString(),
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        LinearProgressIndicator(
                                            progress = {
                                                count.toFloat() / maximum
                                            },
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                            }
                        }
                    }

                    item {
                        DashboardSection(
                            title = "Training",
                            onViewAll = onOpenTraining
                        )
                    }

                    item {
                        ElevatedCard(
                            onClick = onOpenTraining,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    "Training record validity",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )

                                if (current.trainingTotal == 0) {
                                    Text(
                                        "N/A",
                                        style =
                                            MaterialTheme.typography.headlineMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text("No training records have been recorded.")
                                } else {
                                    Text(
                                        "${current.trainingCompliance}% not expired",
                                        style =
                                            MaterialTheme.typography.headlineSmall,
                                        fontWeight = FontWeight.Bold
                                    )

                                    LinearProgressIndicator(
                                        progress = {
                                            (
                                                    current.trainingCompliance /
                                                            100f
                                                    ).coerceIn(0f, 1f)
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    )

                                    Text("${current.trainingTotal} records")
                                    Text(
                                        "${current.trainingValid} valid · " +
                                                "${current.trainingExpiring} expiring · " +
                                                "${current.trainingExpired} expired"
                                    )
                                }

                                Text(
                                    "Record validity does not confirm that every worker has every required course.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color =
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DashboardPanel(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            content()
        }
    }
}

@Composable
private fun DashboardSection(
    title: String,
    onViewAll: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        Text(
            title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        TextButton(onClick = onViewAll) {
            Text("View all")
        }
    }
}

@Composable
private fun DashboardMetricRow(
    leftLabel: String,
    leftValue: String,
    rightLabel: String,
    rightValue: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        listOf(
            leftLabel to leftValue,
            rightLabel to rightValue
        ).forEach { (label, value) ->
            ElevatedCard(
                onClick = onClick,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        value,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        label,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}