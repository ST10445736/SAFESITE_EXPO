package com.example.comaventrasafesite.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SafeSiteColorScheme = lightColorScheme(
    primary = SafeSiteOlive,
    onPrimary = Color.White,
    primaryContainer = SafeSiteOlivePale,
    onPrimaryContainer = SafeSiteOliveDark,

    secondary = SafeSiteNavy,
    onSecondary = Color.White,
    secondaryContainer = SafeSiteBackgroundAlt,
    onSecondaryContainer = SafeSiteNavy,

    tertiary = SafeSiteOrange,
    onTertiary = Color.White,

    background = SafeSiteBackground,
    onBackground = SafeSiteCharcoal,

    surface = SafeSiteSurface,
    onSurface = SafeSiteCharcoal,
    surfaceVariant = SafeSiteBackgroundAlt,
    onSurfaceVariant = SafeSiteTextSecondary,

    error = SafeSiteDanger,
    onError = Color.White,
    errorContainer = SafeSiteDangerLight,
    onErrorContainer = SafeSiteDanger,

    outline = SafeSiteBorder,
    outlineVariant = SafeSiteBorderSoft
)

@Composable
fun ComaventrasafesiteTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SafeSiteColorScheme,
        typography = Typography,
        content = content
    )
}