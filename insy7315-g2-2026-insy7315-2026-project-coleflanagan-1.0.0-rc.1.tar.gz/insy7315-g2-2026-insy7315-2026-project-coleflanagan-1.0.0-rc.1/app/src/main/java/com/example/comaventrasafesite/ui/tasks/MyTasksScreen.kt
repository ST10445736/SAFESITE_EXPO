package com.example.comaventrasafesite.ui.tasks

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.Task
import com.example.comaventrasafesite.repository.TaskRepository
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import com.example.comaventrasafesite.ui.worker.WorkerBottomBar
import com.example.comaventrasafesite.ui.worker.WorkerDestination
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@Composable
fun MyTasksScreen(
    onNavigate: (WorkerDestination) -> Unit
) {
    val repository = remember {
        TaskRepository()
    }

    val scope = rememberCoroutineScope()
    val loader = rememberScreenLoader()

    val workerId = remember {
        FirebaseAuth.getInstance().currentUser?.uid.orEmpty()
    }

    var tasks by remember {
        mutableStateOf<List<Task>>(emptyList())
    }

    var expandedTaskId by remember {
        mutableStateOf<String?>(null)
    }

    fun refresh() {
        scope.launch {
            loader.run {
                tasks = repository.getMyTasks(workerId)
                    .sortedBy { it.dueDate }
            }
        }
    }

    LaunchedEffect(workerId) {
        refresh()
    }

    Scaffold(
        bottomBar = {
            WorkerBottomBar(
                selectedDestination = WorkerDestination.TASKS,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Surface(
                color = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(
                        horizontal = 20.dp,
                        vertical = 22.dp
                    )
                ) {
                    Text(
                        text = "My Tasks",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "Review and update your assigned work",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimary.copy(
                            alpha = 0.75f
                        )
                    )
                }
            }

            val loadError = loader.errorMessage

            when {
                loader.isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }

                loadError != null -> {
                    ScreenLoadError(
                        message = loadError,
                        onRetry = {
                            refresh()
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                tasks.isEmpty() -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(28.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "No assigned tasks",
                                style = MaterialTheme.typography.titleLarge
                            )

                            Text(
                                text = "New tasks from your supervisor will appear here.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 8.dp)
                            )

                            TextButton(
                                onClick = {
                                    refresh()
                                },
                                modifier = Modifier.padding(top = 8.dp)
                            ) {
                                Text("Refresh")
                            }
                        }
                    }
                }

                else -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement =
                                    Arrangement.SpaceBetween,
                                verticalAlignment =
                                    Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${tasks.size} assigned",
                                    style = MaterialTheme.typography.labelLarge
                                )

                                TextButton(
                                    onClick = {
                                        refresh()
                                    }
                                ) {
                                    Text("Refresh")
                                }
                            }
                        }

                        items(
                            items = tasks,
                            key = { it.id }
                        ) { task ->
                            TaskCard(
                                task = task,
                                expanded = expandedTaskId == task.id,
                                onToggleExpand = {
                                    expandedTaskId =
                                        if (expandedTaskId == task.id) {
                                            null
                                        } else {
                                            task.id
                                        }
                                },
                                repository = repository,
                                scope = scope,
                                onUpdated = {
                                    refresh()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TaskCard(
    task: Task,
    expanded: Boolean,
    onToggleExpand: () -> Unit,
    repository: TaskRepository,
    scope: CoroutineScope,
    onUpdated: () -> Unit
) {
    val context = LocalContext.current

    var note by remember(task.id) {
        mutableStateOf(task.progressNote)
    }

    var statusSelection by remember(
        task.id,
        task.status
    ) {
        mutableStateOf(task.status)
    }

    var selectedUri by remember(task.id) {
        mutableStateOf<Uri?>(null)
    }

    var isSaving by remember(task.id) {
        mutableStateOf(false)
    }

    var errorMessage by remember(task.id) {
        mutableStateOf<String?>(null)
    }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            selectedUri = uri
            errorMessage = null
        }
    }

    val overdue = task.status != "completed" &&
            task.dueDate > 0 &&
            task.dueDate < System.currentTimeMillis()

    ElevatedCard(
        onClick = {
            if (!isSaving) {
                onToggleExpand()
            }
        },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.elevatedCardElevation(
            defaultElevation = 1.dp
        )
    ) {
        Column(
            modifier = Modifier.padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )

                Spacer(
                    modifier = Modifier.width(12.dp)
                )

                Text(
                    text = task.status
                        .replace("_", " ")
                        .uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = when (task.status) {
                        "completed" -> {
                            MaterialTheme.colorScheme.primary
                        }

                        "blocked" -> {
                            MaterialTheme.colorScheme.error
                        }

                        else -> {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    }
                )
            }

            if (task.description.isNotBlank()) {
                Text(
                    text = task.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            Text(
                text = "Due ${formatDueDate(task.dueDate)}",
                style = MaterialTheme.typography.bodySmall,
                color = if (overdue) {
                    MaterialTheme.colorScheme.error
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
                modifier = Modifier.padding(top = 10.dp)
            )

            TaskProgressPhoto(
                photoUrl = task.photoUrl
            )

            TextButton(
                onClick = onToggleExpand,
                enabled = !isSaving,
                contentPadding = PaddingValues(0.dp)
            ) {
                Text(
                    text = if (expanded) {
                        "Hide update"
                    } else {
                        "Update progress"
                    }
                )
            }

            if (expanded) {
                HorizontalDivider(
                    modifier = Modifier.padding(
                        vertical = 8.dp
                    )
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "not_started",
                        "in_progress",
                        "completed",
                        "blocked"
                    ).forEach { option ->
                        FilterChip(
                            selected = statusSelection == option,
                            onClick = {
                                statusSelection = option
                                errorMessage = null
                            },
                            enabled = !isSaving,
                            label = {
                                Text(
                                    option.replace("_", " ")
                                )
                            }
                        )
                    }
                }

                OutlinedTextField(
                    value = note,
                    onValueChange = {
                        note = it
                        errorMessage = null
                    },
                    label = {
                        Text("Progress note")
                    },
                    supportingText = {
                        Text("${note.length}/5000")
                    },
                    isError = note.length > 5000,
                    enabled = !isSaving,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp),
                    minLines = 3
                )

                OutlinedButton(
                    onClick = {
                        try {
                            imagePicker.launch("image/*")
                        } catch (error: Exception) {
                            errorMessage =
                                error.message
                                    ?: "Could not open the image picker."
                        }
                    },
                    enabled = !isSaving,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                ) {
                    Text(
                        text = if (selectedUri == null) {
                            "Attach photo"
                        } else {
                            "Photo selected"
                        }
                    )
                }

                errorMessage?.let { message ->
                    Text(
                        text = message,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                Button(
                    onClick = {
                        isSaving = true
                        errorMessage = null

                        scope.launch {
                            try {
                                repository.updateTaskProgress(
                                    taskId = task.id,
                                    status = statusSelection,
                                    progressNote = note,
                                    photoUri = selectedUri,
                                    context = context
                                ).onSuccess {
                                    selectedUri = null
                                    onUpdated()
                                }.onFailure { error ->
                                    errorMessage =
                                        error.message ?: "Update failed."
                                }
                            } catch (error: CancellationException) {
                                throw error
                            } catch (error: Exception) {
                                errorMessage =
                                    error.message ?: "Update failed."
                            } finally {
                                isSaving = false
                            }
                        }
                    },
                    enabled = !isSaving &&
                            note.length <= 5000,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                ) {
                    if (isSaving) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    } else {
                        Text("Save update")
                    }
                }
            }
        }
    }
}

private fun formatDueDate(
    timestamp: Long
): String {
    if (timestamp <= 0L) {
        return "date not specified"
    }

    return SimpleDateFormat(
        "dd MMM yyyy, HH:mm",
        Locale.getDefault()
    ).apply {
        timeZone = TimeZone.getTimeZone(
            "Africa/Johannesburg"
        )
    }.format(Date(timestamp))
}