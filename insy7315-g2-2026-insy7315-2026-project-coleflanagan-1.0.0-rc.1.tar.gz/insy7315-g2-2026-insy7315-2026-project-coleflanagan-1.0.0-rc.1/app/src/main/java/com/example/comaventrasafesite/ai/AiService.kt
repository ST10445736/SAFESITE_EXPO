package com.example.comaventrasafesite.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.content
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

object AiService {

    private const val MODEL_NAME = "gemini-3.5-flash-lite"
    private const val LOG_TAG = "PPE_AI"

    private val model by lazy {
        Firebase.ai(
            backend = GenerativeBackend.googleAI()
        ).generativeModel(
            modelName = MODEL_NAME
        )
    }

    data class PpeCheck(
        val verdict: String,
        val reason: String
    )

    private const val PPE_PROMPT = """
You are providing an advisory visual PPE pre-screen for a construction-site supervisor.

Inspect the supplied photo for:
- A hard hat.
- A high-visibility vest.
- Safety boots.

Also mention safety glasses and gloves if clearly visible, but do not use them as additional mandatory requirements.

Return one JSON object containing these two string fields:
{"verdict":"unclear","reason":"A short explanation."}

The verdict must be exactly one of:
- compliant
- non_compliant
- unclear

Use compliant only when all three required PPE items are clearly visible.
Use non_compliant when a required item is clearly absent from a visible body area.
Use unclear when the image is cropped, blurry, does not show a person, or does not let you inspect every required item.

If feet are outside the photo, use unclear rather than assuming boots are present or absent.
Do not infer compliance from clothing colour alone.
Do not claim that the person or site is safe.
The supervisor makes the final decision.

Keep the reason to one short sentence.
Return JSON only, without Markdown.
"""

    suspend fun checkPpe(
        imageBytes: ByteArray
    ): PpeCheck {
        return runCheck {
            withContext(Dispatchers.IO) {
                BitmapFactory.decodeByteArray(
                    imageBytes,
                    0,
                    imageBytes.size
                )
            }
        }
    }

    // Retained for any existing callers that provide a photo URI.
    suspend fun checkPpe(
        context: Context,
        uri: Uri
    ): PpeCheck {
        return runCheck {
            withContext(Dispatchers.IO) {
                loadBitmap(context, uri)
            }
        }
    }

    private suspend fun runCheck(
        loadPhoto: suspend () -> Bitmap?
    ): PpeCheck {
        var bitmap: Bitmap? = null
        val startedAt = System.currentTimeMillis()

        return try {
            val photo = loadPhoto()

            if (photo == null) {
                Log.e(LOG_TAG, "The PPE image could not be decoded.")

                return PpeCheck(
                    verdict = "unavailable",
                    reason = "The photo could not be read for the AI check."
                )
            }

            bitmap = photo

            Log.d(
                LOG_TAG,
                "Starting PPE check: ${photo.width} x ${photo.height}"
            )

            val response = model.generateContent(
                content {
                    image(photo)
                    text(PPE_PROMPT)
                }
            )

            val result = parse(response.text.orEmpty())

            Log.d(
                LOG_TAG,
                "PPE check finished in ${
                    System.currentTimeMillis() - startedAt
                } ms; verdict=${result.verdict}"
            )

            result
        } catch (e: CancellationException) {
            Log.w(
                LOG_TAG,
                "PPE check cancelled or timed out after ${
                    System.currentTimeMillis() - startedAt
                } ms."
            )

            throw e
        } catch (e: Exception) {
            Log.e(LOG_TAG, "PPE AI request failed", e)

            PpeCheck(
                verdict = "unavailable",
                reason = "AI check unavailable. Supervisor review is required."
            )
        } finally {
            bitmap?.recycle()
        }
    }

    private fun parse(
        raw: String
    ): PpeCheck {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')

        if (start < 0 || end <= start) {
            Log.w(LOG_TAG, "The model returned no JSON object.")

            return PpeCheck(
                verdict = "unclear",
                reason = "The AI returned no clear assessment."
            )
        }

        return try {
            val json = JSONObject(
                raw.substring(start, end + 1)
            )

            val verdict = json
                .optString("verdict", "")
                .trim()
                .lowercase()

            if (
                verdict !in setOf(
                    "compliant",
                    "non_compliant",
                    "unclear"
                )
            ) {
                Log.w(LOG_TAG, "The model returned an invalid verdict.")

                return PpeCheck(
                    verdict = "unclear",
                    reason = "The AI returned no clear assessment."
                )
            }

            PpeCheck(
                verdict = verdict,
                reason = json
                    .optString("reason", "")
                    .trim()
                    .take(200)
                    .ifBlank {
                        "Inspect the photo and make the final decision."
                    }
            )
        } catch (e: Exception) {
            Log.w(LOG_TAG, "The AI response could not be parsed.", e)

            PpeCheck(
                verdict = "unclear",
                reason = "The AI returned no clear assessment."
            )
        }
    }

    private fun loadBitmap(
        context: Context,
        uri: Uri,
        maxSide: Int = 1024
    ): Bitmap? {
        val resolver = context.contentResolver

        val bounds = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }

        val boundsStream = resolver.openInputStream(uri)
            ?: return null

        boundsStream.use { stream ->
            BitmapFactory.decodeStream(stream, null, bounds)
        }

        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            return null
        }

        var sampleSize = 1

        while (
            bounds.outWidth / sampleSize > maxSide ||
            bounds.outHeight / sampleSize > maxSide
        ) {
            sampleSize *= 2
        }

        val options = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
        }

        return resolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, options)
        }
    }
}