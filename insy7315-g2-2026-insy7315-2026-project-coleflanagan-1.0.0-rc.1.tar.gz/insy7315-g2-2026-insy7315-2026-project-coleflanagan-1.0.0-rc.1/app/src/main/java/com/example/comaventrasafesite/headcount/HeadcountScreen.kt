package com.example.comaventrasafesite.ui.headcount

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.Attendance
import com.example.comaventrasafesite.repository.AttendanceRepository
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HeadcountScreen(
    siteId: String,
    siteName: String,
    onBack: () -> Unit
) {
    val repository = remember {
        AttendanceRepository()
    }

    val scope = rememberCoroutineScope()
    val loader = rememberScreenLoader()

    var checkedInWorkers by remember(siteId) {
        mutableStateOf<List<Attendance>>(emptyList())
    }

    var workerNames by remember(siteId) {
        mutableStateOf<Map<String, String>>(emptyMap())
    }

    var lastRefreshedAt by remember(siteId) {
        mutableStateOf<Long?>(null)
    }

    fun refresh() {
        scope.launch {
            loader.run {
                val headcount = repository.getSiteHeadcount(siteId)

                val names = repository.getWorkerNames(
                    headcount.map {
                        it.workerId
                    }
                )

                checkedInWorkers = headcount
                workerNames = names
                lastRefreshedAt = System.currentTimeMillis()
            }
        }
    }

    LaunchedEffect(siteId) {
        refresh()
    }

    val loadError = loader.errorMessage

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Live Headcount",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            refresh()
                        },
                        enabled = !loader.isLoading
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Refresh headcount"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor =
                        MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor =
                        MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                ElevatedCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.elevatedCardColors(
                        containerColor =
                            MaterialTheme.colorScheme.primaryContainer
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Person,
                                contentDescription = null,
                                modifier = Modifier.padding(13.dp)
                            )
                        }

                        Spacer(
                            modifier = Modifier.width(16.dp)
                        )

                        Column(
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = siteName.ifBlank {
                                    "Assigned site"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )

                            Text(
                                text = when {
                                    loader.isLoading -> {
                                        "Updating site attendance…"
                                    }

                                    loadError != null -> {
                                        "Headcount unavailable"
                                    }

                                    else -> {
                                        "${checkedInWorkers.size} currently on site"
                                    }
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color =
                                    MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 3.dp)
                            )
                        }

                        if (!loader.isLoading && loadError == null) {
                            Text(
                                text = checkedInWorkers.size.toString(),
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            when {
                loader.isLoading -> {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator()
                        }
                    }
                }

                loadError != null -> {
                    item {
                        ScreenLoadError(
                            message = loadError,
                            onRetry = {
                                refresh()
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                else -> {
                    lastRefreshedAt?.let { timestamp ->
                        item {
                            Text(
                                text = "Last refreshed ${
                                    formatHeadcountTime(timestamp)
                                }. Use Refresh to update.",
                                style = MaterialTheme.typography.bodySmall,
                                color =
                                    MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    item {
                        Text(
                            text = "WORKERS ON SITE",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    if (checkedInWorkers.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 40.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment =
                                        Alignment.CenterHorizontally,
                                    verticalArrangement =
                                        Arrangement.spacedBy(10.dp)
                                ) {
                                    Surface(
                                        color =
                                            MaterialTheme.colorScheme.primaryContainer,
                                        shape = RoundedCornerShape(18.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Person,
                                            contentDescription = null,
                                            tint =
                                                MaterialTheme.colorScheme.primary,
                                            modifier = Modifier
                                                .padding(18.dp)
                                                .size(32.dp)
                                        )
                                    }

                                    Text(
                                        text = "No workers checked in",
                                        style =
                                            MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )

                                    Text(
                                        text = "Workers appear here after " +
                                                "checking in to this site.",
                                        style =
                                            MaterialTheme.typography.bodyMedium,
                                        color =
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    } else {
                        items(
                            items = checkedInWorkers,
                            key = { it.id }
                        ) { attendance ->
                            HeadcountWorkerCard(
                                workerName =
                                    workerNames[attendance.workerId]
                                        ?: "Worker account unavailable",
                                checkInTime = attendance.checkIn
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HeadcountWorkerCard(
    workerName: String,
    checkInTime: Long?
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.elevatedCardElevation(
            defaultElevation = 1.dp
        )
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Person,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(12.dp)
                )
            }

            Spacer(
                modifier = Modifier.width(14.dp)
            )

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = workerName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )

                Text(
                    text = checkInTime?.let {
                        "Checked in ${formatHeadcountTime(it)}"
                    } ?: "Check-in time unavailable",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 3.dp)
                )
            }

            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.primary,
                shape = RoundedCornerShape(50)
            ) {
                Text(
                    text = "ON SITE",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(
                        horizontal = 10.dp,
                        vertical = 6.dp
                    )
                )
            }
        }
    }
}

private fun formatHeadcountTime(
    timestamp: Long
): String {
    return SimpleDateFormat(
        "dd MMM, HH:mm",
        Locale.getDefault()
    ).apply {
        timeZone = TimeZone.getTimeZone(
            "Africa/Johannesburg"
        )
    }.format(Date(timestamp))
}