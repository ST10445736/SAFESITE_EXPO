package com.example.comaventrasafesite.ui.hazard

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.Hazard
import com.example.comaventrasafesite.repository.HazardRepository
import com.example.comaventrasafesite.ui.shared.SafeSiteEmptyState
import com.example.comaventrasafesite.ui.shared.SafeSiteListTopBar
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

fun severityColor(
    severity: String
): Color = when (severity.uppercase()) {
    "CRITICAL" -> Color(0xFFD32F2F)
    "HIGH" -> Color(0xFFF57C00)
    "MEDIUM" -> Color(0xFFFBC02D)
    "LOW" -> Color(0xFF388E3C)
    else -> Color.Gray
}

private fun severityContentColor(
    severity: String
): Color = when (severity.uppercase()) {
    "MEDIUM" -> Color(0xFF3E3200)
    else -> Color.White
}

private fun hazardStatusColor(
    status: String
): Color = when (status) {
    "closed" -> Color(0xFF388E3C)
    "in_progress" -> Color(0xFF1565C0)
    "open" -> Color(0xFFF57C00)
    else -> Color.Gray
}

private fun hazardStatusLabel(
    status: String
): String {
    return status
        .replace("_", " ")
        .replaceFirstChar {
            it.uppercase()
        }
        .ifBlank {
            "Status unavailable"
        }
}

fun formatDate(
    millis: Long
): String {
    if (millis <= 0L) {
        return "Date unavailable"
    }

    return SimpleDateFormat(
        "dd MMM yyyy, HH:mm",
        Locale.getDefault()
    ).apply {
        timeZone = TimeZone.getTimeZone(
            "Africa/Johannesburg"
        )
    }.format(Date(millis))
}

@Composable
fun HazardRegisterScreen(
    siteId: String,
    onBack: () -> Unit,
    onReportNew: () -> Unit,
    onOpenHazard: (String) -> Unit
) {
    val repository = remember {
        HazardRepository()
    }

    val loader = rememberScreenLoader()
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    var hazards by remember(siteId) {
        mutableStateOf<List<Hazard>>(emptyList())
    }

    var filter by rememberSaveable(siteId) {
        mutableStateOf("all")
    }

    fun refresh() {
        scope.launch {
            loader.run {
                hazards = repository.getHazardsForSite(siteId)
            }
        }
    }

    LaunchedEffect(siteId) {
        refresh()
    }

    val shownHazards = remember(hazards, filter) {
        if (filter == "all") {
            hazards
        } else {
            hazards.filter {
                it.status == filter
            }
        }
    }

    val loadError = loader.errorMessage

    val subtitle = when {
        loader.isLoading -> "Loading hazards…"
        loadError != null -> "Unable to load hazards"
        else -> "${hazards.size} total hazards"
    }

    Scaffold(
        topBar = {
            SafeSiteListTopBar(
                title = "Hazard Register",
                subtitle = subtitle,
                actionLabel = "Report",
                onBack = onBack,
                onCreate = onReportNew,
                onRefresh = {
                    refresh()
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when {
                loader.isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment =
                                Alignment.CenterHorizontally,
                            verticalArrangement =
                                Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator()

                            Text(
                                text = "Loading hazards…",
                                color =
                                    MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                loadError != null -> {
                    ScreenLoadError(
                        message = loadError,
                        onRetry = {
                            refresh()
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                else -> {
                    HazardSummary(
                        hazards = hazards,
                        selectedFilter = filter,
                        onFilterSelected = {
                            filter = it
                        }
                    )

                    HazardFilters(
                        selectedFilter = filter,
                        onFilterSelected = {
                            filter = it
                        }
                    )

                    if (shownHazards.isEmpty()) {
                        SafeSiteEmptyState(
                            icon = Icons.Filled.Warning,
                            title = if (filter == "all") {
                                "No hazards reported"
                            } else {
                                "No ${
                                    hazardStatusLabel(filter).lowercase()
                                } hazards"
                            },
                            description = if (filter == "all") {
                                "Use Report in the header to report a site hazard."
                            } else {
                                "Try selecting a different status filter."
                            }
                        )
                    } else {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(
                                start = 16.dp,
                                top = 14.dp,
                                end = 16.dp,
                                bottom = 24.dp
                            ),
                            verticalArrangement =
                                Arrangement.spacedBy(12.dp)
                        ) {
                            items(
                                items = shownHazards,
                                key = { it.id }
                            ) { hazard ->
                                HazardCard(
                                    hazard = hazard,
                                    onClick = {
                                        onOpenHazard(hazard.id)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HazardSummary(
    hazards: List<Hazard>,
    selectedFilter: String,
    onFilterSelected: (String) -> Unit
) {
    val summaryItems = listOf(
        "Open" to "open",
        "In progress" to "in_progress",
        "Closed" to "closed"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                horizontal = 16.dp,
                vertical = 14.dp
            ),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        summaryItems.forEach { (label, status) ->
            ElevatedCard(
                onClick = {
                    onFilterSelected(status)
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = if (selectedFilter == status) {
                        MaterialTheme.colorScheme.primaryContainer
                    } else {
                        MaterialTheme.colorScheme.surface
                    }
                ),
                elevation = CardDefaults.elevatedCardElevation(
                    defaultElevation = 1.dp
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(
                            horizontal = 8.dp,
                            vertical = 14.dp
                        ),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = hazards.count {
                            it.status == status
                        }.toString(),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = hazardStatusColor(status)
                    )

                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun HazardFilters(
    selectedFilter: String,
    onFilterSelected: (String) -> Unit
) {
    val options = listOf(
        "all" to "All",
        "open" to "Open",
        "in_progress" to "In progress",
        "closed" to "Closed"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { (value, label) ->
            FilterChip(
                selected = selectedFilter == value,
                onClick = {
                    onFilterSelected(value)
                },
                label = {
                    Text(label)
                }
            )
        }
    }
}

@Composable
private fun HazardCard(
    hazard: Hazard,
    onClick: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                enabled = hazard.id.isNotBlank(),
                onClick = onClick
            ),
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.elevatedCardElevation(
            defaultElevation = 1.dp
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = hazard.title.ifBlank {
                            "Untitled hazard"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Text(
                        text = hazard.category.ifBlank {
                            "Uncategorised"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                }

                Surface(
                    color = severityColor(hazard.severity),
                    contentColor = severityContentColor(hazard.severity),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = hazard.severity.ifBlank {
                            "Not provided"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(
                            horizontal = 9.dp,
                            vertical = 5.dp
                        )
                    )
                }
            }

            if (hazard.location.isNotBlank()) {
                Text(
                    text = "Location: ${hazard.location}",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = hazardStatusColor(hazard.status)
                        .copy(alpha = 0.12f),
                    contentColor = hazardStatusColor(hazard.status),
                    shape = RoundedCornerShape(50)
                ) {
                    Text(
                        text = hazardStatusLabel(hazard.status),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(
                            horizontal = 10.dp,
                            vertical = 5.dp
                        )
                    )
                }

                Text(
                    text = formatDate(hazard.createdAt),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}