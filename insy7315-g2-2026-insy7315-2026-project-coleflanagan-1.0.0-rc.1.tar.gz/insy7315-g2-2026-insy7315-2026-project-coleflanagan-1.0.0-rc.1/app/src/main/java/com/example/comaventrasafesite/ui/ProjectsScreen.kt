package com.example.comaventrasafesite.ui.admin

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.Project
import com.example.comaventrasafesite.model.Site
import com.example.comaventrasafesite.repository.ProjectRepository
import com.example.comaventrasafesite.ui.shared.SafeSiteEmptyState
import com.example.comaventrasafesite.ui.shared.SafeSiteListTopBar
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import kotlinx.coroutines.launch

fun projectStatusColor(status: String): Color = when (status) {
    "active" -> Color(0xFF388E3C)
    "on_hold" -> Color(0xFFF57C00)
    "completed" -> Color(0xFF1976D2)
    else -> Color(0xFF757575)
}

@Composable
fun StatusBadge(status: String) {
    val color = projectStatusColor(status)

    Surface(
        color = color.copy(alpha = 0.12f),
        contentColor = color,
        shape = RoundedCornerShape(50)
    ) {
        Text(
            ProjectRepository.label(status),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun ProjectsScreen(
    onBack: () -> Unit,
    onOpenProject: (String) -> Unit,
    onOpenSite: (String) -> Unit
) {
    val repository = remember { ProjectRepository() }
    val loader = rememberScreenLoader()
    val actions = remember { ProjectActionState() }
    val scope = rememberCoroutineScope()

    var projects by remember { mutableStateOf<List<Project>>(emptyList()) }
    var sites by remember { mutableStateOf<List<Site>>(emptyList()) }
    var refreshKey by remember { mutableIntStateOf(0) }

    var search by rememberSaveable { mutableStateOf("") }
    var showAdd by rememberSaveable { mutableStateOf(false) }
    var projectName by rememberSaveable { mutableStateOf("") }
    var clientName by rememberSaveable { mutableStateOf("") }
    var startDate by rememberSaveable { mutableStateOf("") }

    val ready = !loader.isLoading && loader.errorMessage == null

    BackHandler(enabled = actions.busy) {}

    suspend fun reload() {
        loader.run {
            val loadedProjects = repository.getProjects()
            val loadedSites = repository.getAllSites()
            projects = loadedProjects
            sites = loadedSites
        }
    }

    LaunchedEffect(refreshKey) { reload() }

    if (showAdd) {
        ProjectFormDialog(
            title = "Create project",
            busy = actions.busy,
            error = actions.message.takeIf { actions.isError },
            onDismiss = { showAdd = false },
            saveLabel = "Create",
            onSave = {
                scope.launch {
                    actions.run(
                        successMessage = "Project created.",
                        reload = { reload() },
                        onSuccess = {
                            showAdd = false
                            projectName = ""
                            clientName = ""
                            startDate = ""
                        },
                        action = {
                            repository.createProject(
                                projectName,
                                clientName,
                                startDate
                            )
                        }
                    )
                }
            }
        ) {
            Text("Enter the project details. Add sites from its details screen.")

            OutlinedTextField(
                value = projectName,
                onValueChange = { projectName = it },
                label = { Text("Project name") },
                enabled = !actions.busy,
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = clientName,
                onValueChange = { clientName = it },
                label = { Text("Client") },
                enabled = !actions.busy,
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = startDate,
                onValueChange = { startDate = it },
                label = { Text("Start date") },
                placeholder = { Text("YYYY-MM-DD") },
                enabled = !actions.busy,
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }

    Scaffold(
        containerColor = Color(0xFFF7F8F6),
        topBar = {
            SafeSiteListTopBar(
                title = "Projects & Sites",
                subtitle = when {
                    loader.isLoading -> "Loading projects and sites…"
                    !ready -> "Projects and sites unavailable"
                    else -> "${projects.size} projects · ${sites.size} sites"
                },
                actionLabel = "Add",
                onBack = { if (!actions.busy) onBack() },
                onCreate = {
                    actions.clear()
                    showAdd = true
                },
                createEnabled = ready && !actions.busy,
                onRefresh = if (!loader.isLoading && !actions.busy) {
                    { refreshKey++ }
                } else null,
                containerColor = Color(0xFF496F42),
                contentColor = Color.White
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            when {
                loader.isLoading -> ProjectWaiting()

                loader.errorMessage != null -> ScreenLoadError(
                    message = loader.errorMessage.orEmpty(),
                    onRetry = { refreshKey++ },
                    modifier = Modifier.fillMaxSize()
                )

                else -> {
                    val projectIds = projects.map { it.id }.toSet()
                    val shownProjects = projects.filter {
                        search.isBlank() ||
                                it.name.contains(search, true) ||
                                it.clientName.contains(search, true)
                    }
                    val unlinkedSites = sites.filter {
                        (it.projectId.isBlank() || it.projectId !in projectIds) &&
                                (
                                        search.isBlank() ||
                                                it.name.contains(search, true) ||
                                                it.address.contains(search, true)
                                        )
                    }

                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item { ProjectMessage(actions) }

                        item {
                            ProjectPanel("Overview") {
                                Text(
                                    "${projects.size} projects · " +
                                            "${projects.count { it.status == "active" }} active"
                                )
                                Text(
                                    "${sites.size} sites · " +
                                            "${sites.count { it.status == "active" }} active"
                                )
                            }
                        }

                        item {
                            OutlinedTextField(
                                value = search,
                                onValueChange = { search = it },
                                label = { Text("Search projects and unlinked sites") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        items(shownProjects, key = { "project-${it.id}" }) { project ->
                            ElevatedCard(
                                onClick = { onOpenProject(project.id) },
                                enabled = !actions.busy,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(18.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(18.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        project.name.ifBlank { "Unnamed project" },
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(project.clientName.ifBlank { "No client recorded" })
                                    Text(
                                        "Started ${project.startDate.ifBlank { "date unavailable" }}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Text(
                                        "${sites.count { it.projectId == project.id }} linked sites",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    StatusBadge(project.status)
                                }
                            }
                        }

                        if (unlinkedSites.isNotEmpty()) {
                            item {
                                Text(
                                    "Unlinked sites",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }

                            items(unlinkedSites, key = { "site-${it.id}" }) { site ->
                                ProjectSiteCard(
                                    site = site,
                                    enabled = !actions.busy,
                                    onClick = { onOpenSite(site.id) }
                                )
                            }
                        }

                        if (shownProjects.isEmpty() && unlinkedSites.isEmpty()) {
                            item {
                                SafeSiteEmptyState(
                                    icon = Icons.Default.List,
                                    title = if (search.isBlank()) {
                                        "No projects yet"
                                    } else {
                                        "No matching results"
                                    },
                                    description = if (search.isBlank()) {
                                        "Use Add in the header to create a project."
                                    } else {
                                        "Try another project, client or unlinked site."
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}