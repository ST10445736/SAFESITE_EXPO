package com.example.comaventrasafesite.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import kotlinx.coroutines.tasks.await

data class WorkerSiteContext(
    val siteId: String,
    val siteName: String,
    val projectName: String
)

class WorkerSessionRepository {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    private val assignmentRepository =
        SiteAssignmentRepository()

    suspend fun getActiveSite(
        workerId: String
    ): WorkerSiteContext? {
        require(
            workerId.isNotBlank() &&
                    auth.currentUser?.uid == workerId
        ) {
            "Please sign in again."
        }

        val profile = db.collection("users")
            .document(workerId)
            .get(Source.SERVER)
            .await()

        check(
            profile.exists() &&
                    profile.getString("status") == "active"
        ) {
            "Your account is unavailable or inactive. Please sign in again."
        }

        val today = SiteAssignmentRepository.today()

        val assignments = assignmentRepository
            .getMyAssignments(workerId)
            .filter { assignment ->
                assignment.endDate.isBlank() &&
                        (
                                assignment.startDate.isBlank() ||
                                        assignment.startDate <= today
                                )
            }
            .sortedByDescending {
                it.startDate
            }

        for (assignment in assignments) {
            val site = db.collection("sites")
                .document(assignment.siteId)
                .get(Source.SERVER)
                .await()

            if (
                !site.exists() ||
                site.getString("status") != "active"
            ) {
                continue
            }

            val projectId = site.getString("projectId").orEmpty()

            val project = if (projectId.isNotBlank()) {
                db.collection("projects")
                    .document(projectId)
                    .get(Source.SERVER)
                    .await()
            } else {
                null
            }

            if (
                projectId.isNotBlank() &&
                (
                        project == null ||
                                !project.exists() ||
                                project.getString("status") != "active"
                        )
            ) {
                continue
            }

            check(auth.currentUser?.uid == workerId) {
                "Your signed-in account has changed. Please sign in again."
            }

            return WorkerSiteContext(
                siteId = site.id,
                siteName = site.getString("name")
                    ?.takeIf { it.isNotBlank() }
                    ?: "Assigned site",
                projectName = project?.getString("name").orEmpty()
            )
        }

        return null
    }
}