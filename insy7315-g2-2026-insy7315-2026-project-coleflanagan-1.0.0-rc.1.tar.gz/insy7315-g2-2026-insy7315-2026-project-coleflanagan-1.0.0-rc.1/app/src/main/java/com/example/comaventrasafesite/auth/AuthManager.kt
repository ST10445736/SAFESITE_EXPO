package com.example.comaventrasafesite.auth

import com.example.comaventrasafesite.model.Role
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await

class AuthManager {

    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    suspend fun signIn(
        email: String,
        password: String
    ): Result<Role> {
        return try {
            val authResult = auth
                .signInWithEmailAndPassword(email, password)
                .await()

            val uid = authResult.user?.uid
                ?: throw IllegalStateException(
                    "Sign in failed. Please try again."
                )

            val userDocument = db
                .collection("users")
                .document(uid)
                .get(Source.SERVER)
                .await()

            val role = AccountAccess.requireRole(
                profileExists = userDocument.exists(),
                status = userDocument.getString("status"),
                roleName = userDocument.getString("role")
            )

            Result.success(role)
        } catch (e: CancellationException) {
            auth.signOut()
            throw e
        } catch (e: Exception) {
            auth.signOut()
            Result.failure(e)
        }
    }

    fun signOut() {
        auth.signOut()
    }

    fun currentUserEmail(): String? {
        return auth.currentUser?.email
    }
}