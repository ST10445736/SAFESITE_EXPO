package com.example.comaventrasafesite.ui.training

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.TrainingRecord
import com.example.comaventrasafesite.repository.TrainingRepository
import com.example.comaventrasafesite.repository.WorkerOption
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

private val commonTrainingCourses = listOf(
    "Site induction",
    "Working at heights",
    "First aid level 1",
    "Fire fighting",
    "Scaffolding",
    "Excavation safety",
    "Forklift operator"
)

private val trainingValidityOptions = listOf(
    "No expiry" to null,
    "1 year" to 1,
    "2 years" to 2,
    "3 years" to 3
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTrainingScreen(
    siteId: String,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val repository = remember {
        TrainingRepository()
    }

    val scope = rememberCoroutineScope()
    val workerLoader = rememberScreenLoader()
    val scrollState = rememberScrollState()

    var workers by remember {
        mutableStateOf<List<WorkerOption>>(emptyList())
    }

    var workerMenuOpen by remember {
        mutableStateOf(false)
    }

    var workerId by rememberSaveable(siteId) {
        mutableStateOf("")
    }

    var workerName by rememberSaveable(siteId) {
        mutableStateOf("")
    }

    var courseName by rememberSaveable(siteId) {
        mutableStateOf("")
    }

    var provider by rememberSaveable(siteId) {
        mutableStateOf("")
    }

    var certificateNumber by rememberSaveable(siteId) {
        mutableStateOf("")
    }

    var completedAt by rememberSaveable(siteId) {
        mutableStateOf<Long?>(null)
    }

    var validYears by rememberSaveable(siteId) {
        mutableStateOf<Int?>(null)
    }

    var validitySelected by rememberSaveable(siteId) {
        mutableStateOf(false)
    }

    var showDatePicker by remember {
        mutableStateOf(false)
    }

    var isSaving by remember {
        mutableStateOf(false)
    }

    var errorMessage by remember {
        mutableStateOf<String?>(null)
    }

    BackHandler(enabled = isSaving) {
        // Wait for the current save to finish.
    }

    fun loadWorkers() {
        scope.launch {
            workerLoader.run {
                workers = repository.getWorkers()
            }
        }
    }

    LaunchedEffect(siteId) {
        loadWorkers()
    }

    val expiresAt = completedAt?.let { completionDate ->
        validYears?.let { years ->
            TrainingRepository.expiryAfterYears(
                completedAt = completionDate,
                years = years
            )
        }
    }

    if (showDatePicker) {
        val pickerState = rememberDatePickerState(
            initialSelectedDateMillis = completedAt?.let {
                TrainingRepository.pickerFromCompletion(it)
            }
        )

        val selectedCompletion = pickerState.selectedDateMillis?.let {
            TrainingRepository.completionFromPicker(it)
        }

        DatePickerDialog(
            onDismissRequest = {
                showDatePicker = false
            },
            confirmButton = {
                TextButton(
                    enabled = selectedCompletion != null &&
                            selectedCompletion <= System.currentTimeMillis(),
                    onClick = {
                        completedAt = selectedCompletion
                        errorMessage = null
                        showDatePicker = false
                    }
                ) {
                    Text("Confirm")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showDatePicker = false
                    }
                ) {
                    Text("Cancel")
                }
            }
        ) {
            DatePicker(
                state = pickerState
            )
        }
    }

    fun saveTraining() {
        if (isSaving) return

        val completionDate = completedAt

        errorMessage = when {
            siteId.isBlank() -> {
                "No assigned site was found."
            }

            workerName.isBlank() -> {
                "Choose or enter a worker."
            }

            workerName.trim().length > 200 -> {
                "Keep the worker name under 200 characters."
            }

            courseName.isBlank() -> {
                "Enter the completed course."
            }

            courseName.trim().length > 200 -> {
                "Keep the course name under 200 characters."
            }

            provider.length > 200 ||
                    certificateNumber.length > 200 -> {
                "Keep the provider and certificate fields under 200 characters."
            }

            completionDate == null -> {
                "Choose the course completion date."
            }

            completionDate > System.currentTimeMillis() -> {
                "The completion date cannot be in the future."
            }

            !validitySelected -> {
                "Choose a validity period or select No expiry."
            }

            workerId.isNotBlank() &&
                    (
                            workerLoader.isLoading ||
                                    workerLoader.errorMessage != null
                            ) -> {
                "Load the worker accounts before saving linked training."
            }

            workerId.isNotBlank() &&
                    workers.none { it.id == workerId } -> {
                "The selected worker is no longer available. Choose again."
            }

            else -> {
                null
            }
        }

        if (errorMessage != null || completionDate == null) {
            return
        }

        isSaving = true

        val record = TrainingRecord(
            siteId = siteId,
            workerId = workerId,
            workerName = workerName.trim(),
            courseName = courseName.trim(),
            provider = provider.trim(),
            certificateNumber = certificateNumber.trim(),
            completedAt = completionDate,
            expiresAt = expiresAt
        )

        scope.launch {
            try {
                repository.addRecord(record)
                    .onSuccess {
                        onSaved()
                    }
                    .onFailure { error ->
                        errorMessage = error.message
                            ?: "The training record could not be saved."
                    }
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                errorMessage = error.message
                    ?: "The training record could not be saved."
            } finally {
                isSaving = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Record Training",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        enabled = !isSaving
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(
                    start = 20.dp,
                    top = 8.dp,
                    end = 20.dp,
                    bottom = 28.dp
                ),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            if (isSaving) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth()
                )
            }

            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surface
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CheckCircle,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(12.dp)
                        )
                    }

                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "Add a completed course",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "Choose the completion date and validity " +
                                    "to calculate the expiry status.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 3.dp)
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TrainingFormHeading(
                    title = "Worker",
                    subtitle = "Choose an active Worker account or enter " +
                            "a name manually.",
                    modifier = Modifier.weight(1f)
                )

                IconButton(
                    onClick = {
                        loadWorkers()
                    },
                    enabled = !isSaving && !workerLoader.isLoading
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = "Refresh worker accounts"
                    )
                }
            }

            workerLoader.errorMessage?.let { message ->
                ScreenLoadError(
                    message = message,
                    onRetry = {
                        loadWorkers()
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Box(
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(
                    onClick = {
                        workerMenuOpen = true
                    },
                    enabled = !isSaving &&
                            !workerLoader.isLoading &&
                            workerLoader.errorMessage == null &&
                            workers.isNotEmpty(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    if (workerLoader.isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Filled.Person,
                            contentDescription = null
                        )
                    }

                    Spacer(
                        modifier = Modifier.width(8.dp)
                    )

                    Text(
                        text = when {
                            workerLoader.isLoading -> {
                                "Loading workers…"
                            }

                            workerLoader.errorMessage != null -> {
                                "Worker accounts unavailable"
                            }

                            workers.isEmpty() -> {
                                "No active worker accounts"
                            }

                            workerName.isBlank() -> {
                                "Choose a worker"
                            }

                            else -> {
                                workerName
                            }
                        },
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                DropdownMenu(
                    expanded = workerMenuOpen,
                    onDismissRequest = {
                        workerMenuOpen = false
                    },
                    modifier = Modifier.heightIn(max = 320.dp)
                ) {
                    workers.forEach { worker ->
                        DropdownMenuItem(
                            text = {
                                Text(worker.name)
                            },
                            onClick = {
                                workerId = worker.id
                                workerName = worker.name
                                workerMenuOpen = false
                                errorMessage = null
                            }
                        )
                    }
                }
            }

            OutlinedTextField(
                value = workerName,
                onValueChange = {
                    workerName = it
                    workerId = ""
                    errorMessage = null
                },
                label = {
                    Text("Worker name")
                },
                supportingText = {
                    Text(
                        text = when {
                            workerId.isNotBlank() -> {
                                "Linked to an existing account"
                            }

                            workerName.isNotBlank() -> {
                                "Manually entered; not linked to an account"
                            }

                            else -> {
                                "You may enter a name for a worker without an account"
                            }
                        }
                    )
                },
                isError = workerName.length > 200,
                singleLine = true,
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth()
            )

            HorizontalDivider()

            TrainingFormHeading(
                title = "Course",
                subtitle = "Choose a common course or enter another course name."
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                commonTrainingCourses.forEach { course ->
                    FilterChip(
                        selected = courseName == course,
                        onClick = {
                            courseName = course
                            errorMessage = null
                        },
                        enabled = !isSaving,
                        label = {
                            Text(course)
                        }
                    )
                }
            }

            OutlinedTextField(
                value = courseName,
                onValueChange = {
                    courseName = it
                    errorMessage = null
                },
                label = {
                    Text("Course name")
                },
                isError = courseName.length > 200,
                singleLine = true,
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = provider,
                onValueChange = {
                    provider = it
                    errorMessage = null
                },
                label = {
                    Text("Training provider")
                },
                placeholder = {
                    Text("Organisation that delivered the course")
                },
                isError = provider.length > 200,
                singleLine = true,
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = certificateNumber,
                onValueChange = {
                    certificateNumber = it
                    errorMessage = null
                },
                label = {
                    Text("Certificate number")
                },
                supportingText = {
                    Text("Optional")
                },
                isError = certificateNumber.length > 200,
                singleLine = true,
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth()
            )

            HorizontalDivider()

            TrainingFormHeading(
                title = "Completion and validity",
                subtitle = "Choose when the course was completed and how " +
                        "long it remains valid."
            )

            OutlinedButton(
                onClick = {
                    showDatePicker = true
                },
                enabled = !isSaving,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(
                    text = completedAt?.let {
                        "Completed ${trainingDateOnly(it)}"
                    } ?: "Choose completion date"
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                trainingValidityOptions.forEach { (label, years) ->
                    FilterChip(
                        selected = validitySelected && validYears == years,
                        onClick = {
                            validYears = years
                            validitySelected = true
                            errorMessage = null
                        },
                        enabled = !isSaving,
                        label = {
                            Text(label)
                        }
                    )
                }
            }

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.primaryContainer
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "Expiry",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Text(
                        text = when {
                            completedAt == null || !validitySelected -> {
                                "Choose a completion date and validity."
                            }

                            validYears == null -> {
                                "This training does not expire"
                            }

                            else -> {
                                expiresAt?.let {
                                    trainingDateOnly(it)
                                } ?: "Expiry unavailable"
                            }
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    if (expiresAt != null && validitySelected) {
                        Text(
                            text = "Valid through the end of this date " +
                                    "in South Africa.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            errorMessage?.let { message ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    contentColor = MaterialTheme.colorScheme.onErrorContainer
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Warning,
                            contentDescription = null
                        )

                        Text(
                            text = message,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Button(
                onClick = {
                    saveTraining()
                },
                enabled = !isSaving,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                if (isSaving) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )

                    Text(
                        text = "Saving…",
                        modifier = Modifier.padding(start = 10.dp)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null
                    )

                    Text(
                        text = "Save Training",
                        modifier = Modifier.padding(start = 10.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun TrainingFormHeading(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}