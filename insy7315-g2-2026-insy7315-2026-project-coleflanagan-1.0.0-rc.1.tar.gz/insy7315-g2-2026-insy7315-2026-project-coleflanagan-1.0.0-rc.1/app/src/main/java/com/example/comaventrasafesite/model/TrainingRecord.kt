package com.example.comaventrasafesite.model

/**
 * A training course a worker completed (FR15). expiresAt = null means
 * the training never expires (e.g. once-off site induction).
 */
data class TrainingRecord(
    val id: String = "",
    val siteId: String = "",
    val workerId: String = "",
    val workerName: String = "",
    val courseName: String = "",
    val provider: String = "",
    val certificateNumber: String = "",
    val completedAt: Long = 0L,
    val expiresAt: Long? = null,
    val recordedBy: String = "",
    val createdAt: Long = 0L
)