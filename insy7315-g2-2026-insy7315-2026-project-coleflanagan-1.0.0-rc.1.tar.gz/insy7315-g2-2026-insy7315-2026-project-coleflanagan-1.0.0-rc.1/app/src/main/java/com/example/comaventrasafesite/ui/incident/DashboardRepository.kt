package com.example.comaventrasafesite.repository

import com.example.comaventrasafesite.model.CorrectiveAction
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class SafetyKpis(
    val periodDays: Int?,
    val hazardsReported: Int = 0,
    val hazardsOpen: Int = 0,
    val hazardsInProgress: Int = 0,
    val hazardsClosed: Int = 0,
    val highRiskOpen: Int = 0,
    val hazardClosureRate: Int = 0,
    val avgDaysToClose: Double? = null,
    val pendingActions: Int = 0,
    val overdueActions: Int = 0,
    val incidentsReported: Int = 0,
    val incidentsOpen: Int = 0,
    val injuries: Int = 0,
    val nearMisses: Int = 0,
    val incidentsByType: Map<String, Int> = emptyMap(),
    val daysSinceLastInjury: Int? = null,
    val trainingTotal: Int = 0,
    val trainingValid: Int = 0,
    val trainingExpiring: Int = 0,
    val trainingExpired: Int = 0,
    val trainingCompliance: Int = 0,
    val onSiteNow: Int = 0,
    val generatedAt: Long = 0L,
    val undatedHazardClosures: Int = 0
)

class DashboardRepository {

    private val db = FirebaseFirestore.getInstance()
    private val hazardRepo = HazardRepository()
    private val incidentRepo = IncidentRepository()
    private val trainingRepo = TrainingRepository()
    private val attendanceRepo = AttendanceRepository()

    companion object {
        private const val DAY_MILLIS = 86_400_000L

        fun timestamp(millis: Long): String {
            if (millis <= 0L) return "Time unavailable"

            return SimpleDateFormat(
                "dd MMM yyyy, HH:mm",
                Locale.US
            ).apply {
                timeZone = TimeZone.getTimeZone("Africa/Johannesburg")
            }.format(Date(millis)) + " SAST"
        }
    }

    private fun startOfDay(millis: Long): Long =
        Calendar.getInstance(
            TimeZone.getTimeZone("Africa/Johannesburg")
        ).apply {
            timeInMillis = millis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

    private fun percent(part: Int, total: Int): Int =
        if (total == 0) 0 else ((part.toLong() * 100L) / total).toInt()

    suspend fun getKpis(
        siteId: String,
        periodDays: Int?
    ): SafetyKpis = coroutineScope {
        require(siteId.isNotBlank()) { "A site is required." }
        require(periodDays == null || periodDays in listOf(7, 30, 90)) {
            "Choose a supported reporting period."
        }

        val now = System.currentTimeMillis()
        val cutoff = periodDays?.let { now - it * DAY_MILLIS } ?: 0L

        fun inPeriod(millis: Long): Boolean =
            millis > 0L && millis >= cutoff && millis <= now

        val hazardsRequest = async {
            hazardRepo.getHazardsForSite(siteId)
        }
        val incidentsRequest = async {
            incidentRepo.getIncidentsForSite(siteId)
        }
        val trainingRequest = async {
            trainingRepo.getRecordsForSite(siteId)
        }
        val attendanceRequest = async {
            attendanceRepo.getSiteHeadcount(siteId)
        }

        val hazards = hazardsRequest.await()
        val incidents = incidentsRequest.await()
        val training = trainingRequest.await()
        val attendance = attendanceRequest.await()

        check(hazards.all {
            it.status in listOf("open", "in_progress", "closed")
        }) {
            "A hazard has an unrecognised status. Review the hazard register."
        }

        check(incidents.all {
            it.status in listOf(
                IncidentRepository.REPORTED,
                IncidentRepository.INVESTIGATING,
                IncidentRepository.ACTIONS_PENDING,
                IncidentRepository.CLOSED
            )
        }) {
            "An incident has an unrecognised status. Review the incident register."
        }

        val actions = getActionsForHazards(hazards.map { it.id })

        check(actions.all { it.status in listOf("pending", "done") }) {
            "A corrective action has an unrecognised status."
        }

        val pending = actions.filter { it.status == "pending" }

        check(pending.all { it.dueDate > 0L }) {
            "A pending corrective action has no valid due date."
        }

        val periodHazards = hazards.filter { inPeriod(it.createdAt) }

        // Closure rate tracks the current status of hazards reported
        // during the selected period.
        val reportedHazardsNowClosed = periodHazards.count {
            it.status == "closed"
        }

        // Closed-in-period tracks the closure date, even when the
        // hazard was originally reported before the selected period.
        val datedClosures = hazards.filter {
            it.status == "closed" &&
                    it.closedAt?.let { closed ->
                        closed > 0L && closed >= it.createdAt
                    } == true
        }

        val closedInPeriod = datedClosures.filter {
            inPeriod(it.closedAt ?: 0L)
        }

        val closeTimes = closedInPeriod.map {
            ((it.closedAt ?: it.createdAt) - it.createdAt).toDouble() /
                    DAY_MILLIS
        }

        val periodIncidents = incidents.filter { inPeriod(it.createdAt) }

        fun isType(actual: String, expected: String): Boolean =
            actual.trim().equals(expected, ignoreCase = true)

        val injuries = incidents.filter { isType(it.type, "Injury") }
        val lastInjury = injuries
            .filter { it.occurredAt in 1L..now }
            .maxOfOrNull { it.occurredAt }

        val statuses = training.map {
            TrainingRepository.statusOf(it, now)
        }

        val expired = statuses.count {
            it == TrainingRepository.EXPIRED
        }

        SafetyKpis(
            periodDays = periodDays,
            hazardsReported = periodHazards.size,
            hazardsOpen = hazards.count { it.status == "open" },
            hazardsInProgress = hazards.count { it.status == "in_progress" },
            hazardsClosed = closedInPeriod.size,
            highRiskOpen = hazards.count {
                it.status != "closed" &&
                        (
                                it.severity.equals("HIGH", true) ||
                                        it.severity.equals("CRITICAL", true)
                                )
            },
            hazardClosureRate = percent(
                reportedHazardsNowClosed,
                periodHazards.size
            ),
            avgDaysToClose = closeTimes.takeIf { it.isNotEmpty() }?.average(),
            pendingActions = pending.size,
            overdueActions = pending.count { it.dueDate < now },
            incidentsReported = periodIncidents.size,
            incidentsOpen = incidents.count {
                it.status != IncidentRepository.CLOSED
            },
            injuries = injuries.count { inPeriod(it.occurredAt) },
            nearMisses = incidents.count {
                isType(it.type, "Near miss") && inPeriod(it.occurredAt)
            },
            incidentsByType = periodIncidents.groupingBy {
                it.type.trim().ifBlank { "Unspecified" }
            }.eachCount(),
            daysSinceLastInjury = lastInjury?.let {
                ((startOfDay(now) - startOfDay(it)) / DAY_MILLIS)
                    .toInt()
                    .coerceAtLeast(0)
            },
            trainingTotal = training.size,
            trainingValid = statuses.count {
                it == TrainingRepository.VALID
            },
            trainingExpiring = statuses.count {
                it == TrainingRepository.EXPIRING
            },
            trainingExpired = expired,
            trainingCompliance = percent(
                training.size - expired,
                training.size
            ),
            onSiteNow = attendance.size,
            generatedAt = System.currentTimeMillis(),
            undatedHazardClosures = hazards.count {
                it.status == "closed" &&
                        (
                                it.closedAt == null ||
                                        (it.closedAt ?: 0L) <= 0L ||
                                        (it.closedAt ?: 0L) < it.createdAt
                                )
            }
        )
    }

    private suspend fun getActionsForHazards(
        hazardIds: List<String>
    ): List<CorrectiveAction> {
        if (hazardIds.isEmpty()) return emptyList()

        check(hazardIds.all { it.isNotBlank() }) {
            "A hazard has no valid reference."
        }

        return hazardIds.distinct().chunked(30).flatMap { chunk ->
            db.collection("correctiveActions")
                .whereIn("hazardId", chunk)
                .get(Source.SERVER)
                .await()
                .documents
                .map { document ->
                    val action = document.toObject(CorrectiveAction::class.java)
                        ?: error("A corrective action could not be read.")

                    action.copy(id = document.id)
                }
        }
    }

    fun buildReportText(k: SafetyKpis, siteName: String): String {
        val period = k.periodDays?.let { "last $it days" } ?: "all time"

        return buildString {
            appendLine("SafeSite Safety Report")
            appendLine(siteName.ifBlank { "Site" })
            appendLine("Period: $period")
            appendLine("Refreshed: ${timestamp(k.generatedAt)}")
            appendLine()
            appendLine("HAZARDS")
            appendLine("Reported in period: ${k.hazardsReported}")
            appendLine("Closed in period: ${k.hazardsClosed}")
            appendLine("Open now: ${k.hazardsOpen}")
            appendLine("In progress now: ${k.hazardsInProgress}")
            appendLine("High-risk not closed: ${k.highRiskOpen}")

            appendLine(
                "Reported hazards now closed: " +
                        if (k.hazardsReported == 0) {
                            "N/A"
                        } else {
                            "${k.hazardClosureRate}%"
                        }
            )

            appendLine(
                "Average closure time: " +
                        (
                                k.avgDaysToClose?.let {
                                    String.format(Locale.US, "%.1f days", it)
                                } ?: "N/A"
                                )
            )

            appendLine("Pending actions now: ${k.pendingActions}")
            appendLine("Overdue actions now: ${k.overdueActions}")

            if (k.undatedHazardClosures > 0) {
                appendLine(
                    "Note: ${k.undatedHazardClosures} closed hazards lack valid closure dates and are excluded from dated closure metrics."
                )
            }

            appendLine()
            appendLine("INCIDENTS")
            appendLine("Reported in period: ${k.incidentsReported}")
            appendLine("Still open now: ${k.incidentsOpen}")
            appendLine("Injuries occurring in period: ${k.injuries}")
            appendLine("Near misses occurring in period: ${k.nearMisses}")
            appendLine(
                "Days since last recorded injury: " +
                        (k.daysSinceLastInjury?.toString() ?: "No dated injury recorded")
            )

            if (k.incidentsByType.isNotEmpty()) {
                appendLine("Reported incidents by type:")
                k.incidentsByType.toSortedMap().forEach { (type, count) ->
                    appendLine("$type: $count")
                }
            }

            appendLine()
            appendLine("TRAINING RECORD VALIDITY")

            if (k.trainingTotal == 0) {
                appendLine("N/A — no training records.")
            } else {
                appendLine("Not expired: ${k.trainingCompliance}%")
                appendLine("Total records: ${k.trainingTotal}")
                appendLine("Valid: ${k.trainingValid}")
                appendLine("Expiring soon: ${k.trainingExpiring}")
                appendLine("Expired: ${k.trainingExpired}")
            }

            appendLine(
                "Record validity does not confirm that every worker has every required course."
            )
            appendLine()
            appendLine("On site at refresh: ${k.onSiteNow}")
            append("Current-state figures are snapshots, not continuous monitoring.")
        }
    }
}