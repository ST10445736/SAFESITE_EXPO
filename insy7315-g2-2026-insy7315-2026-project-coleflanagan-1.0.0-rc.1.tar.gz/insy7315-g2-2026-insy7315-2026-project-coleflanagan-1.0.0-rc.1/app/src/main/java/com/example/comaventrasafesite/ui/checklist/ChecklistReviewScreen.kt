package com.example.comaventrasafesite.ui.checklist

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.ChecklistSubmission
import com.example.comaventrasafesite.repository.AttendanceRepository
import com.example.comaventrasafesite.repository.ChecklistRepository
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import com.example.comaventrasafesite.ui.supervisor.SupervisorBottomBar
import com.example.comaventrasafesite.ui.supervisor.SupervisorDestination
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@Composable
fun ChecklistReviewScreen(
    siteId: String,
    onNavigate: (SupervisorDestination) -> Unit
) {
    val repository = remember {
        ChecklistRepository()
    }

    val attendanceRepository = remember {
        AttendanceRepository()
    }

    val scope = rememberCoroutineScope()
    val loader = rememberScreenLoader()

    var submissions by remember(siteId) {
        mutableStateOf<List<ChecklistSubmission>>(emptyList())
    }

    var workerNames by remember(siteId) {
        mutableStateOf<Map<String, String>>(emptyMap())
    }

    fun refresh() {
        scope.launch {
            loader.run {
                val loadedSubmissions =
                    repository.getTodaysSubmissions(siteId)

                val loadedNames =
                    attendanceRepository.getWorkerNames(
                        loadedSubmissions.map {
                            it.workerId
                        }
                    )

                submissions = loadedSubmissions
                workerNames = loadedNames
            }
        }
    }

    LaunchedEffect(siteId) {
        refresh()
    }

    val questions = repository.defaultQuestions
    val loadError = loader.errorMessage

    val incompleteCount = submissions.count {
        !checklistComplete(
            submission = it,
            questions = questions
        )
    }

    val subtitle = when {
        loader.isLoading -> {
            "Loading today's checklists…"
        }

        loadError != null -> {
            "Unable to load submissions"
        }

        else -> {
            "${submissions.size} submitted · $incompleteCount incomplete"
        }
    }

    Scaffold(
        bottomBar = {
            SupervisorBottomBar(
                selectedDestination = SupervisorDestination.SAFETY,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Surface(
                color = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(
                            horizontal = 20.dp,
                            vertical = 22.dp
                        ),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "Safety Review",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimary.copy(
                                alpha = 0.75f
                            )
                        )
                    }

                    IconButton(
                        onClick = {
                            refresh()
                        },
                        enabled = !loader.isLoading
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Refresh checklists"
                        )
                    }
                }
            }

            when {
                loader.isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }

                loadError != null -> {
                    ScreenLoadError(
                        message = loadError,
                        onRetry = {
                            refresh()
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                submissions.isEmpty() -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(28.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No checklist submissions yet today.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                else -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(
                            items = submissions,
                            key = { it.id }
                        ) { submission ->
                            ChecklistSubmissionCard(
                                submission = submission,
                                questions = questions,
                                workerName =
                                    workerNames[submission.workerId]
                                        ?: "Worker account unavailable"
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChecklistSubmissionCard(
    submission: ChecklistSubmission,
    questions: List<String>,
    workerName: String
) {
    val complete = checklistComplete(
        submission = submission,
        questions = questions
    )

    val missingItems = questions.count {
        submission.answers[it] != true
    }

    val unexpectedItems = submission.answers.keys.any {
        it !in questions
    }

    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                Text(
                    text = workerName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )

                Text(
                    text = if (complete) {
                        "COMPLETE"
                    } else {
                        "INCOMPLETE"
                    },
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (complete) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.error
                    }
                )
            }

            Text(
                text = "Submitted ${
                    formatChecklistTime(submission.submittedAt)
                }",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Text(
                text = when {
                    unexpectedItems -> {
                        "Unexpected checklist items are present. " +
                                "Review the submission."
                    }

                    missingItems > 0 -> {
                        "$missingItems item(s) require attention"
                    }

                    else -> {
                        "All safety items confirmed"
                    }
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            HorizontalDivider()

            questions.forEach { question ->
                val answer = submission.answers[question]

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = question,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.weight(1f)
                    )

                    Text(
                        text = when (answer) {
                            true -> "Yes"
                            false -> "No"
                            null -> "Not answered"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = if (answer == true) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.error
                        }
                    )
                }
            }
        }
    }
}

private fun checklistComplete(
    submission: ChecklistSubmission,
    questions: List<String>
): Boolean {
    val expected = questions.toSet()

    return submission.answers.keys == expected &&
            expected.all {
                submission.answers[it] == true
            }
}

private fun formatChecklistTime(
    timestamp: Long
): String {
    if (timestamp <= 0L) {
        return "time unavailable"
    }

    return SimpleDateFormat(
        "dd MMM yyyy, HH:mm",
        Locale.getDefault()
    ).apply {
        timeZone = TimeZone.getTimeZone(
            "Africa/Johannesburg"
        )
    }.format(Date(timestamp))
}