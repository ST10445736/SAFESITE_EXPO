package com.example.comaventrasafesite.repository

/*
 * Site-assignment resolution is identical for workers and supervisors.
 * These aliases reuse the existing tested implementation without
 * duplicating its Firestore logic.
 */
typealias SupervisorSiteContext = WorkerSiteContext
typealias SupervisorSessionRepository = WorkerSessionRepository