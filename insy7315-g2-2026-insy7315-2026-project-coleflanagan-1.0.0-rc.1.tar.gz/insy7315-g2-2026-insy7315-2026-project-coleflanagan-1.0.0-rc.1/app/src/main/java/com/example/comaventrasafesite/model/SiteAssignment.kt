package com.example.comaventrasafesite.model

data class SiteAssignment(
    val id: String = "",
    val siteId: String = "",
    val workerId: String = "",
    val startDate: String = "",
    val endDate: String = ""
)