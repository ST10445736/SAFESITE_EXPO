package com.example.comaventrasafesite.ui.shared

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class NextAction(val label: String, val onClick: () -> Unit)

/**
 * Generic stub screen — shows a title + list of buttons to move to
 * the next screen(s) in the flow. Partner replaces this with real
 * UI per screen once navigation is confirmed working end-to-end.
 */
@Composable
fun PlaceholderScreen(
    title: String,
    subtitle: String = "",
    actions: List<NextAction>,
    onBack: (() -> Unit)? = null
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(24.dp))

        Text(text = title, style = MaterialTheme.typography.headlineSmall)
        if (subtitle.isNotBlank()) {
            Text(text = subtitle, style = MaterialTheme.typography.bodyMedium)
        }

        Spacer(modifier = Modifier.height(24.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(actions) { action ->
                Button(
                    onClick = action.onClick,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(action.label)
                }
            }
        }

        if (onBack != null) {
            TextButton(onClick = onBack) {
                Text("Back")
            }
        }
    }
}