package com.example.comaventrasafesite.ui.incident

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.Incident
import com.example.comaventrasafesite.model.IncidentEvent
import com.example.comaventrasafesite.repository.IncidentRepository
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private val incidentLifecycle = listOf(
    IncidentRepository.REPORTED,
    IncidentRepository.INVESTIGATING,
    IncidentRepository.ACTIONS_PENDING,
    IncidentRepository.CLOSED
)

private val incidentSuccess = Color(0xFF388E3C)

private fun detailStatusColor(
    status: String
): Color = when (status) {
    IncidentRepository.REPORTED -> Color(0xFFF57C00)
    IncidentRepository.INVESTIGATING -> Color(0xFF1565C0)
    IncidentRepository.ACTIONS_PENDING -> Color(0xFF7B1FA2)
    IncidentRepository.CLOSED -> incidentSuccess
    else -> Color.Gray
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IncidentDetailScreen(
    incidentId: String,
    onBack: () -> Unit
) {
    val repository = remember {
        IncidentRepository()
    }

    val loader = rememberScreenLoader()
    val scope = rememberCoroutineScope()

    val currentUser = FirebaseAuth.getInstance().currentUser
    val userId = currentUser?.uid.orEmpty()
    val userName = currentUser?.email.orEmpty()

    var incident by remember(incidentId) {
        mutableStateOf<Incident?>(null)
    }

    var events by remember(incidentId) {
        mutableStateOf<List<IncidentEvent>>(emptyList())
    }

    var canManage by remember(incidentId) {
        mutableStateOf(false)
    }

    var isSaving by remember {
        mutableStateOf(false)
    }

    var message by remember {
        mutableStateOf<String?>(null)
    }

    var isError by remember {
        mutableStateOf(false)
    }

    var investigatorName by rememberSaveable(incidentId) {
        mutableStateOf("")
    }

    var rootCause by rememberSaveable(incidentId) {
        mutableStateOf("")
    }

    var findings by rememberSaveable(incidentId) {
        mutableStateOf("")
    }

    var actionsRequired by rememberSaveable(incidentId) {
        mutableStateOf("")
    }

    var closingNote by rememberSaveable(incidentId) {
        mutableStateOf("")
    }

    var showCloseConfirmation by remember {
        mutableStateOf(false)
    }

    BackHandler(enabled = isSaving) {
        // Keep the current screen open while its save is in progress.
    }

    suspend fun reload() {
        loader.run {
            val loadedIncident = repository.getIncident(incidentId)

            val loadedEvents = if (loadedIncident != null) {
                repository.getEvents(incidentId)
            } else {
                emptyList()
            }

            val managementAllowed = repository.canManageIncidents()

            incident = loadedIncident
            events = loadedEvents
            canManage = managementAllowed
        }
    }

    fun runLifecycleStep(
        successMessage: String,
        step: suspend () -> Result<Unit>
    ) {
        if (isSaving || loader.isLoading) return

        isSaving = true
        message = null

        scope.launch {
            try {
                val result = step()

                result.onSuccess {
                    message = successMessage
                    isError = false

                    investigatorName = ""
                    rootCause = ""
                    findings = ""
                    actionsRequired = ""
                    closingNote = ""
                }.onFailure { error ->
                    message = error.message
                        ?: "The incident could not be updated."
                    isError = true
                }

                reload()
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                message = error.message
                    ?: "The incident could not be updated."
                isError = true
            } finally {
                isSaving = false
            }
        }
    }

    LaunchedEffect(incidentId) {
        reload()
    }

    if (showCloseConfirmation) {
        AlertDialog(
            onDismissRequest = {
                showCloseConfirmation = false
            },
            title = {
                Text("Close this incident?")
            },
            text = {
                Text(
                    "Confirm that the required actions have been completed. " +
                            "Your closing note will be saved in the incident " +
                            "record and timeline."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showCloseConfirmation = false

                        runLifecycleStep(
                            successMessage = "Incident closed successfully."
                        ) {
                            repository.closeIncident(
                                incidentId = incidentId,
                                closingNote = closingNote,
                                byUserId = userId,
                                byName = userName
                            )
                        }
                    }
                ) {
                    Text("Close incident")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showCloseConfirmation = false
                    }
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Incident Details",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        enabled = !isSaving
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            scope.launch {
                                reload()
                            }
                        },
                        enabled = !isSaving && !loader.isLoading
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Refresh incident"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        val currentIncident = incident
        val loadError = loader.errorMessage

        when {
            loader.isLoading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator()

                        Text(
                            text = "Loading incident…",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            loadError != null -> {
                ScreenLoadError(
                    message = loadError,
                    onRetry = {
                        scope.launch {
                            reload()
                        }
                    },
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                )
            }

            currentIncident == null -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error
                        )

                        Text(
                            text = "Incident not found",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "The record may have been removed.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Button(onClick = onBack) {
                            Text("Return")
                        }
                    }
                }
            }

            else -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .verticalScroll(rememberScrollState())
                        .padding(
                            start = 20.dp,
                            top = 8.dp,
                            end = 20.dp,
                            bottom = 28.dp
                        ),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    IncidentLifecycleCard(
                        status = currentIncident.status
                    )

                    IncidentInformationCard(
                        incident = currentIncident
                    )

                    message?.let { currentMessage ->
                        IncidentResultMessage(
                            message = currentMessage,
                            isError = isError,
                            onDismiss = {
                                message = null
                            }
                        )
                    }

                    IncidentPanel {
                        if (!canManage) {
                            IncidentSectionHeading(
                                title = "Incident updates",
                                subtitle = "A Safety Officer or Administrator " +
                                        "manages the investigation and closure."
                            )
                        } else {
                            when (currentIncident.status) {
                                IncidentRepository.REPORTED -> {
                                    IncidentSectionHeading(
                                        title = "Start investigation",
                                        subtitle = "Assign the person responsible " +
                                                "for investigating this incident."
                                    )

                                    OutlinedTextField(
                                        value = investigatorName,
                                        onValueChange = {
                                            investigatorName = it
                                            message = null
                                        },
                                        label = {
                                            Text("Investigator name")
                                        },
                                        singleLine = true,
                                        enabled = !isSaving,
                                        isError = investigatorName.length > 200,
                                        modifier = Modifier.fillMaxWidth()
                                    )

                                    LifecycleButton(
                                        text = "Start Investigation",
                                        isSaving = isSaving,
                                        enabled = investigatorName.isNotBlank() &&
                                                investigatorName.length <= 200,
                                        onClick = {
                                            runLifecycleStep(
                                                successMessage =
                                                    "Investigation started."
                                            ) {
                                                repository.startInvestigation(
                                                    incidentId = incidentId,
                                                    investigatorName =
                                                        investigatorName,
                                                    byUserId = userId
                                                )
                                            }
                                        }
                                    )
                                }

                                IncidentRepository.INVESTIGATING -> {
                                    IncidentSectionHeading(
                                        title = "Record findings",
                                        subtitle = "Document the root cause " +
                                                "and actions required."
                                    )

                                    IncidentTextField(
                                        value = rootCause,
                                        onValueChange = {
                                            rootCause = it
                                            message = null
                                        },
                                        label = "Root cause",
                                        enabled = !isSaving,
                                        minLines = 2
                                    )

                                    IncidentTextField(
                                        value = findings,
                                        onValueChange = {
                                            findings = it
                                        },
                                        label = "Findings",
                                        enabled = !isSaving,
                                        minLines = 3
                                    )

                                    IncidentTextField(
                                        value = actionsRequired,
                                        onValueChange = {
                                            actionsRequired = it
                                            message = null
                                        },
                                        label = "Actions required",
                                        enabled = !isSaving,
                                        minLines = 3
                                    )

                                    LifecycleButton(
                                        text = "Submit Findings",
                                        isSaving = isSaving,
                                        enabled = rootCause.isNotBlank() &&
                                                actionsRequired.isNotBlank() &&
                                                rootCause.length <= 5000 &&
                                                findings.length <= 5000 &&
                                                actionsRequired.length <= 5000,
                                        onClick = {
                                            runLifecycleStep(
                                                successMessage =
                                                    "Investigation findings recorded."
                                            ) {
                                                repository.submitFindings(
                                                    incidentId = incidentId,
                                                    rootCause = rootCause,
                                                    findings = findings,
                                                    actionsRequired =
                                                        actionsRequired,
                                                    byUserId = userId,
                                                    byName = userName
                                                )
                                            }
                                        }
                                    )
                                }

                                IncidentRepository.ACTIONS_PENDING -> {
                                    IncidentSectionHeading(
                                        title = "Close incident",
                                        subtitle = "Confirm that all required " +
                                                "actions have been completed."
                                    )

                                    IncidentTextField(
                                        value = closingNote,
                                        onValueChange = {
                                            closingNote = it
                                            message = null
                                        },
                                        label = "Closing note",
                                        enabled = !isSaving,
                                        minLines = 3
                                    )

                                    LifecycleButton(
                                        text = "Close Incident",
                                        isSaving = isSaving,
                                        enabled = closingNote.isNotBlank() &&
                                                closingNote.length <= 5000,
                                        onClick = {
                                            showCloseConfirmation = true
                                        }
                                    )
                                }

                                IncidentRepository.CLOSED -> {
                                    Row(
                                        horizontalArrangement =
                                            Arrangement.spacedBy(12.dp),
                                        verticalAlignment =
                                            Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.CheckCircle,
                                            contentDescription = null,
                                            tint = incidentSuccess
                                        )

                                        IncidentSectionHeading(
                                            title = "Incident closed",
                                            subtitle = "All lifecycle stages " +
                                                    "have been completed."
                                        )
                                    }
                                }

                                else -> {
                                    Text(
                                        text = "This incident has an unrecognised " +
                                                "workflow status. Refresh or " +
                                                "contact your administrator.",
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }

                    HorizontalDivider()

                    IncidentSectionHeading(
                        title = "Timeline",
                        subtitle = "${events.size} recorded " +
                                "event${if (events.size == 1) "" else "s"}"
                    )

                    if (events.isEmpty()) {
                        OutlinedCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text(
                                text = "No lifecycle events are available.",
                                style = MaterialTheme.typography.bodyMedium,
                                color =
                                    MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    } else {
                        events.forEachIndexed { index, event ->
                            IncidentTimelineItem(
                                event = event,
                                isLast = index == events.lastIndex
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun IncidentPanel(
    content: @Composable ColumnScope.() -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.elevatedCardElevation(
            defaultElevation = 1.dp
        )
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            content = content
        )
    }
}

@Composable
private fun IncidentLifecycleCard(
    status: String
) {
    val stageIndex = incidentLifecycle.indexOf(status)
    val knownStatus = stageIndex >= 0

    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = IncidentRepository.label(status).ifBlank {
                    "Status unavailable"
                },
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = if (knownStatus) {
                    "Stage ${stageIndex + 1} of ${incidentLifecycle.size}"
                } else {
                    "Stage unavailable"
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            LinearProgressIndicator(
                progress = {
                    if (knownStatus) {
                        (stageIndex + 1) / incidentLifecycle.size.toFloat()
                    } else {
                        0f
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp),
                color = detailStatusColor(status)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                incidentLifecycle.forEachIndexed { index, lifecycleStatus ->
                    Text(
                        text = if (
                            lifecycleStatus ==
                            IncidentRepository.ACTIONS_PENDING
                        ) {
                            "Actions"
                        } else {
                            IncidentRepository.label(lifecycleStatus)
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = if (knownStatus && index <= stageIndex) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.outline
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun IncidentInformationCard(
    incident: Incident
) {
    IncidentPanel {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Text(
                text = incident.title.ifBlank {
                    "Untitled incident"
                },
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )

            Surface(
                color = incidentSeverityColor(incident.severity),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = incident.severity.ifBlank {
                        "Not provided"
                    },
                    color = if (
                        incident.severity.uppercase() == "MODERATE"
                    ) {
                        Color(0xFF3E3200)
                    } else {
                        Color.White
                    },
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(
                        horizontal = 9.dp,
                        vertical = 5.dp
                    )
                )
            }
        }

        HorizontalDivider()

        IncidentDetailRow(
            label = "Type",
            value = incident.type.ifBlank { "Uncategorised" }
        )

        IncidentDetailRow(
            label = "Location",
            value = incident.location.ifBlank { "Not provided" }
        )

        IncidentDetailRow(
            label = "Injured person",
            value = incident.injuredPerson.ifBlank { "None recorded" }
        )

        IncidentDetailRow(
            label = "Witnesses",
            value = incident.witnesses.ifBlank { "None recorded" }
        )

        IncidentDetailRow(
            label = "Reported by",
            value = incident.reporterName.ifBlank { "Unknown" }
        )

        IncidentDetailRow(
            label = "Occurred",
            value = detailDate(incident.occurredAt)
        )

        IncidentDetailRow(
            label = "Reported",
            value = detailDate(incident.createdAt)
        )

        HorizontalDivider()

        Text(
            text = "Description",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Text(
            text = incident.description.ifBlank {
                "No description provided."
            },
            style = MaterialTheme.typography.bodyLarge
        )

        if (incident.investigatorName.isNotBlank()) {
            HorizontalDivider()

            IncidentDetailRow(
                label = "Investigator",
                value = incident.investigatorName
            )
        }

        if (incident.rootCause.isNotBlank()) {
            IncidentDetailRow(
                label = "Root cause",
                value = incident.rootCause
            )
        }

        if (incident.findings.isNotBlank()) {
            IncidentDetailRow(
                label = "Findings",
                value = incident.findings
            )
        }

        if (incident.actionsRequired.isNotBlank()) {
            IncidentDetailRow(
                label = "Actions required",
                value = incident.actionsRequired
            )
        }

        if (incident.closingNote.isNotBlank()) {
            HorizontalDivider()

            IncidentDetailRow(
                label = "Closing note",
                value = incident.closingNote
            )
        }

        incident.closedAt?.let {
            IncidentDetailRow(
                label = "Closed",
                value = detailDate(it)
            )
        }
    }
}

@Composable
private fun IncidentTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    enabled: Boolean,
    minLines: Int
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = {
            Text(label)
        },
        supportingText = {
            Text("${value.length}/5000")
        },
        isError = value.length > 5000,
        enabled = enabled,
        minLines = minLines,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun LifecycleButton(
    text: String,
    isSaving: Boolean,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled && !isSaving,
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp),
        shape = RoundedCornerShape(14.dp)
    ) {
        if (isSaving) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                strokeWidth = 2.dp,
                color = MaterialTheme.colorScheme.onPrimary
            )

            Text(
                text = "Saving…",
                modifier = Modifier.padding(start = 8.dp)
            )
        } else {
            Text(text)
        }
    }
}

@Composable
private fun IncidentTimelineItem(
    event: IncidentEvent,
    isLast: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                modifier = Modifier.size(14.dp),
                shape = RoundedCornerShape(50),
                color = detailStatusColor(event.toStatus)
            ) {}

            if (!isLast) {
                Surface(
                    modifier = Modifier
                        .width(2.dp)
                        .height(72.dp),
                    color = MaterialTheme.colorScheme.outlineVariant
                ) {}
            }
        }

        ElevatedCard(
            modifier = Modifier
                .weight(1f)
                .padding(bottom = 10.dp),
            shape = RoundedCornerShape(14.dp),
            elevation = CardDefaults.elevatedCardElevation(
                defaultElevation = 1.dp
            )
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = IncidentRepository.label(event.toStatus),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = detailStatusColor(event.toStatus)
                )

                Text(
                    text = event.note,
                    style = MaterialTheme.typography.bodyMedium
                )

                Text(
                    text = "${detailDate(event.at)} · ${
                        event.byName.ifBlank { "Unknown" }
                    }",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun IncidentDetailRow(
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(0.38f)
        )

        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(0.62f)
        )
    }
}

@Composable
private fun IncidentSectionHeading(
    title: String,
    subtitle: String
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun IncidentResultMessage(
    message: String,
    isError: Boolean,
    onDismiss: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = if (isError) {
            MaterialTheme.colorScheme.errorContainer
        } else {
            incidentSuccess.copy(alpha = 0.12f)
        },
        contentColor = if (isError) {
            MaterialTheme.colorScheme.onErrorContainer
        } else {
            incidentSuccess
        }
    ) {
        Row(
            modifier = Modifier.padding(
                start = 14.dp,
                top = 8.dp,
                end = 6.dp,
                bottom = 8.dp
            ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f)
            )

            TextButton(onClick = onDismiss) {
                Text("Dismiss")
            }
        }
    }
}

private fun detailDate(
    timestamp: Long
): String {
    if (timestamp <= 0L) {
        return "Date unavailable"
    }

    return SimpleDateFormat(
        "dd MMM yyyy, HH:mm",
        Locale.getDefault()
    ).apply {
        timeZone = TimeZone.getTimeZone("Africa/Johannesburg")
    }.format(Date(timestamp))
}