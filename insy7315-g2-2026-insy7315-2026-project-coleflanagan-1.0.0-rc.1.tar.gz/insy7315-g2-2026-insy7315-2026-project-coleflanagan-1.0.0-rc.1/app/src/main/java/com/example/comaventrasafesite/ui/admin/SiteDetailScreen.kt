package com.example.comaventrasafesite.ui.admin

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.AppUser
import com.example.comaventrasafesite.model.Project
import com.example.comaventrasafesite.model.Role
import com.example.comaventrasafesite.model.Site
import com.example.comaventrasafesite.model.SiteAssignment
import com.example.comaventrasafesite.repository.AdminDirectoryRepository
import com.example.comaventrasafesite.repository.ProjectRepository
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SiteDetailScreen(
    siteId: String,
    onBack: () -> Unit
) {
    val repository = remember { ProjectRepository() }
    val directory = remember { AdminDirectoryRepository() }
    val loader = rememberScreenLoader()
    val actions = remember(siteId) { ProjectActionState() }
    val scope = rememberCoroutineScope()

    var site by remember(siteId) { mutableStateOf<Site?>(null) }
    var projects by remember(siteId) {
        mutableStateOf<List<Project>>(emptyList())
    }
    var assignments by remember(siteId) {
        mutableStateOf<List<SiteAssignment>>(emptyList())
    }
    var users by remember(siteId) {
        mutableStateOf<List<AppUser>>(emptyList())
    }
    var refreshKey by remember { mutableIntStateOf(0) }

    var showProjectPicker by remember { mutableStateOf(false) }
    var showPersonPicker by remember { mutableStateOf(false) }
    var personSearch by rememberSaveable(siteId) { mutableStateOf("") }

    var projectToLink by remember { mutableStateOf<Project?>(null) }
    var personToAssign by remember { mutableStateOf<AppUser?>(null) }
    var assignmentToEnd by remember { mutableStateOf<SiteAssignment?>(null) }
    var confirmStatus by remember { mutableStateOf(false) }

    BackHandler(enabled = actions.busy) {}

    suspend fun reload() {
        loader.run {
            val loadedSite = repository.getSite(siteId)

            if (loadedSite == null) {
                site = null
                projects = emptyList()
                assignments = emptyList()
                users = emptyList()
            } else {
                val loadedProjects = repository.getProjects()
                val loadedAssignments = repository.getAssignments(siteId)
                val loadedUsers = directory.getUsers()

                site = loadedSite
                projects = loadedProjects
                assignments = loadedAssignments
                users = loadedUsers
            }
        }
    }

    LaunchedEffect(siteId, refreshKey) { reload() }

    fun personName(id: String): String {
        val user = users.firstOrNull { it.id == id }

        return user?.fullName?.takeIf { it.isNotBlank() }
            ?: user?.email?.takeIf { it.isNotBlank() }
            ?: id
    }

    val openAssignments = assignments.filter { it.endDate.isBlank() }
    val pastAssignments = assignments.filter { it.endDate.isNotBlank() }
        .sortedByDescending { it.endDate }

    val currentProject = projects.firstOrNull { it.id == site?.projectId }

    val canAssign = site?.status == "active" &&
            (
                    site?.projectId.isNullOrBlank() ||
                            currentProject?.status == "active"
                    )

    if (showProjectPicker) {
        AlertDialog(
            onDismissRequest = { showProjectPicker = false },
            title = { Text("Choose an active project") },
            text = {
                val available = projects.filter {
                    it.status == "active" && it.id != site?.projectId
                }

                LazyColumn(
                    modifier = Modifier.heightIn(max = 360.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (available.isEmpty()) {
                        item { Text("No other active projects are available.") }
                    }

                    items(available, key = { it.id }) { project ->
                        TextButton(
                            onClick = {
                                showProjectPicker = false
                                projectToLink = project
                            }
                        ) {
                            Text(project.name.ifBlank { project.id })
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showProjectPicker = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showPersonPicker) {
        val available = users.filter { user ->
            user.status == "active" &&
                    Role.values().any { it.name == user.role } &&
                    openAssignments.none { it.workerId == user.id } &&
                    (
                            personSearch.isBlank() ||
                                    user.fullName.contains(personSearch, true) ||
                                    user.email.contains(personSearch, true)
                            )
        }

        AlertDialog(
            onDismissRequest = { showPersonPicker = false },
            title = { Text("Assign a person") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = personSearch,
                        onValueChange = { personSearch = it },
                        label = { Text("Search name or email") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    LazyColumn(
                        modifier = Modifier.heightIn(max = 300.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (available.isEmpty()) {
                            item {
                                Text("No available people match this search.")
                            }
                        }

                        items(available, key = { it.id }) { user ->
                            TextButton(
                                onClick = {
                                    showPersonPicker = false
                                    personToAssign = user
                                }
                            ) {
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    Text(
                                        user.fullName.ifBlank { user.email },
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        roleLabel(user.role),
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showPersonPicker = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    projectToLink?.let { project ->
        ProjectFormDialog(
            title = "Move this site?",
            busy = actions.busy,
            error = null,
            onDismiss = { projectToLink = null },
            saveLabel = "Move site",
            onSave = {
                projectToLink = null
                scope.launch {
                    actions.run(
                        successMessage = "Site moved to ${project.name}.",
                        reload = { reload() },
                        action = {
                            repository.linkSiteToProject(siteId, project.id)
                        }
                    )
                }
            }
        ) {
            Text(
                "Link this site to ${project.name}? Its assignment history will remain attached to the site."
            )
        }
    }

    personToAssign?.let { user ->
        ProjectFormDialog(
            title = "Confirm assignment",
            busy = actions.busy,
            error = null,
            onDismiss = { personToAssign = null },
            saveLabel = "Assign",
            onSave = {
                personToAssign = null
                scope.launch {
                    actions.run(
                        successMessage = "Person assigned to this site.",
                        reload = { reload() },
                        action = {
                            repository.assignWorker(siteId, user.id)
                        }
                    )
                }
            }
        ) {
            Text("Assign ${personName(user.id)} to this site?")
            Text(roleLabel(user.role))
        }
    }

    assignmentToEnd?.let { assignment ->
        ProjectFormDialog(
            title = "End assignment?",
            busy = actions.busy,
            error = null,
            onDismiss = { assignmentToEnd = null },
            saveLabel = "End assignment",
            onSave = {
                assignmentToEnd = null
                scope.launch {
                    actions.run(
                        successMessage = "Assignment ended.",
                        reload = { reload() },
                        action = {
                            repository.endAssignment(assignment.id)
                        }
                    )
                }
            }
        ) {
            Text(
                "${personName(assignment.workerId)} will no longer be assigned to this site. The assignment will remain in its history."
            )
        }
    }

    if (confirmStatus) {
        val nextStatus = if (site?.status == "active") "inactive" else "active"

        ProjectFormDialog(
            title = if (nextStatus == "active") {
                "Activate site?"
            } else {
                "Deactivate site?"
            },
            busy = actions.busy,
            error = null,
            onDismiss = { confirmStatus = false },
            saveLabel = "Confirm",
            onSave = {
                confirmStatus = false
                scope.launch {
                    actions.run(
                        successMessage =
                            "Site status changed to ${ProjectRepository.label(nextStatus)}.",
                        reload = { reload() },
                        action = {
                            repository.setSiteStatus(siteId, nextStatus)
                        }
                    )
                }
            }
        ) {
            Text(
                if (nextStatus == "active") {
                    "The linked project must be active. Existing assignment history will be retained."
                } else {
                    "New assignments will be blocked and this site will no longer be treated as an active work site. Existing history will be retained."
                }
            )
        }
    }

    Scaffold(
        containerColor = Color(0xFFF7F8F6),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Site details", fontWeight = FontWeight.Bold)
                        Text(
                            when {
                                loader.isLoading -> "Loading site…"
                                loader.errorMessage != null -> "Site unavailable"
                                else -> site?.name.orEmpty()
                            },
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        enabled = !actions.busy,
                        onClick = onBack
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        enabled = !loader.isLoading && !actions.busy,
                        onClick = { refreshKey++ }
                    ) {
                        Icon(
                            Icons.Default.Refresh,
                            contentDescription = "Refresh site"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF496F42),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            when {
                loader.isLoading -> ProjectWaiting()

                loader.errorMessage != null -> ScreenLoadError(
                    message = loader.errorMessage.orEmpty(),
                    onRetry = { refreshKey++ },
                    modifier = Modifier.fillMaxSize()
                )

                site == null -> {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            "Site not found",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text("This site no longer exists.")
                        Button(onClick = onBack) { Text("Go back") }
                    }
                }

                else -> {
                    val current = site ?: return@Scaffold

                    LazyColumn(
                        contentPadding = PaddingValues(20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item { ProjectMessage(actions) }

                        if (actions.busy) {
                            item {
                                LinearProgressIndicator(
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }

                        item {
                            ProjectPanel(current.name.ifBlank { "Unnamed site" }) {
                                Text(current.address.ifBlank { "No address recorded" })
                                StatusBadge(current.status)
                                HorizontalDivider()
                                Text(
                                    "Project: ${
                                        currentProject?.name
                                            ?: if (current.projectId.isBlank()) {
                                                "Not linked"
                                            } else {
                                                "Linked project missing"
                                            }
                                    }"
                                )
                                Text(
                                    "Site reference: ${current.id}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }

                        item {
                            ProjectPanel("Site management") {
                                OutlinedButton(
                                    enabled = !actions.busy,
                                    onClick = { showProjectPicker = true },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Change project")
                                }

                                OutlinedButton(
                                    enabled = !actions.busy,
                                    onClick = { confirmStatus = true },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        if (current.status == "active") {
                                            "Deactivate site"
                                        } else {
                                            "Activate site"
                                        }
                                    )
                                }
                            }
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    "Assigned people (${openAssignments.size})",
                                    modifier = Modifier.weight(1f),
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )

                                TextButton(
                                    enabled = canAssign && !actions.busy,
                                    onClick = {
                                        personSearch = ""
                                        showPersonPicker = true
                                    }
                                ) {
                                    Text("Assign")
                                }
                            }

                            if (!canAssign) {
                                Text(
                                    "The site and any linked project must be active before assigning people.",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }

                        if (openAssignments.isEmpty()) {
                            item {
                                ProjectPanel("Nobody assigned yet") {
                                    Text(
                                        "Use Assign above when the site is available."
                                    )
                                }
                            }
                        }

                        items(
                            openAssignments.sortedBy {
                                personName(it.workerId).lowercase()
                            },
                            key = { "open-${it.id}" }
                        ) { assignment ->
                            val user = users.firstOrNull {
                                it.id == assignment.workerId
                            }
                            val scheduled =
                                assignment.startDate > ProjectRepository.today()

                            ProjectPanel(personName(assignment.workerId)) {
                                Text(
                                    user?.role?.let(::roleLabel)
                                        ?: "Account unavailable"
                                )
                                Text(
                                    if (scheduled) {
                                        "Scheduled from ${assignment.startDate}"
                                    } else {
                                        "Assigned since ${
                                            assignment.startDate.ifBlank {
                                                "date unavailable"
                                            }
                                        }"
                                    },
                                    style = MaterialTheme.typography.bodySmall
                                )

                                if (user != null && user.status != "active") {
                                    Text(
                                        "This account is not active.",
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }

                                TextButton(
                                    enabled = !actions.busy,
                                    onClick = { assignmentToEnd = assignment }
                                ) {
                                    Text(
                                        "End assignment",
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }

                        if (pastAssignments.isNotEmpty()) {
                            item {
                                Text(
                                    "Assignment history",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            items(
                                pastAssignments,
                                key = { "past-${it.id}" }
                            ) { assignment ->
                                ProjectPanel(personName(assignment.workerId)) {
                                    Text(
                                        "${assignment.startDate.ifBlank { "Unknown start" }} to ${assignment.endDate}"
                                    )
                                    Text(
                                        "Ended assignment",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}