package com.example.comaventrasafesite.ui.hazard

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.Hazard
import com.example.comaventrasafesite.repository.HazardRepository
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

private val hazardCategories = listOf(
    "Working at height",
    "Electrical",
    "Machinery",
    "Excavation",
    "Housekeeping",
    "Fire",
    "Other"
)

private val hazardSeverities = listOf(
    "LOW",
    "MEDIUM",
    "HIGH",
    "CRITICAL"
)

private fun severityLabelColor(
    severity: String
): Color = when (severity) {
    "MEDIUM" -> Color(0xFF3E3200)
    else -> Color.White
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportHazardScreen(
    siteId: String,
    onBack: () -> Unit,
    onSubmitted: () -> Unit
) {
    val repository = remember { HazardRepository() }
    val scope = rememberCoroutineScope()

    val currentUser = remember {
        FirebaseAuth.getInstance().currentUser
    }

    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var severity by remember { mutableStateOf("") }
    var isSaving by remember { mutableStateOf(false) }
    var errorMessage by remember {
        mutableStateOf<String?>(null)
    }

    fun submitHazard() {
        errorMessage = when {
            siteId.isBlank() ->
                "No assigned site was found."

            title.isBlank() ->
                "Enter a short title for the hazard."

            description.isBlank() ->
                "Describe what you observed."

            location.isBlank() ->
                "Enter where the hazard was found."

            category !in hazardCategories ->
                "Choose a hazard category."

            severity !in hazardSeverities ->
                "Choose the hazard severity."

            else ->
                null
        }

        if (errorMessage != null) {
            return
        }

        isSaving = true

        scope.launch {
            val hazard = Hazard(
                siteId = siteId,
                title = title.trim(),
                description = description.trim(),
                category = category,
                severity = severity,
                location = location.trim(),
                reportedBy = currentUser?.uid.orEmpty(),
                reporterName = currentUser?.email ?: "Unknown"
            )

            repository.reportHazard(hazard)
                .onSuccess {
                    isSaving = false
                    onSubmitted()
                }
                .onFailure { error ->
                    isSaving = false
                    errorMessage = error.message
                        ?: "The hazard could not be saved."
                }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Report Hazard",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        enabled = !isSaving
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(
                    start = 20.dp,
                    top = 8.dp,
                    end = 20.dp,
                    bottom = 28.dp
                ),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            if (isSaving) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth()
                )
            }

            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surface
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(12.dp)
                        )
                    }

                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "Report it early",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "Provide enough detail for the safety team to locate and assess the risk.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 3.dp)
                        )
                    }
                }
            }

            FormSectionTitle(
                title = "Hazard details",
                subtitle = "Describe what was found on site."
            )

            OutlinedTextField(
                value = title,
                onValueChange = {
                    title = it
                    errorMessage = null
                },
                label = {
                    Text("Hazard title")
                },
                placeholder = {
                    Text("Enter a short title")
                },
                supportingText = {
                    Text("${title.length}/80 characters")
                },
                singleLine = true,
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = description,
                onValueChange = {
                    description = it
                    errorMessage = null
                },
                label = {
                    Text("Description")
                },
                placeholder = {
                    Text("Explain what you observed and why it may be unsafe.")
                },
                minLines = 4,
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = location,
                onValueChange = {
                    location = it
                    errorMessage = null
                },
                label = {
                    Text("Location on site")
                },
                placeholder = {
                    Text("Describe the exact location")
                },
                singleLine = true,
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth()
            )

            FormSectionTitle(
                title = "Category",
                subtitle = "Select the closest hazard type."
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                hazardCategories.forEach { option ->
                    FilterChip(
                        selected = category == option,
                        onClick = {
                            category = option
                            errorMessage = null
                        },
                        enabled = !isSaving,
                        label = {
                            Text(option)
                        }
                    )
                }
            }

            FormSectionTitle(
                title = "Severity",
                subtitle = "Select the potential level of harm."
            )

            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                hazardSeverities.chunked(2).forEach { rowOptions ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        rowOptions.forEach { option ->
                            FilterChip(
                                selected = severity == option,
                                onClick = {
                                    severity = option
                                    errorMessage = null
                                },
                                enabled = !isSaving,
                                label = {
                                    Text(
                                        text = option,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                },
                                modifier = Modifier.weight(1f),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = severityColor(option),
                                    selectedLabelColor = severityLabelColor(option),
                                    selectedLeadingIconColor = severityLabelColor(option)
                                )
                            )
                        }

                        if (rowOptions.size == 1) {
                            Spacer(
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            SeverityExplanation(
                severity = severity
            )

            errorMessage?.let { message ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    contentColor = MaterialTheme.colorScheme.onErrorContainer
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Warning,
                            contentDescription = null
                        )

                        Text(
                            text = message,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Button(
                onClick = ::submitHazard,
                enabled = !isSaving,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                if (isSaving) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )

                    Text(
                        text = "Submitting…",
                        modifier = Modifier.padding(start = 10.dp)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null
                    )

                    Text(
                        text = "Submit Hazard",
                        modifier = Modifier.padding(start = 10.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun FormSectionTitle(
    title: String,
    subtitle: String
) {
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

@Composable
private fun SeverityExplanation(
    severity: String
) {
    val description = when (severity) {
        "CRITICAL" ->
            "Immediate danger with the potential for severe injury or loss of life."

        "HIGH" ->
            "Serious risk that requires urgent corrective action."

        "MEDIUM" ->
            "Moderate risk that should be corrected soon."

        "LOW" ->
            "Limited immediate danger, but the condition should still be addressed."

        else ->
            "Select a severity to see its explanation."
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = if (severity.isBlank()) {
            MaterialTheme.colorScheme.surfaceVariant
        } else {
            severityColor(severity).copy(alpha = 0.12f)
        }
    ) {
        Text(
            text = description,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(14.dp)
        )
    }
}