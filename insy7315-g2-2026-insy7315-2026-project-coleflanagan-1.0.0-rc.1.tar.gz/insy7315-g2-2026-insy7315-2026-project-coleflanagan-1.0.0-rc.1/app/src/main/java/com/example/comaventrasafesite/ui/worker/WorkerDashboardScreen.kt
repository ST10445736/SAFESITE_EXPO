package com.example.comaventrasafesite.ui.worker

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.repository.WorkerSessionRepository
import com.example.comaventrasafesite.repository.WorkerSiteContext
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

@Composable
fun WorkerDashboardScreen(
    onNavigate: (WorkerDestination) -> Unit,
    onOpenCheckIn: (String) -> Unit,
    onOpenTasks: () -> Unit,
    onOpenSafety: () -> Unit,
    onOpenPpe: (String) -> Unit,
    onOpenAlerts: () -> Unit,
    onOpenProfile: () -> Unit,
    onReportHazard: (String) -> Unit,
    onReportIncident: (String) -> Unit
) {
    val repository = remember {
        WorkerSessionRepository()
    }

    val loader = rememberScreenLoader()
    val scope = rememberCoroutineScope()

    val currentUser = FirebaseAuth.getInstance().currentUser

    var siteContext by remember(currentUser?.uid) {
        mutableStateOf<WorkerSiteContext?>(null)
    }

    fun refresh() {
        scope.launch {
            loader.run {
                siteContext = repository.getActiveSite(
                    currentUser?.uid.orEmpty()
                )
            }
        }
    }

    LaunchedEffect(currentUser?.uid) {
        refresh()
    }

    val firstName = currentUser?.email.orEmpty()
        .substringBefore("@")
        .substringBefore(".")
        .replaceFirstChar {
            it.uppercase()
        }
        .ifBlank {
            "Worker"
        }

    val hasActiveSite = siteContext != null
    val loadError = loader.errorMessage

    Scaffold(
        bottomBar = {
            WorkerBottomBar(
                selectedDestination = WorkerDestination.HOME,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            WorkerSiteHeader(
                title = firstName,
                eyebrow = "Welcome back",
                refreshEnabled = !loader.isLoading,
                onRefresh = {
                    refresh()
                }
            )

            when {
                loader.isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }

                loadError != null -> {
                    ScreenLoadError(
                        message = loadError,
                        onRetry = {
                            refresh()
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                else -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            WorkerActiveSiteCard(
                                siteContext = siteContext
                            )
                        }

                        item {
                            WorkerSectionLabel("Today")
                        }

                        item {
                            WorkerActionCard(
                                title = "Site attendance",
                                description = if (hasActiveSite) {
                                    "Check in or review your attendance status"
                                } else {
                                    "An active site assignment is required"
                                },
                                icon = Icons.Filled.Place,
                                enabled = hasActiveSite,
                                onClick = {
                                    siteContext?.siteId?.let {
                                        onOpenCheckIn(it)
                                    }
                                }
                            )
                        }

                        item {
                            WorkerActionCard(
                                title = "Daily safety",
                                description =
                                    "Complete today's site safety requirements",
                                icon = Icons.Filled.CheckCircle,
                                enabled = hasActiveSite,
                                onClick = onOpenSafety
                            )
                        }

                        item {
                            WorkerActionCard(
                                title = "PPE verification",
                                description = "Upload your PPE verification photo",
                                icon = Icons.Filled.Person,
                                enabled = hasActiveSite,
                                onClick = {
                                    siteContext?.siteId?.let {
                                        onOpenPpe(it)
                                    }
                                }
                            )
                        }

                        item {
                            WorkerActionCard(
                                title = "My tasks",
                                description = "Review and update assigned work",
                                icon = Icons.Filled.List,
                                enabled = true,
                                onClick = onOpenTasks
                            )
                        }

                        item {
                            WorkerSectionLabel(
                                text = "Quick actions",
                                modifier = Modifier.padding(top = 12.dp)
                            )
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement =
                                    Arrangement.spacedBy(12.dp)
                            ) {
                                QuickActionButton(
                                    text = "Hazard",
                                    enabled = hasActiveSite,
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        siteContext?.siteId?.let {
                                            onReportHazard(it)
                                        }
                                    }
                                )

                                QuickActionButton(
                                    text = "Incident",
                                    enabled = hasActiveSite,
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        siteContext?.siteId?.let {
                                            onReportIncident(it)
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickActionButton(
    text: String,
    enabled: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(52.dp),
        shape = RoundedCornerShape(14.dp)
    ) {
        Icon(
            imageVector = Icons.Filled.Warning,
            contentDescription = null
        )

        Spacer(
            modifier = Modifier.width(8.dp)
        )

        Text(text)
    }
}