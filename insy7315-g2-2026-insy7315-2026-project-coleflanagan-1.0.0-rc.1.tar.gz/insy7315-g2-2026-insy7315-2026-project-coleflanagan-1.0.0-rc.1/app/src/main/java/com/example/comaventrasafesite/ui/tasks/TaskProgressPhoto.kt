package com.example.comaventrasafesite.ui.tasks

import android.util.Base64
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

@Composable
fun TaskProgressPhoto(
    photoUrl: String,
    modifier: Modifier = Modifier
) {
    if (photoUrl.isBlank()) return

    val imageModel: Any? = remember(photoUrl) {
        if (photoUrl.startsWith("data:image/")) {
            runCatching {
                val separator = photoUrl.indexOf(',')
                require(separator >= 0)

                Base64.decode(
                    photoUrl.substring(separator + 1),
                    Base64.DEFAULT
                )
            }.getOrNull()
        } else {
            photoUrl
        }
    }

    var loading by remember(photoUrl) {
        mutableStateOf(imageModel != null)
    }
    var failed by remember(photoUrl) {
        mutableStateOf(imageModel == null)
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 10.dp)
            .height(220.dp)
            .clip(RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (imageModel != null && !failed) {
            AsyncImage(
                model = imageModel,
                contentDescription = "Task progress photo",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp),
                onSuccess = {
                    loading = false
                    failed = false
                },
                onError = {
                    loading = false
                    failed = true
                }
            )
        }

        if (loading) {
            CircularProgressIndicator()
        }

        if (failed) {
            Text(
                text = "The task photo could not be loaded.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(12.dp)
            )
        }
    }
}