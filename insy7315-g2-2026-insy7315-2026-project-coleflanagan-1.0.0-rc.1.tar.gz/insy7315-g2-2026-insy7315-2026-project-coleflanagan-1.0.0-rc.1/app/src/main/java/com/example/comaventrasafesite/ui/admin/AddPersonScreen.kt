package com.example.comaventrasafesite.ui.admin

import android.util.Patterns
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.Role
import com.example.comaventrasafesite.repository.AdminRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

private fun adminRoleDescription(role: String): String = when (role) {
    Role.WORKER.name ->
        "Can check in, complete assigned tasks and submit safety information."

    Role.SUPERVISOR.name ->
        "Can monitor workers, assign tasks and review site submissions."

    Role.SAFETY_OFFICER.name ->
        "Can manage hazards, incidents, training records and safety reports."

    Role.ADMIN.name ->
        "Can manage users, roles, projects, sites and system records."

    else ->
        "Select a role to see the account's access level."
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPersonScreen(
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val repository = remember { AdminRepository() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current.applicationContext

    var fullName by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var role by rememberSaveable { mutableStateOf("") }

    // Passwords are deliberately excluded from saved instance state.
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    var isSaving by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    BackHandler(enabled = isSaving) {}

    fun createAccount() {
        if (isSaving) return

        val enteredName = fullName.trim()
        val enteredEmail = email.trim()
        val enteredPassword = password
        val enteredRole = role

        errorMessage = when {
            enteredName.isBlank() ->
                "Enter the person's full name."

            enteredName.length > 200 ->
                "The full name must contain no more than 200 characters."

            enteredEmail.length > 254 ||
                    !Patterns.EMAIL_ADDRESS.matcher(enteredEmail).matches() ->
                "Enter a valid email address."

            enteredPassword.length < 8 ->
                "The initial password must contain at least eight characters."

            Role.values().none { it.name == enteredRole } ->
                "Choose an account role."

            else -> null
        }

        if (errorMessage != null) return

        isSaving = true

        scope.launch {
            try {
                val result = repository.createUser(
                    context = context,
                    fullName = enteredName,
                    email = enteredEmail,
                    password = enteredPassword,
                    role = enteredRole
                )

                result.fold(
                    onSuccess = {
                        password = ""
                        passwordVisible = false
                        onSaved()
                    },
                    onFailure = { error ->
                        if (error is CancellationException) throw error

                        errorMessage = error.message
                            ?: "The account could not be created."
                    }
                )
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                errorMessage =
                    "Account creation could not be confirmed. Check the user list before trying again."
            } finally {
                isSaving = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("Add person", fontWeight = FontWeight.Bold)
                },
                navigationIcon = {
                    IconButton(
                        enabled = !isSaving,
                        onClick = onBack
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(
                    start = 20.dp,
                    top = 8.dp,
                    end = 20.dp,
                    bottom = 28.dp
                ),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            if (isSaving) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth()
                )
            }

            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor =
                        MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Filled.Person,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )

                    Text(
                        "Create a SafeSite account",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        "The user can sign in once their account and profile have been created successfully.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            AdminFormHeading(
                title = "Personal details",
                subtitle = "Enter the person's name and work email address."
            )

            OutlinedTextField(
                value = fullName,
                onValueChange = {
                    fullName = it
                    errorMessage = null
                },
                label = { Text("Full name") },
                singleLine = true,
                enabled = !isSaving,
                supportingText = {
                    Text("${fullName.trim().length}/200 characters")
                },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = email,
                onValueChange = {
                    email = it
                    errorMessage = null
                },
                label = { Text("Email address") },
                singleLine = true,
                enabled = !isSaving,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email
                ),
                modifier = Modifier.fillMaxWidth()
            )

            HorizontalDivider()

            AdminFormHeading(
                title = "Initial password",
                subtitle =
                    "Use a unique password and share it with the intended user securely."
            )

            OutlinedTextField(
                value = password,
                onValueChange = {
                    password = it
                    errorMessage = null
                },
                label = { Text("Initial password") },
                supportingText = {
                    Text("At least eight characters")
                },
                singleLine = true,
                enabled = !isSaving,
                visualTransformation = if (passwordVisible) {
                    VisualTransformation.None
                } else {
                    PasswordVisualTransformation()
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password
                ),
                trailingIcon = {
                    TextButton(
                        enabled = !isSaving,
                        onClick = { passwordVisible = !passwordVisible }
                    ) {
                        Text(if (passwordVisible) "Hide" else "Show")
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            HorizontalDivider()

            AdminFormHeading(
                title = "Role and permissions",
                subtitle = "Choose the access level required for this person."
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Role.values().forEach { option ->
                    FilterChip(
                        selected = role == option.name,
                        enabled = !isSaving,
                        onClick = {
                            role = option.name
                            errorMessage = null
                        },
                        label = { Text(option.label) }
                    )
                }
            }

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.secondaryContainer
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        if (role.isBlank()) "Select a role" else roleLabel(role),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )

                    Text(
                        adminRoleDescription(role),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Text(
                    "Creating this account keeps you signed in as the Administrator.",
                    modifier = Modifier.padding(14.dp),
                    style = MaterialTheme.typography.bodySmall
                )
            }

            errorMessage?.let { message ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    contentColor =
                        MaterialTheme.colorScheme.onErrorContainer
                ) {
                    Text(
                        message,
                        modifier = Modifier.padding(14.dp),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            Button(
                enabled = !isSaving,
                onClick = ::createAccount,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                if (isSaving) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp
                    )
                    Spacer(Modifier.width(10.dp))
                    Text("Creating account…")
                } else {
                    Text("Create account")
                }
            }
        }
    }
}

@Composable
private fun AdminFormHeading(
    title: String,
    subtitle: String
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Text(
            subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}