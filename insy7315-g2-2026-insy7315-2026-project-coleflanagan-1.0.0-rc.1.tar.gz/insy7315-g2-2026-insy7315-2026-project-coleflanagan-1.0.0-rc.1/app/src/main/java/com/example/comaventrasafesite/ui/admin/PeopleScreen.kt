package com.example.comaventrasafesite.ui.admin

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.AppUser
import com.example.comaventrasafesite.model.Role
import com.example.comaventrasafesite.repository.AdminDirectoryRepository
import com.example.comaventrasafesite.repository.AdminRepository
import com.example.comaventrasafesite.ui.shared.SafeSiteEmptyState
import com.example.comaventrasafesite.ui.shared.SafeSiteListTopBar
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

private val AdminSuccess = Color(0xFF388E3C)

fun roleLabel(role: String): String =
    Role.values().firstOrNull { it.name == role }?.label
        ?: role.ifBlank { "No role" }

private data class AccountChange(
    val user: AppUser,
    val newRole: String? = null,
    val newStatus: String? = null
)

@Composable
fun PeopleScreen(
    onBack: () -> Unit,
    onAddPerson: () -> Unit
) {
    val directory = remember { AdminDirectoryRepository() }
    val repository = remember { AdminRepository() }
    val loader = rememberScreenLoader()
    val scope = rememberCoroutineScope()

    var users by remember { mutableStateOf<List<AppUser>>(emptyList()) }
    var refreshKey by remember { mutableIntStateOf(0) }
    var search by rememberSaveable { mutableStateOf("") }
    var roleFilter by rememberSaveable { mutableStateOf<String?>(null) }

    var message by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }
    var busyUserId by remember { mutableStateOf<String?>(null) }
    var pendingChange by remember { mutableStateOf<AccountChange?>(null) }

    val busy = busyUserId != null
    val myUid = FirebaseAuth.getInstance().currentUser?.uid
    val dataReady = !loader.isLoading && loader.errorMessage == null

    BackHandler(enabled = busy) {}

    suspend fun reload() {
        loader.run {
            users = directory.getUsers()
        }
    }

    LaunchedEffect(refreshKey) {
        reload()
    }

    fun applyChange(change: AccountChange) {
        if (busy || !dataReady || change.user.id == myUid) return

        busyUserId = change.user.id
        pendingChange = null
        message = null

        scope.launch {
            try {
                val result = when {
                    change.newRole != null -> repository.updateRole(
                        change.user.id,
                        change.newRole
                    )

                    change.newStatus != null -> repository.setStatus(
                        change.user.id,
                        change.newStatus
                    )

                    else -> error("No account change was selected.")
                }

                result.fold(
                    onSuccess = {
                        message = when {
                            change.newRole != null ->
                                "Role updated to ${roleLabel(change.newRole)}."

                            change.newStatus == "active" ->
                                "Account activated."

                            else ->
                                "Account deactivated."
                        }
                        isError = false
                    },
                    onFailure = { error ->
                        if (error is CancellationException) throw error

                        message = error.message
                            ?: "The account update could not be confirmed. Refresh before trying again."
                        isError = true
                    }
                )

                reload()
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                message =
                    "The account update could not be confirmed. Refresh before trying again."
                isError = true
            } finally {
                busyUserId = null
            }
        }
    }

    pendingChange?.let { change ->
        val person = change.user.fullName.ifBlank {
            change.user.email.ifBlank { "this user" }
        }

        val description = when {
            change.newRole != null ->
                "Change $person's role to ${roleLabel(change.newRole)}? Their available features will change."

            change.newStatus == "active" ->
                "Activate $person's account and allow them to sign in?"

            else ->
                "Deactivate $person's account? They will no longer be allowed to sign in."
        }

        AlertDialog(
            onDismissRequest = { pendingChange = null },
            title = { Text("Confirm account change") },
            text = { Text(description) },
            confirmButton = {
                TextButton(onClick = { applyChange(change) }) {
                    Text("Confirm")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingChange = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    val shownUsers = users.filter { user ->
        val matchesRole = roleFilter == null || user.role == roleFilter
        val matchesSearch =
            search.isBlank() ||
                    user.fullName.contains(search, ignoreCase = true) ||
                    user.email.contains(search, ignoreCase = true)

        matchesRole && matchesSearch
    }

    Scaffold(
        topBar = {
            SafeSiteListTopBar(
                title = "People",
                subtitle = when {
                    loader.isLoading -> "Loading user accounts…"
                    loader.errorMessage != null -> "User accounts unavailable"
                    else ->
                        "${users.size} user account${if (users.size == 1) "" else "s"}"
                },
                actionLabel = "Add",
                onBack = { if (!busy) onBack() },
                onCreate = onAddPerson,
                createEnabled = !busy && dataReady,
                onRefresh = if (!busy && !loader.isLoading) {
                    { refreshKey++ }
                } else {
                    null
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            message?.let { currentMessage ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(14.dp),
                    color = if (isError) {
                        MaterialTheme.colorScheme.errorContainer
                    } else {
                        AdminSuccess.copy(alpha = 0.12f)
                    },
                    contentColor = if (isError) {
                        MaterialTheme.colorScheme.onErrorContainer
                    } else {
                        AdminSuccess
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            currentMessage,
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyMedium
                        )

                        TextButton(onClick = { message = null }) {
                            Text("Dismiss")
                        }
                    }
                }
            }

            when {
                loader.isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }

                loader.errorMessage != null -> {
                    ScreenLoadError(
                        message = loader.errorMessage
                            ?: "User accounts could not be loaded.",
                        onRetry = { refreshKey++ },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                else -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(
                            start = 16.dp,
                            top = 8.dp,
                            end = 16.dp,
                            bottom = 32.dp
                        ),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            OutlinedTextField(
                                value = search,
                                onValueChange = { search = it },
                                label = { Text("Search people") },
                                placeholder = { Text("Name or email address") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                FilterChip(
                                    selected = roleFilter == null,
                                    onClick = { roleFilter = null },
                                    label = { Text("All (${users.size})") }
                                )

                                Role.values().forEach { role ->
                                    FilterChip(
                                        selected = roleFilter == role.name,
                                        onClick = { roleFilter = role.name },
                                        label = {
                                            Text(
                                                "${role.label} (${users.count { it.role == role.name }})"
                                            )
                                        }
                                    )
                                }
                            }
                        }

                        if (shownUsers.isEmpty()) {
                            item {
                                SafeSiteEmptyState(
                                    icon = Icons.Filled.Person,
                                    title = if (
                                        search.isNotBlank() || roleFilter != null
                                    ) {
                                        "No matching people"
                                    } else {
                                        "No users found"
                                    },
                                    description = if (
                                        search.isNotBlank() || roleFilter != null
                                    ) {
                                        "Try changing the search or role filter."
                                    } else {
                                        "Use Add in the header to create a SafeSite account."
                                    }
                                )
                            }
                        }

                        items(
                            items = shownUsers,
                            key = { it.id }
                        ) { user ->
                            PersonCard(
                                user = user,
                                isMe = user.id == myUid,
                                actionsEnabled = !busy,
                                isWorking = busyUserId == user.id,
                                onChangeRole = { newRole ->
                                    pendingChange = AccountChange(
                                        user = user,
                                        newRole = newRole
                                    )
                                },
                                onToggleStatus = {
                                    pendingChange = AccountChange(
                                        user = user,
                                        newStatus = if (user.status == "active") {
                                            "inactive"
                                        } else {
                                            "active"
                                        }
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PersonCard(
    user: AppUser,
    isMe: Boolean,
    actionsEnabled: Boolean,
    isWorking: Boolean,
    onChangeRole: (String) -> Unit,
    onToggleStatus: () -> Unit
) {
    var roleMenuOpen by remember { mutableStateOf(false) }
    val active = user.status == "active"

    LaunchedEffect(actionsEnabled) {
        if (!actionsEnabled) roleMenuOpen = false
    }

    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Icon(
                        Icons.Filled.Person,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(11.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        user.fullName.ifBlank { "Unnamed user" },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        user.email.ifBlank { "No email address" },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (active) {
                        AdminSuccess.copy(alpha = 0.12f)
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    }
                ) {
                    Text(
                        when (user.status) {
                            "active" -> "Active"
                            "inactive" -> "Inactive"
                            else -> "Unknown status"
                        },
                        modifier = Modifier.padding(
                            horizontal = 10.dp,
                            vertical = 5.dp
                        ),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(50),
                color = MaterialTheme.colorScheme.secondaryContainer
            ) {
                Text(
                    roleLabel(user.role),
                    modifier = Modifier.padding(
                        horizontal = 10.dp,
                        vertical = 5.dp
                    ),
                    style = MaterialTheme.typography.labelMedium
                )
            }

            if (isMe) {
                Text(
                    "Your account",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelMedium
                )

                Text(
                    "Your own role and account status cannot be changed here.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                HorizontalDivider()

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box {
                        TextButton(
                            enabled = actionsEnabled,
                            onClick = { roleMenuOpen = true }
                        ) {
                            Text("Change role")
                        }

                        DropdownMenu(
                            expanded = roleMenuOpen,
                            onDismissRequest = { roleMenuOpen = false }
                        ) {
                            Role.values().forEach { role ->
                                DropdownMenuItem(
                                    text = { Text(role.label) },
                                    enabled =
                                        actionsEnabled && role.name != user.role,
                                    onClick = {
                                        roleMenuOpen = false
                                        onChangeRole(role.name)
                                    }
                                )
                            }
                        }
                    }

                    TextButton(
                        enabled = actionsEnabled,
                        onClick = onToggleStatus
                    ) {
                        Text(
                            if (active) "Deactivate" else "Activate",
                            color = if (active) {
                                MaterialTheme.colorScheme.error
                            } else {
                                AdminSuccess
                            }
                        )
                    }

                    if (isWorking) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp
                        )
                    }
                }
            }
        }
    }
}