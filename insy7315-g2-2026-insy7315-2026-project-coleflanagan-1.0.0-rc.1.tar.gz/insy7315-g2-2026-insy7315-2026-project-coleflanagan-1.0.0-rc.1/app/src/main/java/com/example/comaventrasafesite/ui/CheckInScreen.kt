package com.example.comaventrasafesite.ui.checkin

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.Attendance
import com.example.comaventrasafesite.repository.AttendanceRepository
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@Composable
fun CheckInScreen(
    siteId: String,
    siteName: String = "",
    onBack: () -> Unit
) {
    val repository = remember {
        AttendanceRepository()
    }

    val scope = rememberCoroutineScope()
    val loader = rememberScreenLoader()
    val scrollState = rememberScrollState()

    val workerId = remember {
        FirebaseAuth.getInstance().currentUser?.uid.orEmpty()
    }

    var resolvedSiteName by remember(siteId) {
        mutableStateOf(
            siteName.ifBlank {
                "Assigned site"
            }
        )
    }

    var openAttendance by remember {
        mutableStateOf<Attendance?>(null)
    }

    var actionInProgress by remember {
        mutableStateOf(false)
    }

    var actionMessage by remember {
        mutableStateOf<String?>(null)
    }

    var actionFailed by remember {
        mutableStateOf(false)
    }

    BackHandler(enabled = actionInProgress) {
        // Wait for the current attendance change to finish.
    }

    suspend fun reload() {
        loader.run {
            val attendance = repository
                .getOpenAttendance(workerId)

            val displayedSiteId = attendance?.siteId ?: siteId

            val fallbackName = if (displayedSiteId == siteId) {
                siteName.ifBlank {
                    "Assigned site"
                }
            } else {
                "Current check-in site"
            }

            // A site-name lookup is cosmetic. A missing name must not
            // turn a confirmed check-in into "not checked in".
            val loadedName = withTimeoutOrNull(2_000L) {
                try {
                    repository.getSiteName(displayedSiteId)
                } catch (error: CancellationException) {
                    throw error
                } catch (_: Exception) {
                    null
                }
            }

            openAttendance = attendance
            resolvedSiteName = loadedName ?: fallbackName
        }
    }

    LaunchedEffect(siteId, workerId) {
        reload()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
    ) {
        Surface(
            color = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(
                        horizontal = 8.dp,
                        vertical = 14.dp
                    ),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    enabled = !actionInProgress
                ) {
                    Icon(
                        imageVector = Icons.Filled.ArrowBack,
                        contentDescription = "Back"
                    )
                }

                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "Site Attendance",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = resolvedSiteName,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimary.copy(
                            alpha = 0.75f
                        )
                    )
                }

                IconButton(
                    onClick = {
                        scope.launch {
                            reload()
                        }
                    },
                    enabled = !actionInProgress && !loader.isLoading
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = "Refresh attendance"
                    )
                }
            }
        }

        val loadError = loader.errorMessage

        when {
            loader.isLoading -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }

            loadError != null -> {
                ScreenLoadError(
                    message = loadError,
                    onRetry = {
                        scope.launch {
                            reload()
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }

            else -> {
                val currentAttendance = openAttendance

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(scrollState)
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    ElevatedCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        elevation = CardDefaults.elevatedCardElevation(
                            defaultElevation = 1.dp
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color =
                                        MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Place,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }

                                Spacer(
                                    modifier = Modifier.width(14.dp)
                                )

                                Column(
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = resolvedSiteName,
                                        style =
                                            MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold
                                    )

                                    Text(
                                        text = if (currentAttendance != null) {
                                            "Currently checked in"
                                        } else {
                                            "Not checked in"
                                        },
                                        style =
                                            MaterialTheme.typography.bodyMedium,
                                        color = if (currentAttendance != null) {
                                            MaterialTheme.colorScheme.primary
                                        } else {
                                            MaterialTheme.colorScheme
                                                .onSurfaceVariant
                                        }
                                    )
                                }
                            }

                            currentAttendance?.let { attendance ->
                                HorizontalDivider()

                                Row(
                                    horizontalArrangement =
                                        Arrangement.spacedBy(10.dp),
                                    verticalAlignment =
                                        Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.CheckCircle,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )

                                    Column {
                                        Text(
                                            text = "Checked in",
                                            style =
                                                MaterialTheme.typography.labelMedium
                                        )

                                        Text(
                                            text = attendance.checkIn?.let {
                                                formatAttendanceTime(it)
                                            } ?: "Time unavailable",
                                            style =
                                                MaterialTheme.typography.bodyLarge
                                        )
                                    }
                                }

                                if (attendance.siteId != siteId) {
                                    Text(
                                        text = "Your open check-in belongs to " +
                                                "another site. Check out of " +
                                                "that site before checking in again.",
                                        style =
                                            MaterialTheme.typography.bodySmall,
                                        color =
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    actionMessage?.let { message ->
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = if (actionFailed) {
                                MaterialTheme.colorScheme.errorContainer
                            } else {
                                MaterialTheme.colorScheme.primaryContainer
                            }
                        ) {
                            Text(
                                text = message,
                                color = if (actionFailed) {
                                    MaterialTheme.colorScheme.onErrorContainer
                                } else {
                                    MaterialTheme.colorScheme.onPrimaryContainer
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    }

                    Button(
                        onClick = {
                            if (actionInProgress) return@Button

                            actionInProgress = true
                            actionMessage = null

                            val attendanceBeforeAction = openAttendance

                            scope.launch {
                                try {
                                    val result = if (
                                        attendanceBeforeAction == null
                                    ) {
                                        repository.checkIn(
                                            siteId = siteId,
                                            workerId = workerId
                                        ).map {
                                            Unit
                                        }
                                    } else {
                                        repository.checkOut(
                                            attendanceBeforeAction.id
                                        )
                                    }

                                    result.onSuccess {
                                        actionFailed = false
                                        actionMessage =
                                            if (attendanceBeforeAction == null) {
                                                "Checked in successfully."
                                            } else {
                                                "Checked out successfully."
                                            }
                                    }.onFailure { error ->
                                        actionFailed = true
                                        actionMessage =
                                            error.message
                                                ?: "Attendance could not be updated."
                                    }

                                    reload()
                                } catch (error: CancellationException) {
                                    throw error
                                } catch (error: Exception) {
                                    actionFailed = true
                                    actionMessage =
                                        error.message
                                            ?: "Attendance could not be updated."
                                } finally {
                                    actionInProgress = false
                                }
                            }
                        },
                        enabled = !actionInProgress &&
                                workerId.isNotBlank() &&
                                (
                                        currentAttendance != null ||
                                                siteId.isNotBlank()
                                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        if (actionInProgress) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        } else {
                            Text(
                                text = if (currentAttendance == null) {
                                    "Check in"
                                } else {
                                    "Check out"
                                }
                            )
                        }
                    }

                    Text(
                        text = "Check out when you leave the site.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

private fun formatAttendanceTime(
    timestamp: Long
): String {
    return SimpleDateFormat(
        "dd MMM yyyy, HH:mm",
        Locale.getDefault()
    ).apply {
        timeZone = TimeZone.getTimeZone(
            "Africa/Johannesburg"
        )
    }.format(Date(timestamp))
}