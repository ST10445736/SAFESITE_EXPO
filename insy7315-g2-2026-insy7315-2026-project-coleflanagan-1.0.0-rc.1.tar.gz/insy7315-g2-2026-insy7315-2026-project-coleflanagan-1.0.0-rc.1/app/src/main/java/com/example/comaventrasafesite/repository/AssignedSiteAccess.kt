package com.example.comaventrasafesite.repository

import com.example.comaventrasafesite.model.Role
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import kotlinx.coroutines.tasks.await

internal object AssignedSiteAccess {
    suspend fun requireAssignment(siteId: String, workerId: String): String {
        require(siteId.isNotBlank() && workerId.isNotBlank()) {
            "A site and assigned account are required."
        }
        val snapshot = FirebaseFirestore.getInstance()
            .collection("site_assignments")
            .whereEqualTo("workerId", workerId)
            .get(Source.SERVER).await()
        val today = SiteAssignmentRepository.today()
        return snapshot.documents.firstOrNull {
            val start = it.getString("startDate").orEmpty()
            it.getString("siteId") == siteId &&
                it.getString("endDate").orEmpty().isBlank() &&
                (start.isBlank() || start <= today)
        }?.id ?: error("This account has no current assignment at this site.")
    }

    suspend fun forReport(siteId: String): String {
        val uid = FirebaseAuth.getInstance().currentUser?.uid
            ?: error("Please sign in again.")
        val profile = FirebaseFirestore.getInstance()
            .collection("users").document(uid).get(Source.SERVER).await()
        val role = profile.getString("role")
        check(profile.getString("status") == "active" &&
            Role.values().any { it.name == role }) {
            "An active account with a valid role is required."
        }
        return if (role == Role.WORKER.name) requireAssignment(siteId, uid) else ""
    }
}
