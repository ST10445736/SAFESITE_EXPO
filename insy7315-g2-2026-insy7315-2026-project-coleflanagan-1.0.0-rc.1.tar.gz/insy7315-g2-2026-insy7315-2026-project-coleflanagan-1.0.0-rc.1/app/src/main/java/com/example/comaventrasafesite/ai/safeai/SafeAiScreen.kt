package com.example.comaventrasafesite.ui.safeai

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.ai.SafeAiChat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

private data class ChatMessage(
    val text: String,
    val fromUser: Boolean
)

private val boldPattern = Regex(
    pattern = "\\*\\*(.+?)\\*\\*",
    option = RegexOption.DOT_MATCHES_ALL
)

private fun formatSafeAiReply(text: String): AnnotatedString {
    return buildAnnotatedString {
        var position = 0

        boldPattern.findAll(text).forEach { match ->
            append(text.substring(position, match.range.first))

            val start = length
            append(match.groupValues[1])

            addStyle(
                style = SpanStyle(fontWeight = FontWeight.Bold),
                start = start,
                end = length
            )

            position = match.range.last + 1
        }

        append(text.substring(position))
    }
}

@Composable
fun SafeAiScreen(
    onBack: () -> Unit
) {
    val chat = remember { SafeAiChat.startChat() }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    val messages = remember {
        mutableStateListOf(
            ChatMessage(
                text = "Hi, I'm SafeAI. Ask me how SafeSite works, including tasks, PPE, training or managing projects.",
                fromUser = false
            )
        )
    }

    var input by remember { mutableStateOf("") }
    var isThinking by remember { mutableStateOf(false) }

    val suggestions = remember {
        listOf(
            "How do I check in?",
            "How does PPE approval work?",
            "How do I create a task?",
            "How do I record training?",
            "How do I add a project?"
        )
    }

    LaunchedEffect(messages.size, isThinking) {
        val lastIndex = if (isThinking) {
            messages.size
        } else {
            messages.lastIndex
        }

        if (lastIndex >= 0) {
            listState.animateScrollToItem(lastIndex)
        }
    }

    fun send(text: String) {
        val question = text.trim()

        if (question.isBlank() || isThinking) {
            return
        }

        messages.add(
            ChatMessage(
                text = question,
                fromUser = true
            )
        )

        input = ""
        isThinking = true

        scope.launch {
            try {
                val reply = chat.sendMessage(question).text
                    ?.takeIf { it.isNotBlank() }
                    ?: "I couldn't generate an answer. Please try asking again."

                messages.add(
                    ChatMessage(
                        text = reply,
                        fromUser = false
                    )
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                android.util.Log.e("SafeAI", "Chat failed", e)

                messages.add(
                    ChatMessage(
                        text = "SafeAI is unavailable right now. Please check your connection or ask your supervisor.",
                        fromUser = false
                    )
                )
            } finally {
                isThinking = false
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Surface(
            color = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(
                    horizontal = 8.dp,
                    vertical = 14.dp
                ),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back"
                    )
                }

                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "SafeAI Assistant",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "Ask how anything in SafeSite works",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { message ->
                val displayText = remember(
                    message.text,
                    message.fromUser
                ) {
                    if (message.fromUser) {
                        AnnotatedString(message.text)
                    } else {
                        formatSafeAiReply(message.text)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (message.fromUser) {
                        Arrangement.End
                    } else {
                        Arrangement.Start
                    }
                ) {
                    Surface(
                        color = if (message.fromUser) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant
                        },
                        contentColor = if (message.fromUser) {
                            MaterialTheme.colorScheme.onPrimary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.widthIn(max = 300.dp)
                    ) {
                        Text(
                            text = displayText,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }

            if (isThinking) {
                item {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp
                        )

                        Text(
                            text = "SafeAI is typing…",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        if (messages.size == 1) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                suggestions.forEach { suggestion ->
                    AssistChip(
                        onClick = {
                            send(suggestion)
                        },
                        enabled = !isThinking,
                        label = {
                            Text(
                                text = suggestion,
                                maxLines = 1
                            )
                        }
                    )
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = {
                    input = it
                },
                placeholder = {
                    Text("Ask SafeAI…")
                },
                modifier = Modifier.weight(1f),
                maxLines = 3
            )

            Button(
                onClick = {
                    send(input)
                },
                enabled = input.isNotBlank() && !isThinking
            ) {
                Text("Send")
            }
        }
    }
}