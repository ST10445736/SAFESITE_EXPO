package com.example.comaventrasafesite.ui.supervisor

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.repository.SupervisorSessionRepository
import com.example.comaventrasafesite.repository.SupervisorSiteContext
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

@Composable
fun SupervisorSiteGate(
    selectedDestination: SupervisorDestination,
    onNavigate: (SupervisorDestination) -> Unit,
    content: @Composable (SupervisorSiteContext) -> Unit
) {
    val repository = remember {
        SupervisorSessionRepository()
    }

    val loader = rememberScreenLoader()
    val scope = rememberCoroutineScope()

    val userId = FirebaseAuth.getInstance()
        .currentUser?.uid.orEmpty()

    var siteContext by remember(userId) {
        mutableStateOf<SupervisorSiteContext?>(null)
    }

    fun refresh() {
        scope.launch {
            loader.run {
                siteContext = repository.getActiveSite(userId)
            }
        }
    }

    LaunchedEffect(userId) {
        refresh()
    }

    val resolvedSite = siteContext
    val loadError = loader.errorMessage

    when {
        loader.isLoading -> {
            SupervisorSiteStatusScreen(
                selectedDestination = selectedDestination,
                onNavigate = onNavigate
            ) {
                CircularProgressIndicator()
            }
        }

        loadError != null -> {
            SupervisorSiteStatusScreen(
                selectedDestination = selectedDestination,
                onNavigate = onNavigate
            ) {
                ScreenLoadError(
                    message = loadError,
                    onRetry = {
                        refresh()
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        resolvedSite == null -> {
            SupervisorSiteStatusScreen(
                selectedDestination = selectedDestination,
                onNavigate = onNavigate
            ) {
                Column(
                    modifier = Modifier.padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Place,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(48.dp)
                    )

                    Text(
                        text = "No active site assignment",
                        style = MaterialTheme.typography.titleLarge,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = "Ask an administrator to assign your account " +
                                "to an active site and project.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )

                    TextButton(
                        onClick = {
                            refresh()
                        }
                    ) {
                        Text("Refresh assignment")
                    }
                }
            }
        }

        else -> {
            content(resolvedSite)
        }
    }
}

@Composable
private fun SupervisorSiteStatusScreen(
    selectedDestination: SupervisorDestination,
    onNavigate: (SupervisorDestination) -> Unit,
    content: @Composable () -> Unit
) {
    Scaffold(
        bottomBar = {
            SupervisorBottomBar(
                selectedDestination = selectedDestination,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.Center
        ) {
            content()
        }
    }
}