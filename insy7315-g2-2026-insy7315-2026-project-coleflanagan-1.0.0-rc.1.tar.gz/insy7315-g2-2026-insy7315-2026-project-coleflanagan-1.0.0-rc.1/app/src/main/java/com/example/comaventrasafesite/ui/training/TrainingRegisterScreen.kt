package com.example.comaventrasafesite.ui.training

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.TrainingRecord
import com.example.comaventrasafesite.repository.TrainingRepository
import com.example.comaventrasafesite.ui.shared.SafeSiteEmptyState
import com.example.comaventrasafesite.ui.shared.SafeSiteListTopBar
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

fun trainingStatusColor(
    status: String
): Color = when (status) {
    TrainingRepository.EXPIRED -> Color(0xFFD32F2F)
    TrainingRepository.EXPIRING -> Color(0xFFF57C00)
    TrainingRepository.VALID -> Color(0xFF388E3C)
    else -> Color.Gray
}

fun trainingDateOnly(
    millis: Long
): String {
    if (millis <= 0L) {
        return "Date unavailable"
    }

    return SimpleDateFormat(
        "dd MMM yyyy",
        Locale.getDefault()
    ).apply {
        timeZone = TimeZone.getTimeZone(
            "Africa/Johannesburg"
        )
    }.format(Date(millis))
}

private val trainingFilters = listOf(
    "all",
    TrainingRepository.VALID,
    TrainingRepository.EXPIRING,
    TrainingRepository.EXPIRED
)

@Composable
fun TrainingRegisterScreen(
    siteId: String,
    onBack: () -> Unit,
    onAddNew: () -> Unit
) {
    val repository = remember {
        TrainingRepository()
    }

    val scope = rememberCoroutineScope()
    val loader = rememberScreenLoader()

    var records by remember(siteId) {
        mutableStateOf<List<TrainingRecord>>(emptyList())
    }

    var filter by rememberSaveable(siteId) {
        mutableStateOf("all")
    }

    var canManage by remember(siteId) {
        mutableStateOf(false)
    }

    var recordToDelete by remember {
        mutableStateOf<TrainingRecord?>(null)
    }

    var isDeleting by remember {
        mutableStateOf(false)
    }

    var errorMessage by remember {
        mutableStateOf<String?>(null)
    }

    var statusTime by remember {
        mutableLongStateOf(System.currentTimeMillis())
    }

    BackHandler(enabled = isDeleting) {
        // Wait for the current deletion to finish.
    }

    suspend fun reload() {
        loader.run {
            val loadedRecords = repository.getRecordsForSite(siteId)
            val managementAllowed = repository.canManageTraining()

            records = loadedRecords
            canManage = managementAllowed
            statusTime = System.currentTimeMillis()
        }
    }

    fun refresh() {
        if (isDeleting) return

        scope.launch {
            reload()
        }
    }

    LaunchedEffect(siteId) {
        reload()
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(60_000L)
            statusTime = System.currentTimeMillis()
        }
    }

    val shownRecords = remember(
        records,
        filter,
        statusTime
    ) {
        if (filter == "all") {
            records
        } else {
            records.filter {
                TrainingRepository.statusOf(
                    record = it,
                    now = statusTime
                ) == filter
            }
        }
    }

    recordToDelete?.let { record ->
        AlertDialog(
            onDismissRequest = {
                if (!isDeleting) {
                    recordToDelete = null
                }
            },
            title = {
                Text("Delete training record?")
            },
            text = {
                Text(
                    "${record.courseName} for ${record.workerName} " +
                            "will be permanently removed."
                )
            },
            confirmButton = {
                Button(
                    enabled = !isDeleting,
                    onClick = {
                        if (isDeleting) return@Button

                        isDeleting = true
                        errorMessage = null

                        scope.launch {
                            try {
                                repository.deleteRecord(record.id)
                                    .onFailure { error ->
                                        errorMessage =
                                            error.message
                                                ?: "The record could not be deleted."
                                    }

                                recordToDelete = null
                                reload()
                            } catch (error: CancellationException) {
                                throw error
                            } catch (error: Exception) {
                                recordToDelete = null
                                errorMessage =
                                    error.message
                                        ?: "The record could not be deleted."
                            } finally {
                                isDeleting = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    if (isDeleting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onError
                        )
                    } else {
                        Text("Delete")
                    }
                }
            },
            dismissButton = {
                TextButton(
                    enabled = !isDeleting,
                    onClick = {
                        recordToDelete = null
                    }
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    val loadError = loader.errorMessage

    val subtitle = when {
        loader.isLoading -> "Loading training records…"
        loadError != null -> "Unable to load training records"
        else -> "${records.size} total records"
    }

    Scaffold(
        topBar = {
            SafeSiteListTopBar(
                title = "Training Records",
                subtitle = subtitle,
                actionLabel = "Record",
                onBack = {
                    if (!isDeleting) {
                        onBack()
                    }
                },
                onCreate = onAddNew,
                createEnabled = canManage &&
                        !isDeleting &&
                        !loader.isLoading &&
                        loadError == null,
                onRefresh = {
                    refresh()
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            errorMessage?.let { message ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(
                            horizontal = 16.dp,
                            vertical = 10.dp
                        ),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    contentColor = MaterialTheme.colorScheme.onErrorContainer
                ) {
                    Row(
                        modifier = Modifier.padding(
                            start = 14.dp,
                            top = 8.dp,
                            end = 6.dp,
                            bottom = 8.dp
                        ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = message,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f)
                        )

                        TextButton(
                            onClick = {
                                errorMessage = null
                            }
                        ) {
                            Text("Dismiss")
                        }
                    }
                }
            }

            when {
                loader.isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment =
                                Alignment.CenterHorizontally,
                            verticalArrangement =
                                Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator()

                            Text(
                                text = "Loading training records…",
                                color =
                                    MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                loadError != null -> {
                    ScreenLoadError(
                        message = loadError,
                        onRetry = {
                            refresh()
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                else -> {
                    TrainingSummary(
                        records = records,
                        now = statusTime,
                        selectedFilter = filter,
                        onFilterSelected = {
                            filter = it
                        }
                    )

                    TrainingFilterRow(
                        selectedFilter = filter,
                        onFilterSelected = {
                            filter = it
                        }
                    )

                    if (shownRecords.isEmpty()) {
                        SafeSiteEmptyState(
                            icon = Icons.Filled.CheckCircle,
                            title = if (filter == "all") {
                                "No training records"
                            } else {
                                "No ${
                                    TrainingRepository.label(filter).lowercase()
                                } records"
                            },
                            description = if (filter == "all") {
                                "Completed worker training will appear here."
                            } else {
                                "Try selecting a different status filter."
                            }
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(
                                start = 16.dp,
                                top = 14.dp,
                                end = 16.dp,
                                bottom = 24.dp
                            ),
                            verticalArrangement =
                                Arrangement.spacedBy(12.dp)
                        ) {
                            items(
                                items = shownRecords,
                                key = { it.id }
                            ) { record ->
                                TrainingRecordCard(
                                    record = record,
                                    now = statusTime,
                                    canDelete = canManage && !isDeleting,
                                    onDelete = {
                                        recordToDelete = record
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TrainingSummary(
    records: List<TrainingRecord>,
    now: Long,
    selectedFilter: String,
    onFilterSelected: (String) -> Unit
) {
    val summaryItems = listOf(
        "Valid" to TrainingRepository.VALID,
        "Expiring" to TrainingRepository.EXPIRING,
        "Expired" to TrainingRepository.EXPIRED
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                horizontal = 16.dp,
                vertical = 14.dp
            ),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        summaryItems.forEach { (label, status) ->
            ElevatedCard(
                onClick = {
                    onFilterSelected(status)
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = if (selectedFilter == status) {
                        MaterialTheme.colorScheme.primaryContainer
                    } else {
                        MaterialTheme.colorScheme.surface
                    }
                ),
                elevation = CardDefaults.elevatedCardElevation(
                    defaultElevation = 1.dp
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(
                            horizontal = 6.dp,
                            vertical = 14.dp
                        ),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = records.count {
                            TrainingRepository.statusOf(it, now) == status
                        }.toString(),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = trainingStatusColor(status)
                    )

                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun TrainingFilterRow(
    selectedFilter: String,
    onFilterSelected: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        trainingFilters.forEach { option ->
            FilterChip(
                selected = selectedFilter == option,
                onClick = {
                    onFilterSelected(option)
                },
                label = {
                    Text(
                        text = if (option == "all") {
                            "All"
                        } else {
                            TrainingRepository.label(option)
                        }
                    )
                }
            )
        }
    }
}

@Composable
private fun TrainingRecordCard(
    record: TrainingRecord,
    now: Long,
    canDelete: Boolean,
    onDelete: () -> Unit
) {
    val status = TrainingRepository.statusOf(record, now)
    val statusColor = trainingStatusColor(status)

    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.elevatedCardElevation(
            defaultElevation = 1.dp
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = record.workerName.ifBlank {
                            "Unknown worker"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = record.courseName.ifBlank {
                            "Unnamed course"
                        },
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                Surface(
                    color = statusColor.copy(alpha = 0.12f),
                    contentColor = statusColor,
                    shape = RoundedCornerShape(50)
                ) {
                    Text(
                        text = TrainingRepository.label(status),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(
                            horizontal = 10.dp,
                            vertical = 5.dp
                        )
                    )
                }
            }

            HorizontalDivider()

            if (record.provider.isNotBlank()) {
                TrainingDetailRow(
                    label = "Provider",
                    value = record.provider
                )
            }

            if (record.certificateNumber.isNotBlank()) {
                TrainingDetailRow(
                    label = "Certificate",
                    value = record.certificateNumber
                )
            }

            TrainingDetailRow(
                label = "Completed",
                value = trainingDateOnly(record.completedAt)
            )

            TrainingDetailRow(
                label = "Expires",
                value = record.expiresAt?.let {
                    trainingDateOnly(it)
                } ?: "No expiry"
            )

            if (canDelete) {
                TextButton(
                    onClick = onDelete,
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    ),
                    contentPadding = PaddingValues(horizontal = 0.dp)
                ) {
                    Text("Delete record")
                }
            }
        }
    }
}

@Composable
private fun TrainingDetailRow(
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(0.38f)
        )

        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(0.62f)
        )
    }
}