package com.example.comaventrasafesite.ui.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.Site
import kotlinx.coroutines.CancellationException

internal class ProjectActionState {
    var busy by mutableStateOf(false)
        private set

    var message by mutableStateOf<String?>(null)
        private set

    var isError by mutableStateOf(false)
        private set

    fun clear() {
        if (!busy) {
            message = null
            isError = false
        }
    }

    suspend fun run(
        successMessage: String,
        reload: suspend () -> Unit,
        onSuccess: () -> Unit = {},
        action: suspend () -> Result<*>
    ) {
        if (busy) return

        busy = true
        message = null
        isError = false

        try {
            action().fold(
                onSuccess = {
                    message = successMessage
                    onSuccess()
                },
                onFailure = { error ->
                    if (error is CancellationException) throw error

                    isError = true
                    message = error.message
                        ?: "The update could not be confirmed. Refresh before trying again."
                }
            )

            reload()
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            isError = true
            message =
                "The update could not be confirmed. Refresh before trying again."
        } finally {
            busy = false
        }
    }
}

@Composable
internal fun ProjectPanel(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            content()
        }
    }
}

@Composable
internal fun ProjectMessage(actions: ProjectActionState) {
    actions.message?.let { message ->
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            color = if (actions.isError) {
                MaterialTheme.colorScheme.errorContainer
            } else {
                Color(0xFFEAF2E8)
            },
            contentColor = if (actions.isError) {
                MaterialTheme.colorScheme.onErrorContainer
            } else {
                Color(0xFF496F42)
            }
        ) {
            Text(
                message,
                modifier = Modifier.padding(14.dp),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
internal fun ProjectWaiting(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        CircularProgressIndicator()
    }
}

@Composable
internal fun ProjectFormDialog(
    title: String,
    busy: Boolean,
    error: String?,
    onDismiss: () -> Unit,
    onSave: () -> Unit,
    saveLabel: String = "Save",
    content: @Composable ColumnScope.() -> Unit
) {
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        shape = RoundedCornerShape(22.dp),
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                content()

                error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            Button(
                enabled = !busy,
                onClick = onSave
            ) {
                if (busy) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp
                    )
                } else {
                    Text(saveLabel)
                }
            }
        },
        dismissButton = {
            TextButton(
                enabled = !busy,
                onClick = onDismiss
            ) {
                Text("Cancel")
            }
        }
    )
}

@Composable
internal fun ProjectSiteCard(
    site: Site,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    OutlinedCard(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.outlinedCardColors(
            containerColor = Color.White
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                site.name.ifBlank { "Unnamed site" },
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                site.address.ifBlank { "No address recorded" },
                style = MaterialTheme.typography.bodyMedium
            )
            StatusBadge(site.status)
        }
    }
}