package com.example.comaventrasafesite.repository

import com.example.comaventrasafesite.model.SiteAssignment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class SiteAssignmentRepository {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    companion object {
        fun today(): String {
            return SimpleDateFormat(
                "yyyy-MM-dd",
                Locale.US
            ).apply {
                timeZone = TimeZone.getTimeZone(
                    "Africa/Johannesburg"
                )
            }.format(Date())
        }
    }

    suspend fun getMyAssignments(
        workerId: String
    ): List<SiteAssignment> {
        require(
            workerId.isNotBlank() &&
                    auth.currentUser?.uid == workerId
        ) {
            "Please sign in again."
        }

        val snapshot = db.collection("site_assignments")
            .whereEqualTo("workerId", workerId)
            .get(Source.SERVER)
            .await()

        return snapshot.documents
            .mapNotNull { document ->
                document.toObject(SiteAssignment::class.java)
                    ?.copy(id = document.id)
            }
            .onEach { assignment ->
                check(assignment.siteId.isNotBlank()) {
                    "A site assignment is incomplete. " +
                            "Contact your administrator."
                }
            }
            .sortedByDescending {
                it.startDate
            }
    }
}