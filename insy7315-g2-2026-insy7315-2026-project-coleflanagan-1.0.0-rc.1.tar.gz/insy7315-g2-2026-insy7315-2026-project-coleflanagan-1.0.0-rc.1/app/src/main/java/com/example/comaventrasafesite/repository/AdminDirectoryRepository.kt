package com.example.comaventrasafesite.repository

import com.example.comaventrasafesite.model.AppUser
import com.example.comaventrasafesite.model.Role
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import kotlinx.coroutines.tasks.await
import java.util.Locale

class AdminDirectoryRepository {

    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    suspend fun getUsers(): List<AppUser> {
        val administratorId = auth.currentUser?.uid
            ?: error("Sign in before viewing user accounts.")

        val administrator = db.collection("users")
            .document(administratorId)
            .get(Source.SERVER)
            .await()

        check(
            administrator.exists() &&
                    administrator.getString("status") == "active" &&
                    administrator.getString("role") == Role.ADMIN.name
        ) {
            "An active Administrator account is required."
        }

        val snapshot = db.collection("users")
            .get(Source.SERVER)
            .await()

        check(auth.currentUser?.uid == administratorId) {
            "Your session changed. Sign in again."
        }

        return snapshot.documents.map { document ->
            AppUser(
                id = document.id,
                fullName = document.getString("fullName").orEmpty(),
                email = document.getString("email").orEmpty(),
                role = document.getString("role").orEmpty(),
                status = document.getString("status").orEmpty()
            )
        }.sortedWith(
            compareBy<AppUser> {
                it.fullName.ifBlank { it.email }.lowercase(Locale.ROOT)
            }.thenBy { it.id }
        )
    }
}