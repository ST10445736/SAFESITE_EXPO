package com.example.comaventrasafesite.ui.ppe

import android.util.Base64
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.comaventrasafesite.model.PpeSubmission
import com.example.comaventrasafesite.repository.AttendanceRepository
import com.example.comaventrasafesite.repository.PpeRepository
import com.example.comaventrasafesite.ui.supervisor.SupervisorBottomBar
import com.example.comaventrasafesite.ui.supervisor.SupervisorDestination
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private fun ppeImageModel(
    photoUrl: String
): Any? {
    if (photoUrl.isBlank()) {
        return null
    }

    return if (photoUrl.startsWith("data:image/")) {
        runCatching {
            val separator = photoUrl.indexOf(',')
            require(separator >= 0)

            Base64.decode(
                photoUrl.substring(separator + 1),
                Base64.DEFAULT
            )
        }.getOrNull()
    } else {
        photoUrl
    }
}

@Composable
fun PpeApprovalScreen(
    siteId: String,
    onNavigate: (SupervisorDestination) -> Unit
) {
    val repository = remember { PpeRepository() }
    val attendanceRepository = remember {
        AttendanceRepository()
    }
    val scope = rememberCoroutineScope()

    var pending by remember {
        mutableStateOf<List<PpeSubmission>>(emptyList())
    }
    var workerNames by remember {
        mutableStateOf<Map<String, String>>(emptyMap())
    }
    var isLoading by remember { mutableStateOf(true) }
    var reviewingId by remember {
        mutableStateOf<String?>(null)
    }
    var loadError by remember {
        mutableStateOf<String?>(null)
    }
    var reviewError by remember {
        mutableStateOf<String?>(null)
    }

    suspend fun loadPending() {
        isLoading = true
        loadError = null

        try {
            pending = repository.getPendingSubmissions(siteId)

            workerNames = attendanceRepository.getWorkerNames(
                pending.map { it.workerId }
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            loadError = e.message
                ?: "PPE submissions could not be loaded."
        } finally {
            isLoading = false
        }
    }

    fun refresh() {
        scope.launch {
            loadPending()
        }
    }

    fun review(
        submissionId: String,
        approved: Boolean
    ) {
        reviewingId = submissionId
        reviewError = null

        scope.launch {
            try {
                repository.reviewSubmission(
                    submissionId = submissionId,
                    approved = approved
                ).onSuccess {
                    loadPending()
                }.onFailure {
                    reviewError = it.message
                        ?: "The review could not be saved."
                }
            } finally {
                reviewingId = null
            }
        }
    }

    LaunchedEffect(siteId) {
        loadPending()
    }

    Scaffold(
        bottomBar = {
            SupervisorBottomBar(
                selectedDestination = SupervisorDestination.WORKERS,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Surface(
                color = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(
                        horizontal = 20.dp,
                        vertical = 22.dp
                    ),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "PPE Review",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "Showing ${pending.size} pending submission(s)",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimary
                                .copy(alpha = 0.75f)
                        )
                    }

                    TextButton(
                        onClick = {
                            refresh()
                        },
                        enabled = !isLoading && reviewingId == null
                    ) {
                        Text(
                            text = "Refresh",
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }

            reviewError?.let { message ->
                Text(
                    text = message,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(20.dp)
                )
            }

            when {
                isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }

                loadError != null -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "Could not load PPE submissions",
                            style = MaterialTheme.typography.titleLarge
                        )

                        Text(
                            text = loadError.orEmpty(),
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(top = 8.dp)
                        )

                        TextButton(
                            onClick = {
                                refresh()
                            }
                        ) {
                            Text("Try again")
                        }
                    }
                }

                pending.isEmpty() -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(28.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Queue is clear",
                                style = MaterialTheme.typography.titleLarge
                            )

                            Text(
                                text = "There are no pending PPE submissions.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                    }
                }

                else -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(
                            items = pending,
                            key = { it.id }
                        ) { submission ->
                            val imageModel = remember(submission.photoUrl) {
                                ppeImageModel(submission.photoUrl)
                            }

                            var photoLoaded by remember(submission.photoUrl) {
                                mutableStateOf(false)
                            }

                            var photoFailed by remember(submission.photoUrl) {
                                mutableStateOf(imageModel == null)
                            }

                            ElevatedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column {
                                    if (imageModel != null) {
                                        AsyncImage(
                                            model = imageModel,
                                            contentDescription = "Submitted PPE photo",
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(260.dp),
                                            contentScale = ContentScale.Fit,
                                            onSuccess = {
                                                photoLoaded = true
                                                photoFailed = false
                                            },
                                            onError = {
                                                photoLoaded = false
                                                photoFailed = true
                                            }
                                        )
                                    }

                                    Column(
                                        modifier = Modifier.padding(18.dp)
                                    ) {
                                        if (photoFailed) {
                                            Text(
                                                text = "The photo could not be loaded. Do not approve a photo you cannot inspect.",
                                                color = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.padding(bottom = 12.dp)
                                            )
                                        }

                                        Text(
                                            text = workerNames[submission.workerId]
                                                ?: "Worker",
                                            style = MaterialTheme.typography.titleMedium
                                        )

                                        Text(
                                            text = "Awaiting review",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )

                                        val submittedLabel = remember(submission.submittedAt) {
                                            if (submission.submittedAt > 0L) {
                                                val formatter = SimpleDateFormat(
                                                    "dd MMM yyyy 'at' HH:mm",
                                                    Locale.ENGLISH
                                                ).apply {
                                                    timeZone = TimeZone.getTimeZone("Africa/Johannesburg")
                                                }

                                                "Submitted ${formatter.format(Date(submission.submittedAt))} SAST"
                                            } else {
                                                "Submission time unavailable"
                                            }
                                        }

                                        Text(
                                            text = submittedLabel,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.padding(top = 4.dp)
                                        )

                                        AiVerdictBadge(
                                            verdict = submission.aiVerdict,
                                            reason = submission.aiReason
                                        )

                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(top = 14.dp),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Button(
                                                onClick = {
                                                    review(submission.id, true)
                                                },
                                                enabled = reviewingId == null &&
                                                        photoLoaded &&
                                                        !photoFailed,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text("Approve")
                                            }

                                            OutlinedButton(
                                                onClick = {
                                                    review(submission.id, false)
                                                },
                                                enabled = reviewingId == null,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text("Reject")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AiVerdictBadge(
    verdict: String,
    reason: String
) {
    if (verdict.isBlank()) {
        return
    }

    val (label, color) = when (verdict) {
        "compliant" ->
            "AI: PPE looks compliant" to Color(0xFF2E7D32)

        "non_compliant" ->
            "AI: PPE issue spotted" to Color(0xFFC62828)

        "unclear" ->
            "AI: photo unclear" to Color(0xFFEF6C00)

        else ->
            "AI check unavailable" to Color(0xFF757575)
    }

    Surface(
        color = color.copy(alpha = 0.12f),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Text(
                text = label,
                color = color,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )

            if (reason.isNotBlank()) {
                Text(
                    text = reason,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            Text(
                text = "Advisory only. You make the final decision.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}