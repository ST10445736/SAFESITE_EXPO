package com.example.comaventrasafesite.repository

import android.content.Context
import android.util.Log
import android.util.Patterns
import com.example.comaventrasafesite.AppCheckSetup
import com.example.comaventrasafesite.model.AppUser
import com.example.comaventrasafesite.model.Role
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

class AdminRepository {

    private val db = FirebaseFirestore.getInstance()
    private val users = db.collection("users")
    private val mainAuth = FirebaseAuth.getInstance()

    companion object {
        private const val CREATOR_APP = "admin-user-creator"
        private const val LOG_TAG = "SafeSiteAccounts"

        private const val PROFILE_CHECK_TIMEOUT_MS = 15_000L
        private const val PROFILE_WRITE_TIMEOUT_MS = 30_000L
        private const val CLEANUP_TIMEOUT_MS = 15_000L

        private val creationMutex = Mutex()
    }

    private fun creatorAuth(
        context: Context
    ): FirebaseAuth {
        val app = try {
            FirebaseApp.getInstance(CREATOR_APP)
        } catch (_: IllegalStateException) {
            FirebaseApp.initializeApp(
                context.applicationContext,
                FirebaseApp.getInstance().options,
                CREATOR_APP
            ).also { createdApp ->
                AppCheckSetup.install(createdApp)
            }
        }

        return FirebaseAuth.getInstance(app)
    }

    private suspend fun requireAdministrator(): String {
        val account = mainAuth.currentUser
            ?: error("Please sign in again.")

        val profile = withTimeoutOrNull(
            PROFILE_CHECK_TIMEOUT_MS
        ) {
            users.document(account.uid)
                .get(Source.SERVER)
                .await()
        } ?: error(
            "Your account could not be verified. " +
                    "Check your internet connection and try again."
        )

        check(
            profile.exists() &&
                    profile.getString("status") == "active" &&
                    profile.getString("role") == Role.ADMIN.name
        ) {
            "An active administrator account is required."
        }

        check(mainAuth.currentUser?.uid == account.uid) {
            "Your signed-in account has changed. Please sign in again."
        }

        return account.uid
    }

    suspend fun getUsers(): List<AppUser> {
        return try {
            users.get()
                .await()
                .documents
                .mapNotNull { document ->
                    document.toObject(AppUser::class.java)
                        ?.copy(id = document.id)
                }
                .sortedBy {
                    it.fullName.lowercase()
                }
        } catch (error: CancellationException) {
            throw error
        } catch (_: Exception) {
            // Replaced together with the screen loaders in the next batch.
            emptyList()
        }
    }

    private suspend fun nameOf(
        userId: String
    ): String {
        return try {
            users.document(userId)
                .get()
                .await()
                .getString("fullName")
                ?.takeIf { it.isNotBlank() }
                ?: userId
        } catch (error: CancellationException) {
            throw error
        } catch (_: Exception) {
            userId
        }
    }

    suspend fun createUser(
        context: Context,
        fullName: String,
        email: String,
        password: String,
        role: String
    ): Result<String> {
        val cleanName = fullName.trim()
        val cleanEmail = email.trim()

        if (cleanName.isBlank()) {
            return Result.failure(
                IllegalArgumentException(
                    "Enter the person's full name."
                )
            )
        }

        if (
            !Patterns.EMAIL_ADDRESS
                .matcher(cleanEmail)
                .matches()
        ) {
            return Result.failure(
                IllegalArgumentException(
                    "Enter a valid email address."
                )
            )
        }

        if (password.length < 8) {
            return Result.failure(
                IllegalArgumentException(
                    "Temporary password must be at least 8 characters."
                )
            )
        }

        if (
            Role.values().none {
                it.name == role
            }
        ) {
            return Result.failure(
                IllegalArgumentException(
                    "Choose a valid role."
                )
            )
        }

        return try {
            val uid = creationMutex.withLock {
                val administratorId = requireAdministrator()
                val secondaryAuth = creatorAuth(context)

                withContext(NonCancellable) {
                    try {
                        check(
                            mainAuth.currentUser?.uid == administratorId
                        ) {
                            "Your signed-in account has changed. " +
                                    "Please sign in again."
                        }

                        val credential = secondaryAuth
                            .createUserWithEmailAndPassword(
                                cleanEmail,
                                password
                            )
                            .await()

                        val createdUser = credential.user
                            ?: error(
                                "The account could not be created."
                            )

                        saveProfileOrCleanUp(
                            createdUser = createdUser,
                            profile = AppUser(
                                id = createdUser.uid,
                                fullName = cleanName,
                                email = cleanEmail,
                                role = role,
                                status = "active"
                            )
                        )

                        createdUser.uid
                    } finally {
                        secondaryAuth.signOut()
                    }
                }
            }

            AuditLogger.log(
                action = "USER_CREATED",
                entityType = "user",
                entityId = uid,
                summary = "Account created for $cleanName " +
                        "($cleanEmail) as $role"
            )

            Result.success(uid)
        } catch (error: CancellationException) {
            throw error
        } catch (error: FirebaseAuthUserCollisionException) {
            Result.failure(
                IllegalStateException(
                    "That email already has an account.",
                    error
                )
            )
        } catch (error: Exception) {
            Result.failure(error)
        }
    }

    private suspend fun saveProfileOrCleanUp(
        createdUser: FirebaseUser,
        profile: AppUser
    ) {
        val confirmed = try {
            withTimeoutOrNull(
                PROFILE_WRITE_TIMEOUT_MS
            ) {
                users.document(createdUser.uid)
                    .set(profile)
                    .await()

                true
            } ?: false
        } catch (profileError: Exception) {
            val removed = try {
                withTimeoutOrNull(
                    CLEANUP_TIMEOUT_MS
                ) {
                    createdUser.delete().await()
                    true
                } ?: false
            } catch (cleanupError: Exception) {
                Log.e(
                    LOG_TAG,
                    "Account cleanup failed for UID ${createdUser.uid}.",
                    cleanupError
                )

                false
            }

            if (!removed) {
                throw IllegalStateException(
                    "The account could not be fully set up or removed. " +
                            "An administrator must check the Authentication " +
                            "account and users profile for ${profile.email} " +
                            "before retrying.",
                    profileError
                )
            }

            throw IllegalStateException(
                "The SafeSite profile could not be saved. " +
                        "The new login was removed. Check your connection " +
                        "and permissions before trying again.",
                profileError
            )
        }

        if (!confirmed) {
            Log.w(
                LOG_TAG,
                "Profile write confirmation timed out for UID " +
                        createdUser.uid
            )

            // A timed-out write may still complete later. Deleting the Auth
            // account here could leave a profile without its login.
            throw IllegalStateException(
                "The account setup could not be confirmed in time. " +
                        "The profile may still finish saving. " +
                        "An administrator must check the Authentication " +
                        "account and users profile for ${profile.email} " +
                        "before retrying."
            )
        }
    }

    suspend fun updateRole(
        userId: String,
        role: String
    ): Result<Unit> {
        return try {
            require(
                Role.values().any {
                    it.name == role
                }
            ) {
                "Choose a valid role."
            }

            val administratorId = requireAdministrator()

            require(userId.isNotBlank()) {
                "The account could not be identified."
            }

            require(userId != administratorId) {
                "You cannot change your own role here."
            }

            users.document(userId)
                .update("role", role)
                .await()

            AuditLogger.log(
                action = "USER_ROLE_CHANGED",
                entityType = "user",
                entityId = userId,
                summary = "${nameOf(userId)} role changed to $role"
            )

            Result.success(Unit)
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Result.failure(error)
        }
    }

    suspend fun setStatus(
        userId: String,
        status: String
    ): Result<Unit> {
        return try {
            require(
                status == "active" ||
                        status == "inactive"
            ) {
                "Choose a valid account status."
            }

            val administratorId = requireAdministrator()

            require(userId.isNotBlank()) {
                "The account could not be identified."
            }

            require(userId != administratorId) {
                "You cannot change your own account status here."
            }

            users.document(userId)
                .update("status", status)
                .await()

            AuditLogger.log(
                action = if (status == "active") {
                    "USER_ACTIVATED"
                } else {
                    "USER_DEACTIVATED"
                },
                entityType = "user",
                entityId = userId,
                summary = "${nameOf(userId)} set to $status"
            )

            Result.success(Unit)
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Result.failure(error)
        }
    }
}