package com.example.comaventrasafesite.auth

import com.example.comaventrasafesite.model.Role

internal object AccountAccess {

    fun requireRole(
        profileExists: Boolean,
        status: String?,
        roleName: String?
    ): Role {
        check(profileExists) {
            "This account has no SafeSite profile. Contact your administrator."
        }

        check(status == "active") {
            "This account is inactive. Contact your administrator."
        }

        return Role.values().firstOrNull {
            it.name == roleName
        } ?: throw IllegalStateException(
            "This account has an invalid role. Contact your administrator."
        )
    }
}