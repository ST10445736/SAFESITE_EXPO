package com.example.comaventrasafesite.model

enum class Role(val label: String) {
    WORKER("Worker / Subcontractor"),
    SUPERVISOR("Site Supervisor / Manager"),
    SAFETY_OFFICER("Safety Officer / Manager"),
    ADMIN("Company Administrator")
}
