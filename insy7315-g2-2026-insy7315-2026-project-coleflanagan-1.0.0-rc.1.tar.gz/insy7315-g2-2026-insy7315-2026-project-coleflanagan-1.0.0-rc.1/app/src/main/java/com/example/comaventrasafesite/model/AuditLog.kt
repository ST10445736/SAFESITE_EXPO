package com.example.comaventrasafesite.model

/**
 * One entry in the audit trail (FR18) — who did what, to what, and when.
 * Written automatically by AuditLogger; never edited or deleted by the app.
 */
data class AuditLog(
    val id: String = "",
    val action: String = "",       // e.g. HAZARD_REPORTED, USER_ROLE_CHANGED
    val entityType: String = "",   // hazard / incident / training / user / project / site / assignment
    val entityId: String = "",
    val summary: String = "",      // human-readable, e.g. "Hazard reported: Loose plank (HIGH)"
    val siteId: String = "",
    val byUserId: String = "",
    val byName: String = "",
    val at: Long = 0L
)