package com.example.comaventrasafesite.repository

import com.example.comaventrasafesite.model.ChecklistSubmission
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await
import java.util.Calendar
import java.util.TimeZone

class ChecklistRepository {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    private val checklistCollection =
        db.collection("checklist_submissions")

    val defaultQuestions = listOf(
        "Wearing correct PPE?",
        "Work area inspected for hazards?",
        "Tools and equipment checked?",
        "Emergency exits known?",
        "Briefed on today's task?"
    )

    suspend fun submitChecklist(
        siteId: String,
        workerId: String,
        answers: Map<String, Boolean>
    ): Result<String> {
        return try {
            require(siteId.isNotBlank()) {
                "An assigned site is required."
            }

            require(
                workerId.isNotBlank() &&
                        auth.currentUser?.uid == workerId
            ) {
                "Please sign in again."
            }

            val expectedQuestions = defaultQuestions.toSet()
            val savedAnswers = answers.toMap()

            require(
                savedAnswers.keys.all {
                    it in expectedQuestions
                }
            ) {
                "The checklist has changed. Reopen it before submitting."
            }

            val complete =
                savedAnswers.keys == expectedQuestions &&
                        expectedQuestions.all {
                            savedAnswers[it] == true
                        }

            val reference = checklistCollection.document()

            val submission = ChecklistSubmission(
                assignmentId = AssignedSiteAccess.requireAssignment(siteId, workerId),
                id = reference.id,
                siteId = siteId,
                workerId = workerId,
                answers = savedAnswers,
                submittedAt = System.currentTimeMillis(),
                status = if (complete) {
                    "complete"
                } else {
                    "incomplete"
                }
            )

            reference.set(submission).await()

            Result.success(reference.id)
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Result.failure(error)
        }
    }

    suspend fun getTodaysSubmissions(
        siteId: String
    ): List<ChecklistSubmission> {
        require(siteId.isNotBlank()) {
            "An assigned site is required."
        }

        val today = Calendar.getInstance(
            TimeZone.getTimeZone("Africa/Johannesburg")
        ).apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val startOfToday = today.timeInMillis

        val startOfTomorrow = (today.clone() as Calendar).apply {
            add(Calendar.DAY_OF_MONTH, 1)
        }.timeInMillis

        val snapshot = checklistCollection
            .whereEqualTo("siteId", siteId)
            .whereGreaterThanOrEqualTo(
                "submittedAt",
                startOfToday
            )
            .whereLessThan(
                "submittedAt",
                startOfTomorrow
            )
            .get(Source.SERVER)
            .await()

        return snapshot.documents.map { document ->
            val workerId = document
                .getString("workerId")
                .orEmpty()

            check(workerId.isNotBlank()) {
                "A checklist submission has no worker account. " +
                        "Contact your administrator."
            }

            val rawAnswers = document.get("answers")

            val answerMap = when (rawAnswers) {
                null -> emptyMap<Any?, Any?>()
                is Map<*, *> -> rawAnswers
                else -> error(
                    "A checklist submission has invalid answers. " +
                            "Contact your administrator."
                )
            }

            val answers = mutableMapOf<String, Boolean>()

            for ((question, answer) in answerMap) {
                if (question !is String || answer !is Boolean) {
                    error(
                        "A checklist submission has invalid answers. " +
                                "Contact your administrator."
                    )
                }

                answers[question] = answer
            }

            ChecklistSubmission(
                id = document.id,
                siteId = siteId,
                workerId = workerId,
                answers = answers,
                submittedAt = document.getLong("submittedAt") ?: 0L,
                status = document.getString("status")
                    ?: "incomplete"
            )
        }.sortedByDescending {
            it.submittedAt
        }
    }
}