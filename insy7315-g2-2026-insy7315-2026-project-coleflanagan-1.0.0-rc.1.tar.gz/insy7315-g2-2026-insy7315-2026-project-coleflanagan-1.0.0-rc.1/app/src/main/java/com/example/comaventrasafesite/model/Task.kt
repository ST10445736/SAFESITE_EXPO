package com.example.comaventrasafesite.model

data class Task(
    val id: String = "",
    val siteId: String = "",
    val assigneeId: String = "",
    val title: String = "",
    val description: String = "",
    val dueDate: Long = 0L,
    val status: String = "not_started", // "not_started", "in_progress", "completed", "blocked"
    val progressNote: String = "",
    val photoUrl: String = "",
    val createdAt: Long = 0L,
    val assignmentId: String = ""
)