package com.example.comaventrasafesite.ui.incident

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.Incident
import com.example.comaventrasafesite.repository.IncidentRepository
import com.example.comaventrasafesite.ui.hazard.formatDate
import com.example.comaventrasafesite.ui.shared.SafeSiteEmptyState
import com.example.comaventrasafesite.ui.shared.SafeSiteListTopBar
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import kotlinx.coroutines.launch

fun incidentSeverityColor(
    severity: String
): Color = when (severity.uppercase()) {
    "CRITICAL" -> Color(0xFFD32F2F)
    "MAJOR" -> Color(0xFFF57C00)
    "MODERATE" -> Color(0xFFFBC02D)
    else -> Color(0xFF388E3C)
}

private fun incidentSeverityContentColor(
    severity: String
): Color = when (severity.uppercase()) {
    "MODERATE" -> Color(0xFF3E3200)
    else -> Color.White
}

private fun incidentStatusColor(
    status: String
): Color = when (status) {
    IncidentRepository.REPORTED -> Color(0xFFF57C00)
    IncidentRepository.INVESTIGATING -> Color(0xFF1565C0)
    IncidentRepository.ACTIONS_PENDING -> Color(0xFF7B1FA2)
    IncidentRepository.CLOSED -> Color(0xFF388E3C)
    else -> Color.Gray
}

private val incidentStatusFilters = listOf(
    "all",
    IncidentRepository.REPORTED,
    IncidentRepository.INVESTIGATING,
    IncidentRepository.ACTIONS_PENDING,
    IncidentRepository.CLOSED
)

@Composable
fun IncidentRegisterScreen(
    siteId: String,
    onBack: () -> Unit,
    onReportNew: () -> Unit,
    onOpenIncident: (String) -> Unit
) {
    val repository = remember {
        IncidentRepository()
    }

    val loader = rememberScreenLoader()
    val scope = rememberCoroutineScope()

    var incidents by remember(siteId) {
        mutableStateOf<List<Incident>>(emptyList())
    }

    var filter by rememberSaveable(siteId) {
        mutableStateOf("all")
    }

    fun refresh() {
        scope.launch {
            loader.run {
                incidents = repository.getIncidentsForSite(siteId)
            }
        }
    }

    LaunchedEffect(siteId) {
        refresh()
    }

    val shownIncidents = remember(incidents, filter) {
        if (filter == "all") {
            incidents
        } else {
            incidents.filter {
                it.status == filter
            }
        }
    }

    val loadError = loader.errorMessage

    val subtitle = when {
        loader.isLoading -> "Loading incidents…"
        loadError != null -> "Unable to load incidents"
        else -> "${incidents.size} total incidents"
    }

    Scaffold(
        topBar = {
            SafeSiteListTopBar(
                title = "Incident Register",
                subtitle = subtitle,
                actionLabel = "Report",
                onBack = onBack,
                onCreate = onReportNew,
                onRefresh = {
                    refresh()
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when {
                loader.isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment =
                                Alignment.CenterHorizontally,
                            verticalArrangement =
                                Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator()

                            Text(
                                text = "Loading incidents…",
                                color =
                                    MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                loadError != null -> {
                    ScreenLoadError(
                        message = loadError,
                        onRetry = {
                            refresh()
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                else -> {
                    IncidentSummary(
                        incidents = incidents,
                        selectedFilter = filter,
                        onFilterSelected = {
                            filter = it
                        }
                    )

                    IncidentFilters(
                        selectedFilter = filter,
                        onFilterSelected = {
                            filter = it
                        }
                    )

                    if (shownIncidents.isEmpty()) {
                        SafeSiteEmptyState(
                            icon = Icons.Filled.Info,
                            title = if (filter == "all") {
                                "No incidents reported"
                            } else {
                                "No ${
                                    IncidentRepository.label(filter).lowercase()
                                } incidents"
                            },
                            description = if (filter == "all") {
                                "Use Report in the header to report a site incident."
                            } else {
                                "Try selecting a different status filter."
                            }
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(
                                start = 16.dp,
                                top = 14.dp,
                                end = 16.dp,
                                bottom = 24.dp
                            ),
                            verticalArrangement =
                                Arrangement.spacedBy(12.dp)
                        ) {
                            items(
                                items = shownIncidents,
                                key = { it.id }
                            ) { incident ->
                                IncidentCard(
                                    incident = incident,
                                    onClick = {
                                        onOpenIncident(incident.id)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun IncidentSummary(
    incidents: List<Incident>,
    selectedFilter: String,
    onFilterSelected: (String) -> Unit
) {
    val summaryItems = listOf(
        "Reported" to IncidentRepository.REPORTED,
        "Investigating" to IncidentRepository.INVESTIGATING,
        "Actions" to IncidentRepository.ACTIONS_PENDING,
        "Closed" to IncidentRepository.CLOSED
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(
                horizontal = 16.dp,
                vertical = 14.dp
            ),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        summaryItems.forEach { (label, status) ->
            ElevatedCard(
                onClick = {
                    onFilterSelected(status)
                },
                modifier = Modifier.width(108.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = if (selectedFilter == status) {
                        MaterialTheme.colorScheme.primaryContainer
                    } else {
                        MaterialTheme.colorScheme.surface
                    }
                ),
                elevation = CardDefaults.elevatedCardElevation(
                    defaultElevation = 1.dp
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(
                            horizontal = 8.dp,
                            vertical = 14.dp
                        ),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = incidents.count {
                            it.status == status
                        }.toString(),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = incidentStatusColor(status)
                    )

                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun IncidentFilters(
    selectedFilter: String,
    onFilterSelected: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        incidentStatusFilters.forEach { option ->
            FilterChip(
                selected = selectedFilter == option,
                onClick = {
                    onFilterSelected(option)
                },
                label = {
                    Text(
                        text = if (option == "all") {
                            "All"
                        } else {
                            IncidentRepository.label(option)
                        }
                    )
                }
            )
        }
    }
}

@Composable
private fun IncidentCard(
    incident: Incident,
    onClick: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                enabled = incident.id.isNotBlank(),
                onClick = onClick
            ),
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.elevatedCardElevation(
            defaultElevation = 1.dp
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = incident.title.ifBlank {
                            "Untitled incident"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Text(
                        text = incident.type.ifBlank {
                            "Uncategorised"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                }

                Surface(
                    color = incidentSeverityColor(incident.severity),
                    contentColor =
                        incidentSeverityContentColor(incident.severity),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = incident.severity.ifBlank {
                            "Not provided"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(
                            horizontal = 9.dp,
                            vertical = 5.dp
                        )
                    )
                }
            }

            if (incident.location.isNotBlank()) {
                Text(
                    text = "Location: ${incident.location}",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = incidentStatusColor(incident.status)
                        .copy(alpha = 0.12f),
                    contentColor = incidentStatusColor(incident.status),
                    shape = RoundedCornerShape(50)
                ) {
                    Text(
                        text = IncidentRepository.label(incident.status),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(
                            horizontal = 10.dp,
                            vertical = 5.dp
                        )
                    )
                }

                Text(
                    text = formatDate(incident.createdAt),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}