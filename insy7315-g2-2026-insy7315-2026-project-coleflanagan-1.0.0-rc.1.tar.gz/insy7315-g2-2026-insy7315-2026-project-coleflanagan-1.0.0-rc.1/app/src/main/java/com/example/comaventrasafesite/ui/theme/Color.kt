package com.example.comaventrasafesite.ui.theme

import androidx.compose.ui.graphics.Color

//primary brand colours
val SafeSiteOlive = Color(0xFF4A6741)
val SafeSiteOliveDark = Color(0xFF3A5232)
val SafeSiteOliveLight = Color(0xFF5E8052)
val SafeSiteOlivePale = Color(0xFFEFF3EE)
val SafeSiteOliveMid = Color(0xFFC8DCBF)

//navy colours
val SafeSiteNavy = Color(0xFF1C3557)
val SafeSiteNavyMedium = Color(0xFF2A4F7A)
val SafeSiteNavyLight = Color(0xFF3D6B96)
val SafeSiteBlueGrey = Color(0xFF607B96)

//warning colours
val SafeSiteOrange = Color(0xFFD97706)
val SafeSiteOrangeLight = Color(0xFFFEF3C7)
val SafeSiteOrangeDark = Color(0xFFB45309)

//success colours
val SafeSiteSuccess = Color(0xFF2D7A4F)
val SafeSiteSuccessLight = Color(0xFFEDFAF2)
val SafeSiteSuccessMid = Color(0xFFA7D9BE)

//danger colours
val SafeSiteDanger = Color(0xFFB91C1C)
val SafeSiteDangerLight = Color(0xFFFEF2F2)

//background and surface colours
val SafeSiteBackground = Color(0xFFF7F6F4)
val SafeSiteBackgroundAlt = Color(0xFFEDECEA)
val SafeSiteSurface = Color(0xFFFFFFFF)
val SafeSiteBorder = Color(0xFFE5E3DF)
val SafeSiteBorderSoft = Color(0xFFF0EEEB)

//text colours
val SafeSiteCharcoal = Color(0xFF1A2332)
val SafeSiteTextSecondary = Color(0xFF4A5568)
val SafeSiteTextMuted = Color(0xFF94A3B8)