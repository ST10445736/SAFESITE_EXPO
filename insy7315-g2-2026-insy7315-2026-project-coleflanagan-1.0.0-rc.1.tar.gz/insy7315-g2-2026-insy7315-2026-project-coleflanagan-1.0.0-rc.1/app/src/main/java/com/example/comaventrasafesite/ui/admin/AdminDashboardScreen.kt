package com.example.comaventrasafesite.ui.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth

@Composable
fun AdminDashboardScreen(
    onNavigate: (AdminDestination) -> Unit,
    onOpenPeople: () -> Unit,
    onOpenProjects: () -> Unit,
    onOpenReports: () -> Unit
) {
    val email = remember {
        FirebaseAuth.getInstance()
            .currentUser
            ?.email
            .orEmpty()
    }

    val firstName = email
        .substringBefore("@")
        .substringBefore(".")
        .replaceFirstChar {
            it.uppercase()
        }
        .ifBlank {
            "Administrator"
        }

    Scaffold(
        bottomBar = {
            AdminBottomBar(
                selectedDestination =
                    AdminDestination.DASHBOARD,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Surface(
                color =
                    MaterialTheme.colorScheme
                        .primary,
                contentColor =
                    MaterialTheme.colorScheme
                        .onPrimary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(
                        horizontal = 20.dp,
                        vertical = 24.dp
                    )
                ) {
                    Text(
                        text =
                            "Administrator Dashboard",
                        style =
                            MaterialTheme.typography
                                .headlineMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text =
                            "Welcome back, $firstName",
                        style =
                            MaterialTheme.typography
                                .bodyMedium,
                        color =
                            MaterialTheme.colorScheme
                                .onPrimary
                                .copy(alpha = 0.75f)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    20.dp
                ),
                verticalArrangement =
                    Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text =
                            "SYSTEM MANAGEMENT",
                        style =
                            MaterialTheme.typography
                                .labelMedium,
                        color =
                            MaterialTheme.colorScheme
                                .onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                }

                item {
                    AdminActionCard(
                        title = "People",
                        description =
                            "Create accounts, manage roles and control access",
                        icon = Icons.Filled.Person,
                        onClick = onOpenPeople
                    )
                }

                item {
                    AdminActionCard(
                        title = "Projects and sites",
                        description =
                            "Create projects, manage sites and assign workers",
                        icon = Icons.Filled.List,
                        onClick = onOpenProjects
                    )
                }

                item {
                    AdminActionCard(
                        title = "Audit and reports",
                        description =
                            "Review system activity and export audit history",
                        icon =
                            Icons.Filled.CheckCircle,
                        onClick = onOpenReports
                    )
                }

                item {
                    ElevatedCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp),
                        shape =
                            RoundedCornerShape(16.dp),
                        colors =
                            CardDefaults
                                .elevatedCardColors(
                                    containerColor =
                                        MaterialTheme
                                            .colorScheme
                                            .primaryContainer
                                )
                    ) {
                        Column(
                            modifier =
                                Modifier.padding(
                                    18.dp
                                )
                        ) {
                            Text(
                                text =
                                    "Administrative access",
                                style =
                                    MaterialTheme
                                        .typography
                                        .titleMedium,
                                fontWeight =
                                    FontWeight.Bold
                            )

                            Text(
                                text =
                                    "Changes to users, roles, projects and assignments affect access across SafeSite.",
                                style =
                                    MaterialTheme
                                        .typography
                                        .bodyMedium,
                                color =
                                    MaterialTheme
                                        .colorScheme
                                        .onSurfaceVariant,
                                modifier =
                                    Modifier.padding(
                                        top = 6.dp
                                    )
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminActionCard(
    title: String,
    description: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    ElevatedCard(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation =
            CardDefaults.elevatedCardElevation(
                defaultElevation = 1.dp
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalAlignment =
                Alignment.CenterVertically
        ) {
            Surface(
                color =
                    MaterialTheme.colorScheme
                        .primaryContainer,
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint =
                        MaterialTheme.colorScheme
                            .primary,
                    modifier = Modifier.padding(
                        12.dp
                    )
                )
            }

            Spacer(
                modifier = Modifier.width(14.dp)
            )

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = title,
                    style =
                        MaterialTheme.typography
                            .titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = description,
                    style =
                        MaterialTheme.typography
                            .bodyMedium,
                    color =
                        MaterialTheme.colorScheme
                            .onSurfaceVariant,
                    modifier = Modifier.padding(
                        top = 3.dp
                    )
                )
            }
        }
    }
}