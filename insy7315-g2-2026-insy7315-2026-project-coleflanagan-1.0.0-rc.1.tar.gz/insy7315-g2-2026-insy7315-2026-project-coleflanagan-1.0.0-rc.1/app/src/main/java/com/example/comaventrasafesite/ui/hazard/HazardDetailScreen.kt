package com.example.comaventrasafesite.ui.hazard

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.CorrectiveAction
import com.example.comaventrasafesite.model.Hazard
import com.example.comaventrasafesite.repository.HazardRepository
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

private const val HAZARD_DAY_MILLIS =
    24L * 60 * 60 * 1000

private val hazardDueOptions = listOf(
    1,
    3,
    7,
    14
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HazardDetailScreen(
    hazardId: String,
    onBack: () -> Unit
) {
    val repository = remember {
        HazardRepository()
    }

    val loader = rememberScreenLoader()
    val scope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    var hazard by remember(hazardId) {
        mutableStateOf<Hazard?>(null)
    }

    var actions by remember(hazardId) {
        mutableStateOf<List<CorrectiveAction>>(emptyList())
    }

    var canManage by remember(hazardId) {
        mutableStateOf(false)
    }

    var message by remember {
        mutableStateOf<String?>(null)
    }

    var isError by remember {
        mutableStateOf(false)
    }

    var actionText by rememberSaveable(hazardId) {
        mutableStateOf("")
    }

    var assignedTo by rememberSaveable(hazardId) {
        mutableStateOf("")
    }

    var dueInDays by rememberSaveable(hazardId) {
        mutableStateOf<Int?>(null)
    }

    var busyKey by remember {
        mutableStateOf<String?>(null)
    }

    var showCloseConfirmation by remember {
        mutableStateOf(false)
    }

    val isSaving = busyKey != null

    BackHandler(enabled = isSaving) {
        // Keep the current screen open while its save is in progress.
    }

    suspend fun reload() {
        loader.run {
            val loadedHazard = repository.getHazard(hazardId)

            val loadedActions = if (loadedHazard != null) {
                repository.getCorrectiveActions(hazardId)
            } else {
                emptyList()
            }

            val managementAllowed = repository.canManageHazards()

            hazard = loadedHazard
            actions = loadedActions
            canManage = managementAllowed
        }
    }

    fun runAction(
        key: String,
        successText: String,
        onSuccess: () -> Unit = {},
        action: suspend () -> Result<*>
    ) {
        if (isSaving || loader.isLoading) return

        busyKey = key
        message = null

        scope.launch {
            try {
                val result = action()

                result.onSuccess {
                    message = successText
                    isError = false
                    onSuccess()
                }.onFailure { error ->
                    message = error.message
                        ?: "The hazard could not be updated."
                    isError = true
                }

                reload()
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                message = error.message
                    ?: "The hazard could not be updated."
                isError = true
            } finally {
                busyKey = null
            }
        }
    }

    LaunchedEffect(hazardId) {
        reload()
    }

    if (showCloseConfirmation) {
        AlertDialog(
            onDismissRequest = {
                showCloseConfirmation = false
            },
            title = {
                Text("Close this hazard?")
            },
            text = {
                Text(
                    "Confirm that the hazard has been addressed. " +
                            "Every recorded corrective action must be completed."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showCloseConfirmation = false

                        runAction(
                            key = "close",
                            successText = "Hazard closed."
                        ) {
                            repository.closeHazard(hazardId)
                        }
                    }
                ) {
                    Text("Close hazard")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showCloseConfirmation = false
                    }
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Hazard Details",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        enabled = !isSaving
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            scope.launch {
                                reload()
                            }
                        },
                        enabled = !isSaving && !loader.isLoading
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Refresh hazard"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        val currentHazard = hazard
        val loadError = loader.errorMessage

        when {
            loader.isLoading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }

            loadError != null -> {
                ScreenLoadError(
                    message = loadError,
                    onRetry = {
                        scope.launch {
                            reload()
                        }
                    },
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                )
            }

            currentHazard == null -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Hazard not found",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "The record may have been removed.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Button(onClick = onBack) {
                            Text("Return")
                        }
                    }
                }
            }

            else -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .verticalScroll(scrollState)
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    HazardInformationCard(
                        hazard = currentHazard
                    )

                    message?.let { currentMessage ->
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            color = if (isError) {
                                MaterialTheme.colorScheme.errorContainer
                            } else {
                                Color(0xFF388E3C).copy(alpha = 0.12f)
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(
                                    start = 14.dp,
                                    top = 8.dp,
                                    end = 6.dp,
                                    bottom = 8.dp
                                ),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = currentMessage,
                                    color = if (isError) {
                                        MaterialTheme.colorScheme.onErrorContainer
                                    } else {
                                        Color(0xFF388E3C)
                                    },
                                    modifier = Modifier.weight(1f)
                                )

                                TextButton(
                                    onClick = {
                                        message = null
                                    }
                                ) {
                                    Text("Dismiss")
                                }
                            }
                        }
                    }

                    Text(
                        text = "Corrective actions (${actions.size})",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )

                    if (actions.isEmpty()) {
                        OutlinedCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text(
                                text = "No corrective actions recorded.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }

                    actions.forEach { action ->
                        CorrectiveActionCard(
                            action = action,
                            canComplete = canManage &&
                                    currentHazard.status != "closed" &&
                                    !isSaving,
                            isWorking = busyKey == action.id,
                            onComplete = {
                                runAction(
                                    key = action.id,
                                    successText = "Action marked done."
                                ) {
                                    repository.completeCorrectiveAction(
                                        action.id
                                    )
                                }
                            }
                        )
                    }

                    if (!canManage) {
                        Text(
                            text = "A Safety Officer or Administrator manages " +
                                    "corrective actions and hazard closure.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else if (
                        currentHazard.status == "open" ||
                        currentHazard.status == "in_progress"
                    ) {
                        HorizontalDivider()

                        ElevatedCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(18.dp),
                                verticalArrangement =
                                    Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "Add corrective action",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )

                                OutlinedTextField(
                                    value = actionText,
                                    onValueChange = {
                                        actionText = it
                                        message = null
                                    },
                                    label = {
                                        Text("What must be done?")
                                    },
                                    supportingText = {
                                        Text("${actionText.length}/5000")
                                    },
                                    isError = actionText.length > 5000,
                                    enabled = !isSaving,
                                    minLines = 2,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                OutlinedTextField(
                                    value = assignedTo,
                                    onValueChange = {
                                        assignedTo = it
                                        message = null
                                    },
                                    label = {
                                        Text("Assigned to (name)")
                                    },
                                    supportingText = {
                                        Text("Optional")
                                    },
                                    isError = assignedTo.length > 200,
                                    enabled = !isSaving,
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Text(
                                    text = "Due in",
                                    style = MaterialTheme.typography.labelLarge
                                )

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(
                                            rememberScrollState()
                                        ),
                                    horizontalArrangement =
                                        Arrangement.spacedBy(8.dp)
                                ) {
                                    hazardDueOptions.forEach { days ->
                                        FilterChip(
                                            selected = dueInDays == days,
                                            onClick = {
                                                dueInDays = days
                                                message = null
                                            },
                                            enabled = !isSaving,
                                            label = {
                                                Text(
                                                    text = if (days == 1) {
                                                        "1 day"
                                                    } else {
                                                        "$days days"
                                                    }
                                                )
                                            }
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        val days =
                                            dueInDays ?: return@Button

                                        val action = CorrectiveAction(
                                            hazardId = hazardId,
                                            description = actionText.trim(),
                                            assignedTo = assignedTo.trim(),
                                            dueDate =
                                                System.currentTimeMillis() +
                                                        days * HAZARD_DAY_MILLIS,
                                            createdBy =
                                                FirebaseAuth.getInstance()
                                                    .currentUser
                                                    ?.uid
                                                    .orEmpty()
                                        )

                                        runAction(
                                            key = "add",
                                            successText =
                                                "Corrective action added.",
                                            onSuccess = {
                                                actionText = ""
                                                assignedTo = ""
                                                dueInDays = null
                                            }
                                        ) {
                                            repository.addCorrectiveAction(
                                                action
                                            )
                                        }
                                    },
                                    enabled = !isSaving &&
                                            actionText.isNotBlank() &&
                                            actionText.length <= 5000 &&
                                            assignedTo.length <= 200 &&
                                            dueInDays != null,
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    if (busyKey == "add") {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(20.dp),
                                            strokeWidth = 2.dp,
                                            color =
                                                MaterialTheme.colorScheme.onPrimary
                                        )

                                        Spacer(
                                            modifier = Modifier.width(8.dp)
                                        )

                                        Text("Saving…")
                                    } else {
                                        Text("Add action")
                                    }
                                }
                            }
                        }

                        val unfinishedCount = actions.count {
                            it.status != "done"
                        }

                        Text(
                            text = if (unfinishedCount == 0) {
                                "There are no unfinished corrective actions."
                            } else {
                                "$unfinishedCount corrective " +
                                        "action${if (unfinishedCount == 1) "" else "s"} " +
                                        "must be completed before closure."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        OutlinedButton(
                            onClick = {
                                showCloseConfirmation = true
                            },
                            enabled = !isSaving &&
                                    unfinishedCount == 0,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            if (busyKey == "close") {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp
                                )

                                Spacer(
                                    modifier = Modifier.width(8.dp)
                                )

                                Text("Closing…")
                            } else {
                                Text("Close hazard")
                            }
                        }
                    } else if (
                        currentHazard.status == "closed" &&
                        actions.any { it.status != "done" }
                    ) {
                        Text(
                            text = "This closed hazard still has unfinished " +
                                    "actions. Contact your administrator " +
                                    "to correct the record.",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HazardInformationCard(
    hazard: Hazard
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                Text(
                    text = hazard.title.ifBlank {
                        "Untitled hazard"
                    },
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )

                Surface(
                    color = severityColor(hazard.severity),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = hazard.severity.ifBlank {
                            "Not provided"
                        },
                        color = if (
                            hazard.severity.uppercase() == "MEDIUM"
                        ) {
                            Color(0xFF3E3200)
                        } else {
                            Color.White
                        },
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(
                            horizontal = 9.dp,
                            vertical = 5.dp
                        )
                    )
                }
            }

            HorizontalDivider()

            HazardDetailRow(
                label = "Status",
                value = hazard.status
                    .replace("_", " ")
                    .replaceFirstChar {
                        it.uppercase()
                    }
                    .ifBlank {
                        "Unavailable"
                    }
            )

            HazardDetailRow(
                label = "Category",
                value = hazard.category.ifBlank {
                    "Uncategorised"
                }
            )

            HazardDetailRow(
                label = "Location",
                value = hazard.location.ifBlank {
                    "Not provided"
                }
            )

            HazardDetailRow(
                label = "Reported by",
                value = hazard.reporterName.ifBlank {
                    "Unknown"
                }
            )

            HazardDetailRow(
                label = "Reported",
                value = formatDate(hazard.createdAt)
            )

            hazard.closedAt?.let {
                HazardDetailRow(
                    label = "Closed",
                    value = formatDate(it)
                )
            }

            if (hazard.description.isNotBlank()) {
                HorizontalDivider()

                Text(
                    text = "Description",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text(
                    text = hazard.description,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
    }
}

@Composable
private fun CorrectiveActionCard(
    action: CorrectiveAction,
    canComplete: Boolean,
    isWorking: Boolean,
    onComplete: () -> Unit
) {
    val overdue = action.status == "pending" &&
            action.dueDate > 0L &&
            action.dueDate < System.currentTimeMillis()

    OutlinedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = action.description,
                style = MaterialTheme.typography.bodyLarge
            )

            Text(
                text = "Assigned to: ${
                    action.assignedTo.ifBlank { "Unassigned" }
                }",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Text(
                text = "Due: ${formatDate(action.dueDate)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            when (action.status) {
                "done" -> {
                    Text(
                        text = action.completedAt?.let {
                            "Completed ${formatDate(it)}"
                        } ?: "Completed",
                        color = Color(0xFF388E3C),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                "pending" -> {
                    Text(
                        text = if (overdue) {
                            "Overdue"
                        } else {
                            "Pending"
                        },
                        color = if (overdue) {
                            MaterialTheme.colorScheme.error
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        style = MaterialTheme.typography.bodySmall
                    )

                    if (canComplete || isWorking) {
                        TextButton(
                            onClick = onComplete,
                            enabled = canComplete && !isWorking
                        ) {
                            if (isWorking) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp
                                )

                                Spacer(
                                    modifier = Modifier.width(8.dp)
                                )

                                Text("Saving…")
                            } else {
                                Text("Mark done")
                            }
                        }
                    }
                }

                else -> {
                    Text(
                        text = "Action status unavailable. " +
                                "Contact your administrator.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}

@Composable
private fun HazardDetailRow(
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(0.38f)
        )

        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(0.62f)
        )
    }
}