package com.example.comaventrasafesite.model

/**
 * An incident on site (FR13–FR14). Moves through a fixed lifecycle:
 * reported -> investigating -> actions_pending -> closed
 */
data class Incident(
    val id: String = "",
    val siteId: String = "",
    val title: String = "",
    val description: String = "",
    val type: String = "Near miss",
    val severity: String = "MINOR",
    val location: String = "",
    val injuredPerson: String = "",
    val witnesses: String = "",
    val occurredAt: Long = 0L,
    val reportedBy: String = "",
    val reporterName: String = "",
    val status: String = "reported",
    val investigatorName: String = "",
    val rootCause: String = "",
    val findings: String = "",
    val actionsRequired: String = "",
    val closingNote: String = "",
    val createdAt: Long = 0L,
    val closedAt: Long? = null,
    val assignmentId: String = ""
)