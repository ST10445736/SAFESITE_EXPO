package com.example.comaventrasafesite.ui.profile

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.Role
import com.example.comaventrasafesite.model.SiteAssignment
import com.example.comaventrasafesite.repository.SiteAssignmentRepository
import com.example.comaventrasafesite.ui.privacy.PrivacyPolicyLink
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import com.example.comaventrasafesite.ui.worker.WorkerBottomBar
import com.example.comaventrasafesite.ui.worker.WorkerDestination
import com.example.comaventrasafesite.ui.worker.WorkerSiteHeader
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.tasks.await

private data class AssignmentDisplay(
    val assignment: SiteAssignment,
    val siteName: String,
    val projectName: String,
    val statusLabel: String,
    val active: Boolean
)

/*
 * These are individual document reads, not collection queries.
 * Parallel requests are limited to eight at a time.
 */
private suspend fun loadProfileReferences(
    db: FirebaseFirestore,
    collection: String,
    ids: List<String>
): Map<String, DocumentSnapshot> = coroutineScope {
    val documents = mutableMapOf<String, DocumentSnapshot>()

    ids.filter { it.isNotBlank() }
        .distinct()
        .chunked(8)
        .forEach { chunk ->
            val loaded = chunk.map { id ->
                async {
                    db.collection(collection)
                        .document(id)
                        .get(Source.SERVER)
                        .await()
                }
            }.map { it.await() }

            loaded.forEach { document ->
                documents[document.id] = document
            }
        }

    documents
}

@Composable
fun ProfileScreen(
    onNavigate: (WorkerDestination) -> Unit,
    onSignOut: () -> Unit
) {
    val db = remember { FirebaseFirestore.getInstance() }
    val auth = remember { FirebaseAuth.getInstance() }
    val repository = remember { SiteAssignmentRepository() }
    val loader = rememberScreenLoader()
    val context = LocalContext.current

    val uid = auth.currentUser?.uid

    var fullName by remember(uid) { mutableStateOf("") }
    var email by remember(uid) { mutableStateOf("") }
    var accountRole by remember(uid) { mutableStateOf("") }
    var assignments by remember(uid) {
        mutableStateOf<List<AssignmentDisplay>>(emptyList())
    }
    var refreshKey by remember { mutableIntStateOf(0) }

    val versionName = remember(context) {
        try {
            context.packageManager
                .getPackageInfo(context.packageName, 0)
                .versionName
                .orEmpty()
        } catch (_: Exception) {
            ""
        }
    }

    LaunchedEffect(uid, refreshKey) {
        loader.run {
            val userId = uid ?: error("Sign in to view your profile.")

            val profile = db.collection("users")
                .document(userId)
                .get(Source.SERVER)
                .await()

            check(
                profile.exists() &&
                        profile.getString("status") == "active"
            ) {
                "Your account is unavailable or inactive."
            }

            val role = profile.getString("role").orEmpty()
            check(Role.values().any { it.name == role }) {
                "Your account has an unrecognised role."
            }

            val history = repository.getMyAssignments(userId)

            val sites = loadProfileReferences(
                db = db,
                collection = "sites",
                ids = history.map { it.siteId }
            )

            val projects = loadProfileReferences(
                db = db,
                collection = "projects",
                ids = sites.values
                    .filter { it.exists() }
                    .mapNotNull { it.getString("projectId") }
            )

            val today = SiteAssignmentRepository.today()

            val displays = history.map { assignment ->
                val site = sites[assignment.siteId]
                val projectId = site?.getString("projectId").orEmpty()
                val project = projects[projectId]

                val ended = assignment.endDate.isNotBlank()
                val scheduled = assignment.startDate.isNotBlank() &&
                        assignment.startDate > today

                val siteExists = site?.exists() == true
                val siteActive = site?.getString("status") == "active"
                val projectExists = project?.exists() == true
                val projectActive =
                    project?.getString("status") == "active"

                val status = when {
                    ended -> "Ended ${assignment.endDate}"
                    scheduled -> "Scheduled from ${assignment.startDate}"
                    !siteExists -> "Assigned site no longer exists"
                    !siteActive -> "Assigned site is not active"
                    projectId.isNotBlank() && !projectExists ->
                        "Linked project no longer exists"
                    projectId.isNotBlank() && !projectActive ->
                        "Linked project is not active"
                    else -> "Current assignment"
                }

                AssignmentDisplay(
                    assignment = assignment,
                    siteName = site?.getString("name")
                        ?.takeIf { it.isNotBlank() }
                        ?: assignment.siteId,
                    projectName = project?.getString("name").orEmpty(),
                    statusLabel = status,
                    active = !ended &&
                            !scheduled &&
                            siteExists &&
                            siteActive &&
                            (
                                    projectId.isBlank() ||
                                            (projectExists && projectActive)
                                    )
                )
            }.sortedWith(
                compareByDescending<AssignmentDisplay> { it.active }
                    .thenBy { it.assignment.endDate.isNotBlank() }
                    .thenByDescending { it.assignment.startDate }
            )

            check(auth.currentUser?.uid == userId) {
                "Your session changed. Sign in again."
            }

            fullName = profile.getString("fullName").orEmpty()
            email = profile.getString("email")
                ?.takeIf { it.isNotBlank() }
                ?: auth.currentUser?.email.orEmpty()
            accountRole = role
            assignments = displays
        }
    }

    Scaffold(
        bottomBar = {
            WorkerBottomBar(
                selectedDestination = WorkerDestination.PROFILE,
                onNavigate = onNavigate
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            WorkerSiteHeader(
                title = "Profile",
                subtitle = when {
                    loader.isLoading -> "Loading your account…"
                    loader.errorMessage != null -> "Account details unavailable"
                    else -> fullName.ifBlank { email }
                },
                refreshEnabled = !loader.isLoading,
                onRefresh = { refreshKey++ }
            )

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when {
                    loader.isLoading -> {
                        CircularProgressIndicator(
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }

                    loader.errorMessage != null -> {
                        ScreenLoadError(
                            message = loader.errorMessage.orEmpty(),
                            onRetry = { refreshKey++ },
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    else -> {
                        LazyColumn(
                            contentPadding = PaddingValues(20.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            item {
                                ProfilePanel("Account") {
                                    ProfileField("Name", fullName)
                                    ProfileField("Email", email)
                                    ProfileField(
                                        "Role",
                                        Role.values()
                                            .firstOrNull {
                                                it.name == accountRole
                                            }?.label ?: accountRole
                                    )
                                }
                            }

                            item {
                                Text(
                                    "SITE ASSIGNMENTS",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (assignments.isEmpty()) {
                                item {
                                    Text(
                                        "No site assignments found. Contact your supervisor."
                                    )
                                }
                            }

                            items(
                                assignments,
                                key = { it.assignment.id }
                            ) { display ->
                                ProfilePanel(display.siteName) {
                                    if (display.projectName.isNotBlank()) {
                                        Text(display.projectName)
                                    }

                                    Text(
                                        "Start: ${
                                            display.assignment.startDate
                                                .ifBlank { "Not recorded" }
                                        }",
                                        style = MaterialTheme.typography.bodySmall
                                    )

                                    Text(
                                        display.statusLabel,
                                        color = if (display.active) {
                                            MaterialTheme.colorScheme.primary
                                        } else {
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                        },
                                        fontWeight = FontWeight.SemiBold,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Surface(
                modifier = Modifier.fillMaxWidth(),
                tonalElevation = 1.dp
            ) {
                Column(
                    modifier = Modifier.padding(
                        horizontal = 20.dp,
                        vertical = 10.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PrivacyPolicyLink()

                    OutlinedButton(
                        onClick = onSignOut,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("Sign out")
                    }

                    Text(
                        if (versionName.isBlank()) {
                            "SafeSite"
                        } else {
                            "SafeSite v$versionName"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun ProfilePanel(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                title,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
            content()
        }
    }
}

@Composable
private fun ProfileField(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(value.ifBlank { "Not recorded" })
    }
}