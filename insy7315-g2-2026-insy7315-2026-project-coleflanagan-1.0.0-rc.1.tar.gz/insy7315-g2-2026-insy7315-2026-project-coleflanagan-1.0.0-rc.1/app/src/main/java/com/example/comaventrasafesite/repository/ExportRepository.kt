package com.example.comaventrasafesite.repository

import com.example.comaventrasafesite.model.AuditLog
import com.example.comaventrasafesite.model.Hazard
import com.example.comaventrasafesite.model.Incident
import com.example.comaventrasafesite.model.TrainingRecord
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.Source
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import com.example.comaventrasafesite.util.CsvExport

class ExportRepository {

    private val db = FirebaseFirestore.getInstance()

    private fun date(millis: Long?): String {
        if (millis == null || millis <= 0L) return ""

        return SimpleDateFormat(
            "yyyy-MM-dd HH:mm",
            Locale.US
        ).apply {
            timeZone = TimeZone.getTimeZone("Africa/Johannesburg")
        }.format(Date(millis))
    }

    suspend fun getAuditLogs(limit: Long = 1000): List<AuditLog> {
        require(limit in 1L..1000L) {
            "The audit limit must be between 1 and 1,000."
        }

        val snapshot = db.collection("auditLogs")
            .orderBy("at", Query.Direction.DESCENDING)
            .limit(limit)
            .get(Source.SERVER)
            .await()

        return snapshot.documents.map { document ->
            val log = document.toObject(AuditLog::class.java)
                ?: error("An audit entry could not be read.")

            log.copy(id = document.id)
        }
    }

    private fun toCsv(
        header: List<String>,
        rows: List<List<String>>
    ): String = CsvExport.document(header, rows)

    fun auditCsv(logs: List<AuditLog>): String = toCsv(
        header = listOf(
            "Date (SAST)",
            "Action",
            "Type",
            "Summary",
            "By",
            "Site ID",
            "Entity ID"
        ),
        rows = logs.map {
            listOf(
                date(it.at),
                it.action,
                it.entityType,
                it.summary,
                it.byName,
                it.siteId,
                it.entityId
            )
        }
    )

    suspend fun hazardsCsv(): String {
        val snapshot = db.collection("hazards")
            .get(Source.SERVER)
            .await()

        val hazards = snapshot.documents.map { document ->
            document.toObject(Hazard::class.java)
                ?: error("A hazard record could not be read.")
        }.sortedByDescending { it.createdAt }

        return withContext(Dispatchers.Default) {
            toCsv(
                header = listOf(
                    "Reported (SAST)",
                    "Title",
                    "Category",
                    "Severity",
                    "Location",
                    "Status",
                    "Reported by",
                    "Closed (SAST)",
                    "Description",
                    "Site ID"
                ),
                rows = hazards.map {
                    listOf(
                        date(it.createdAt),
                        it.title,
                        it.category,
                        it.severity,
                        it.location,
                        it.status,
                        it.reporterName,
                        date(it.closedAt),
                        it.description,
                        it.siteId
                    )
                }
            )
        }
    }

    suspend fun incidentsCsv(): String {
        val snapshot = db.collection("incidents")
            .get(Source.SERVER)
            .await()

        val incidents = snapshot.documents.map { document ->
            document.toObject(Incident::class.java)
                ?: error("An incident record could not be read.")
        }.sortedByDescending { it.createdAt }

        return withContext(Dispatchers.Default) {
            toCsv(
                header = listOf(
                    "Occurred (SAST)",
                    "Reported (SAST)",
                    "Title",
                    "Type",
                    "Severity",
                    "Status",
                    "Location",
                    "Injured",
                    "Witnesses",
                    "Reported by",
                    "Investigator",
                    "Root cause",
                    "Findings",
                    "Actions required",
                    "Closing note",
                    "Closed (SAST)",
                    "Site ID"
                ),
                rows = incidents.map {
                    listOf(
                        date(it.occurredAt),
                        date(it.createdAt),
                        it.title,
                        it.type,
                        it.severity,
                        IncidentRepository.label(it.status),
                        it.location,
                        it.injuredPerson,
                        it.witnesses,
                        it.reporterName,
                        it.investigatorName,
                        it.rootCause,
                        it.findings,
                        it.actionsRequired,
                        it.closingNote,
                        date(it.closedAt),
                        it.siteId
                    )
                }
            )
        }
    }

    suspend fun trainingCsv(): String {
        val snapshot = db.collection("trainingRecords")
            .get(Source.SERVER)
            .await()

        val records = snapshot.documents.map { document ->
            document.toObject(TrainingRecord::class.java)
                ?: error("A training record could not be read.")
        }.sortedBy { it.workerName.lowercase(Locale.ROOT) }

        return withContext(Dispatchers.Default) {
            toCsv(
                header = listOf(
                    "Worker",
                    "Course",
                    "Provider",
                    "Certificate #",
                    "Completed (SAST)",
                    "Expires (SAST)",
                    "Status",
                    "Site ID"
                ),
                rows = records.map {
                    listOf(
                        it.workerName,
                        it.courseName,
                        it.provider,
                        it.certificateNumber,
                        date(it.completedAt),
                        date(it.expiresAt).ifBlank { "Never" },
                        TrainingRepository.label(
                            TrainingRepository.statusOf(it)
                        ),
                        it.siteId
                    )
                }
            )
        }
    }
}