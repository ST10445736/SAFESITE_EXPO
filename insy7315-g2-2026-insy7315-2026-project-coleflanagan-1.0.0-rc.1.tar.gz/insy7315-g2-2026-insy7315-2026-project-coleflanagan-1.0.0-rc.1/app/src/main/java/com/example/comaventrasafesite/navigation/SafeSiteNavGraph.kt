package com.example.comaventrasafesite.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.comaventrasafesite.auth.AuthManager
import com.example.comaventrasafesite.model.Role
import com.example.comaventrasafesite.ui.admin.AddPersonScreen
import com.example.comaventrasafesite.ui.admin.AdminDashboardScreen
import com.example.comaventrasafesite.ui.admin.AdminDestination
import com.example.comaventrasafesite.ui.admin.AdminMoreScreen
import com.example.comaventrasafesite.ui.admin.AdminScreenFrame
import com.example.comaventrasafesite.ui.admin.AuditScreen
import com.example.comaventrasafesite.ui.admin.PeopleScreen
import com.example.comaventrasafesite.ui.admin.ProjectDetailScreen
import com.example.comaventrasafesite.ui.admin.ProjectsScreen
import com.example.comaventrasafesite.ui.admin.SiteDetailScreen
import com.example.comaventrasafesite.ui.checkin.CheckInScreen
import com.example.comaventrasafesite.ui.checklist.ChecklistReviewScreen
import com.example.comaventrasafesite.ui.checklist.ChecklistScreen
import com.example.comaventrasafesite.ui.dashboard.SafetyDashboardScreen
import com.example.comaventrasafesite.ui.hazard.HazardDetailScreen
import com.example.comaventrasafesite.ui.hazard.HazardRegisterScreen
import com.example.comaventrasafesite.ui.hazard.ReportHazardScreen
import com.example.comaventrasafesite.ui.headcount.HeadcountScreen
import com.example.comaventrasafesite.ui.incident.IncidentDetailScreen
import com.example.comaventrasafesite.ui.incident.IncidentRegisterScreen
import com.example.comaventrasafesite.ui.incident.ReportIncidentScreen
import com.example.comaventrasafesite.ui.ppe.PpeApprovalScreen
import com.example.comaventrasafesite.ui.ppe.PpeUploadScreen
import com.example.comaventrasafesite.ui.profile.ProfileScreen
import com.example.comaventrasafesite.ui.safetyofficer.SafetyOfficerDestination
import com.example.comaventrasafesite.ui.safetyofficer.SafetyOfficerMoreScreen
import com.example.comaventrasafesite.ui.safetyofficer.SafetyOfficerSiteGate
import com.example.comaventrasafesite.ui.shared.PlaceholderScreen
import com.example.comaventrasafesite.ui.signin.SignInScreen
import com.example.comaventrasafesite.ui.supervisor.SupervisorDashboardScreen
import com.example.comaventrasafesite.ui.supervisor.SupervisorDestination
import com.example.comaventrasafesite.ui.supervisor.SupervisorMoreScreen
import com.example.comaventrasafesite.ui.supervisor.SupervisorSiteGate
import com.example.comaventrasafesite.ui.supervisor.SupervisorWorkersScreen
import com.example.comaventrasafesite.ui.tasks.MyTasksScreen
import com.example.comaventrasafesite.ui.tasks.TaskBoardScreen
import com.example.comaventrasafesite.ui.training.AddTrainingScreen
import com.example.comaventrasafesite.ui.training.TrainingRegisterScreen
import com.example.comaventrasafesite.ui.welcome.WelcomeScreen
import com.example.comaventrasafesite.ui.worker.WorkerAlertsScreen
import com.example.comaventrasafesite.ui.worker.WorkerDashboardScreen
import com.example.comaventrasafesite.ui.worker.WorkerDestination
import com.example.comaventrasafesite.ui.worker.WorkerSafetyScreen

private object Routes {
    const val WELCOME = "welcome"
    const val SIGN_IN = "sign_in"
    const val ROLE_HUB = "role_hub/{roleName}"
    const val AREA = "area/{roleName}/{areaName}"
    const val HAZARD_REPORT = "hazard_report/{siteId}"
    const val HAZARD_DETAIL = "hazard_detail/{hazardId}"
    const val INCIDENT_REPORT = "incident_report/{siteId}"
    const val INCIDENT_DETAIL = "incident_detail/{incidentId}"
    const val TRAINING_ADD = "training_add/{siteId}"
    const val ADMIN_ADD_PERSON = "admin_add_person"
    const val PROJECT_DETAIL = "project_detail/{projectId}"
    const val SITE_DETAIL = "site_detail/{siteId}"
    const val WORKER_CHECK_IN = "worker_check_in/{siteId}"
    const val WORKER_CHECKLIST = "worker_checklist/{siteId}"
    const val WORKER_PPE = "worker_ppe/{siteId}"
    const val SUPERVISOR_HEADCOUNT = "supervisor_headcount"
    const val SUPERVISOR_PPE_REVIEW = "supervisor_ppe_review"

    fun roleHub(role: Role) = "role_hub/${role.name}"

    fun area(role: Role, areaName: String) =
        "area/${role.name}/$areaName"

    fun hazardReport(siteId: String) = "hazard_report/$siteId"
    fun hazardDetail(hazardId: String) = "hazard_detail/$hazardId"
    fun incidentReport(siteId: String) = "incident_report/$siteId"
    fun incidentDetail(incidentId: String) = "incident_detail/$incidentId"
    fun trainingAdd(siteId: String) = "training_add/$siteId"
    fun projectDetail(projectId: String) = "project_detail/$projectId"
    fun siteDetail(siteId: String) = "site_detail/$siteId"
    fun workerCheckIn(siteId: String) = "worker_check_in/$siteId"
    fun workerChecklist(siteId: String) = "worker_checklist/$siteId"
    fun workerPpe(siteId: String) = "worker_ppe/$siteId"
}

@Composable
fun SafeSiteNavGraph(
    navController: NavHostController = rememberNavController()
) {
    val authManager = AuthManager()

    fun signOut() {
        authManager.signOut()

        navController.navigate(Routes.SIGN_IN) {
            popUpTo(0) {
                inclusive = true
            }
            launchSingleTop = true
        }
    }

    fun navigateWorker(destination: WorkerDestination) {
        val route = when (destination) {
            WorkerDestination.HOME -> Routes.roleHub(Role.WORKER)
            WorkerDestination.TASKS -> Routes.area(Role.WORKER, "Tasks")
            WorkerDestination.SAFETY -> Routes.area(Role.WORKER, "Safety")
            WorkerDestination.ALERTS -> Routes.area(Role.WORKER, "Alerts")
            WorkerDestination.PROFILE -> Routes.area(Role.WORKER, "Profile")
        }

        navController.navigate(route) {
            launchSingleTop = true
            popUpTo(Routes.ROLE_HUB) {
                inclusive = false
            }
        }
    }

    fun navigateSupervisor(destination: SupervisorDestination) {
        val route = when (destination) {
            SupervisorDestination.DASHBOARD ->
                Routes.roleHub(Role.SUPERVISOR)

            SupervisorDestination.WORKERS ->
                Routes.area(Role.SUPERVISOR, "Workers")

            SupervisorDestination.TASKS ->
                Routes.area(Role.SUPERVISOR, "Tasks")

            SupervisorDestination.SAFETY ->
                Routes.area(Role.SUPERVISOR, "Safety")

            SupervisorDestination.MORE ->
                Routes.area(Role.SUPERVISOR, "More")
        }

        navController.navigate(route) {
            launchSingleTop = true
            popUpTo(Routes.ROLE_HUB) {
                inclusive = false
            }
        }
    }

    fun navigateSafetyOfficer(destination: SafetyOfficerDestination) {
        val route = when (destination) {
            SafetyOfficerDestination.DASHBOARD ->
                Routes.roleHub(Role.SAFETY_OFFICER)

            SafetyOfficerDestination.HAZARDS ->
                Routes.area(Role.SAFETY_OFFICER, "Hazards")

            SafetyOfficerDestination.INCIDENTS ->
                Routes.area(Role.SAFETY_OFFICER, "Incidents")

            SafetyOfficerDestination.TRAINING ->
                Routes.area(Role.SAFETY_OFFICER, "Training")

            SafetyOfficerDestination.MORE ->
                Routes.area(Role.SAFETY_OFFICER, "More")
        }

        navController.navigate(route) {
            launchSingleTop = true
            popUpTo(Routes.roleHub(Role.SAFETY_OFFICER)) {
                inclusive = false
            }
        }
    }

    fun navigateAdmin(destination: AdminDestination) {
        val route = when (destination) {
            AdminDestination.DASHBOARD -> Routes.roleHub(Role.ADMIN)
            AdminDestination.PEOPLE -> Routes.area(Role.ADMIN, "People")
            AdminDestination.PROJECTS -> Routes.area(Role.ADMIN, "Projects")
            AdminDestination.REPORTS -> Routes.area(Role.ADMIN, "Reports")
            AdminDestination.MORE -> Routes.area(Role.ADMIN, "More")
        }

        navController.navigate(route) {
            launchSingleTop = true
            popUpTo(Routes.roleHub(Role.ADMIN)) {
                inclusive = false
            }
        }
    }

    NavHost(
        navController = navController,
        startDestination = Routes.WELCOME
    ) {
        composable(Routes.WELCOME) {
            WelcomeScreen(
                onGetStarted = {
                    navController.navigate(Routes.SIGN_IN) {
                        popUpTo(Routes.WELCOME) {
                            inclusive = true
                        }
                        launchSingleTop = true
                    }
                }
            )
        }

        composable(Routes.SIGN_IN) {
            SignInScreen(
                onSignInSuccess = { role ->
                    navController.navigate(Routes.roleHub(role)) {
                        popUpTo(Routes.SIGN_IN) {
                            inclusive = true
                        }
                        launchSingleTop = true
                    }
                }
            )
        }

        composable(
            route = Routes.ROLE_HUB,
            arguments = listOf(
                navArgument("roleName") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val roleName = backStackEntry.arguments
                ?.getString("roleName") ?: Role.WORKER.name

            val role = Role.valueOf(roleName)

            when (role) {
                Role.WORKER -> {
                    WorkerDashboardScreen(
                        onNavigate = ::navigateWorker,
                        onOpenCheckIn = { siteId ->
                            navController.navigate(Routes.workerCheckIn(siteId))
                        },
                        onOpenTasks = {
                            navigateWorker(WorkerDestination.TASKS)
                        },
                        onOpenSafety = {
                            navigateWorker(WorkerDestination.SAFETY)
                        },
                        onOpenPpe = { siteId ->
                            navController.navigate(Routes.workerPpe(siteId))
                        },
                        onOpenAlerts = {
                            navigateWorker(WorkerDestination.ALERTS)
                        },
                        onOpenProfile = {
                            navigateWorker(WorkerDestination.PROFILE)
                        },
                        onReportHazard = { siteId ->
                            navController.navigate(Routes.hazardReport(siteId))
                        },
                        onReportIncident = { siteId ->
                            navController.navigate(Routes.incidentReport(siteId))
                        }
                    )
                }

                Role.SUPERVISOR -> {
                    SupervisorDashboardScreen(
                        onNavigate = ::navigateSupervisor,
                        onOpenHeadcount = {
                            navController.navigate(Routes.SUPERVISOR_HEADCOUNT)
                        },
                        onOpenPpeReview = {
                            navController.navigate(Routes.SUPERVISOR_PPE_REVIEW)
                        },
                        onOpenTasks = {
                            navigateSupervisor(SupervisorDestination.TASKS)
                        },
                        onOpenSafety = {
                            navigateSupervisor(SupervisorDestination.SAFETY)
                        }
                    )
                }

                Role.SAFETY_OFFICER -> {
                    SafetyOfficerSiteGate(
                        selectedDestination = SafetyOfficerDestination.DASHBOARD,
                        onNavigate = ::navigateSafetyOfficer
                    ) { site ->
                        SafetyDashboardScreen(
                            siteId = site.siteId,
                            siteName = site.siteName,
                            onBack = {
                                navController.popBackStack()
                            },
                            onOpenHazards = {
                                navigateSafetyOfficer(
                                    SafetyOfficerDestination.HAZARDS
                                )
                            },
                            onOpenIncidents = {
                                navigateSafetyOfficer(
                                    SafetyOfficerDestination.INCIDENTS
                                )
                            },
                            onOpenTraining = {
                                navigateSafetyOfficer(
                                    SafetyOfficerDestination.TRAINING
                                )
                            }
                        )
                    }
                }

                Role.ADMIN -> {
                    AdminDashboardScreen(
                        onNavigate = ::navigateAdmin,
                        onOpenPeople = {
                            navigateAdmin(AdminDestination.PEOPLE)
                        },
                        onOpenProjects = {
                            navigateAdmin(AdminDestination.PROJECTS)
                        },
                        onOpenReports = {
                            navigateAdmin(AdminDestination.REPORTS)
                        }
                    )
                }
            }
        }

        composable(
            route = Routes.AREA,
            arguments = listOf(
                navArgument("roleName") {
                    type = NavType.StringType
                },
                navArgument("areaName") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val roleName = backStackEntry.arguments
                ?.getString("roleName") ?: Role.WORKER.name

            val areaName = backStackEntry.arguments
                ?.getString("areaName").orEmpty()

            val role = Role.valueOf(roleName)

            when {
                role == Role.WORKER && areaName == "Tasks" -> {
                    MyTasksScreen(
                        onNavigate = ::navigateWorker
                    )
                }

                role == Role.WORKER && areaName == "Safety" -> {
                    WorkerSafetyScreen(
                        onNavigate = ::navigateWorker,
                        onOpenChecklist = { siteId ->
                            navController.navigate(Routes.workerChecklist(siteId))
                        },
                        onOpenPpe = { siteId ->
                            navController.navigate(Routes.workerPpe(siteId))
                        },
                        onReportHazard = { siteId ->
                            navController.navigate(Routes.hazardReport(siteId))
                        },
                        onReportIncident = { siteId ->
                            navController.navigate(Routes.incidentReport(siteId))
                        }
                    )
                }

                role == Role.WORKER && areaName == "Alerts" -> {
                    WorkerAlertsScreen(
                        onNavigate = ::navigateWorker
                    )
                }

                role == Role.WORKER && areaName == "Profile" -> {
                    ProfileScreen(
                        onNavigate = ::navigateWorker,
                        onSignOut = ::signOut
                    )
                }

                role == Role.SUPERVISOR && areaName == "Workers" -> {
                    SupervisorWorkersScreen(
                        onNavigate = ::navigateSupervisor,
                        onOpenHeadcount = {
                            navController.navigate(Routes.SUPERVISOR_HEADCOUNT)
                        },
                        onOpenPpeReview = {
                            navController.navigate(Routes.SUPERVISOR_PPE_REVIEW)
                        }
                    )
                }

                role == Role.SUPERVISOR && areaName == "Tasks" -> {
                    SupervisorSiteGate(
                        selectedDestination = SupervisorDestination.TASKS,
                        onNavigate = ::navigateSupervisor
                    ) { site ->
                        TaskBoardScreen(
                            siteId = site.siteId,
                            onNavigate = ::navigateSupervisor
                        )
                    }
                }

                role == Role.SUPERVISOR && areaName == "Safety" -> {
                    SupervisorSiteGate(
                        selectedDestination = SupervisorDestination.SAFETY,
                        onNavigate = ::navigateSupervisor
                    ) { site ->
                        ChecklistReviewScreen(
                            siteId = site.siteId,
                            onNavigate = ::navigateSupervisor
                        )
                    }
                }

                role == Role.SUPERVISOR && areaName == "More" -> {
                    SupervisorMoreScreen(
                        onNavigate = ::navigateSupervisor,
                        onSignOut = ::signOut
                    )
                }

                role == Role.SAFETY_OFFICER && areaName == "Hazards" -> {
                    SafetyOfficerSiteGate(
                        selectedDestination = SafetyOfficerDestination.HAZARDS,
                        onNavigate = ::navigateSafetyOfficer
                    ) { site ->
                        HazardRegisterScreen(
                            siteId = site.siteId,
                            onBack = {
                                navController.popBackStack()
                            },
                            onReportNew = {
                                navController.navigate(
                                    Routes.hazardReport(site.siteId)
                                )
                            },
                            onOpenHazard = { hazardId ->
                                navController.navigate(
                                    Routes.hazardDetail(hazardId)
                                )
                            }
                        )
                    }
                }

                role == Role.SAFETY_OFFICER && areaName == "Incidents" -> {
                    SafetyOfficerSiteGate(
                        selectedDestination = SafetyOfficerDestination.INCIDENTS,
                        onNavigate = ::navigateSafetyOfficer
                    ) { site ->
                        IncidentRegisterScreen(
                            siteId = site.siteId,
                            onBack = {
                                navController.popBackStack()
                            },
                            onReportNew = {
                                navController.navigate(
                                    Routes.incidentReport(site.siteId)
                                )
                            },
                            onOpenIncident = { incidentId ->
                                navController.navigate(
                                    Routes.incidentDetail(incidentId)
                                )
                            }
                        )
                    }
                }

                role == Role.SAFETY_OFFICER && areaName == "Training" -> {
                    SafetyOfficerSiteGate(
                        selectedDestination = SafetyOfficerDestination.TRAINING,
                        onNavigate = ::navigateSafetyOfficer
                    ) { site ->
                        TrainingRegisterScreen(
                            siteId = site.siteId,
                            onBack = {
                                navController.popBackStack()
                            },
                            onAddNew = {
                                navController.navigate(
                                    Routes.trainingAdd(site.siteId)
                                )
                            }
                        )
                    }
                }

                role == Role.SAFETY_OFFICER && areaName == "More" -> {
                    SafetyOfficerMoreScreen(
                        onNavigate = ::navigateSafetyOfficer,
                        onSignOut = ::signOut
                    )
                }

                role == Role.ADMIN && areaName == "People" -> {
                    AdminScreenFrame(
                        selectedDestination = AdminDestination.PEOPLE,
                        onNavigate = ::navigateAdmin
                    ) {
                        PeopleScreen(
                            onBack = {
                                navController.popBackStack()
                            },
                            onAddPerson = {
                                navController.navigate(Routes.ADMIN_ADD_PERSON)
                            }
                        )
                    }
                }

                role == Role.ADMIN && areaName == "Projects" -> {
                    AdminScreenFrame(
                        selectedDestination = AdminDestination.PROJECTS,
                        onNavigate = ::navigateAdmin
                    ) {
                        ProjectsScreen(
                            onBack = {
                                navController.popBackStack()
                            },
                            onOpenProject = { projectId ->
                                navController.navigate(
                                    Routes.projectDetail(projectId)
                                )
                            },
                            onOpenSite = { siteId ->
                                navController.navigate(Routes.siteDetail(siteId))
                            }
                        )
                    }
                }

                role == Role.ADMIN && areaName == "Reports" -> {
                    AdminScreenFrame(
                        selectedDestination = AdminDestination.REPORTS,
                        onNavigate = ::navigateAdmin
                    ) {
                        AuditScreen(
                            onBack = {
                                navController.popBackStack()
                            }
                        )
                    }
                }

                role == Role.ADMIN && areaName == "More" -> {
                    AdminMoreScreen(
                        onNavigate = ::navigateAdmin,
                        onSignOut = ::signOut
                    )
                }

                else -> {
                    PlaceholderScreen(
                        title = areaName,
                        subtitle = "${role.label} screen",
                        actions = emptyList(),
                        onBack = {
                            navController.popBackStack()
                        }
                    )
                }
            }
        }

        composable(Routes.SUPERVISOR_HEADCOUNT) {
            SupervisorSiteGate(
                selectedDestination = SupervisorDestination.WORKERS,
                onNavigate = ::navigateSupervisor
            ) { site ->
                HeadcountScreen(
                    siteId = site.siteId,
                    siteName = site.siteName,
                    onBack = {
                        navController.popBackStack()
                    }
                )
            }
        }

        composable(Routes.SUPERVISOR_PPE_REVIEW) {
            SupervisorSiteGate(
                selectedDestination = SupervisorDestination.WORKERS,
                onNavigate = ::navigateSupervisor
            ) { site ->
                PpeApprovalScreen(
                    siteId = site.siteId,
                    onNavigate = ::navigateSupervisor
                )
            }
        }

        composable(
            route = Routes.HAZARD_REPORT,
            arguments = listOf(
                navArgument("siteId") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val siteId = backStackEntry.arguments
                ?.getString("siteId").orEmpty()

            ReportHazardScreen(
                siteId = siteId,
                onBack = {
                    navController.popBackStack()
                },
                onSubmitted = {
                    navController.popBackStack()
                }
            )
        }

        composable(
            route = Routes.HAZARD_DETAIL,
            arguments = listOf(
                navArgument("hazardId") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val hazardId = backStackEntry.arguments
                ?.getString("hazardId").orEmpty()

            HazardDetailScreen(
                hazardId = hazardId,
                onBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(
            route = Routes.INCIDENT_REPORT,
            arguments = listOf(
                navArgument("siteId") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val siteId = backStackEntry.arguments
                ?.getString("siteId").orEmpty()

            ReportIncidentScreen(
                siteId = siteId,
                onBack = {
                    navController.popBackStack()
                },
                onSubmitted = {
                    navController.popBackStack()
                }
            )
        }

        composable(
            route = Routes.INCIDENT_DETAIL,
            arguments = listOf(
                navArgument("incidentId") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val incidentId = backStackEntry.arguments
                ?.getString("incidentId").orEmpty()

            IncidentDetailScreen(
                incidentId = incidentId,
                onBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(
            route = Routes.TRAINING_ADD,
            arguments = listOf(
                navArgument("siteId") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val siteId = backStackEntry.arguments
                ?.getString("siteId").orEmpty()

            AddTrainingScreen(
                siteId = siteId,
                onBack = {
                    navController.popBackStack()
                },
                onSaved = {
                    navController.popBackStack()
                }
            )
        }

        composable(Routes.ADMIN_ADD_PERSON) {
            AddPersonScreen(
                onBack = {
                    navController.popBackStack()
                },
                onSaved = {
                    navController.popBackStack()
                }
            )
        }

        composable(
            route = Routes.PROJECT_DETAIL,
            arguments = listOf(
                navArgument("projectId") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val projectId = backStackEntry.arguments
                ?.getString("projectId").orEmpty()

            ProjectDetailScreen(
                projectId = projectId,
                onBack = {
                    navController.popBackStack()
                },
                onOpenSite = { siteId ->
                    navController.navigate(Routes.siteDetail(siteId))
                }
            )
        }

        composable(
            route = Routes.SITE_DETAIL,
            arguments = listOf(
                navArgument("siteId") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val siteId = backStackEntry.arguments
                ?.getString("siteId").orEmpty()

            SiteDetailScreen(
                siteId = siteId,
                onBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(
            route = Routes.WORKER_CHECK_IN,
            arguments = listOf(
                navArgument("siteId") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val siteId = backStackEntry.arguments
                ?.getString("siteId").orEmpty()

            CheckInScreen(
                siteId = siteId,
                siteName = "Current assigned site",
                onBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(
            route = Routes.WORKER_CHECKLIST,
            arguments = listOf(
                navArgument("siteId") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val siteId = backStackEntry.arguments
                ?.getString("siteId").orEmpty()

            ChecklistScreen(
                siteId = siteId,
                onBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(
            route = Routes.WORKER_PPE,
            arguments = listOf(
                navArgument("siteId") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val siteId = backStackEntry.arguments
                ?.getString("siteId").orEmpty()

            PpeUploadScreen(
                siteId = siteId,
                onBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}