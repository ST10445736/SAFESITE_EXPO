package com.example.comaventrasafesite.ui.privacy

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

object SafeSitePrivacy {
    // Fill these with the organisation's confirmed details before submission.
    const val CONTACT_EMAIL = "info@aventra.co.za"
    const val SECONDARY_CONTACT_EMAIL = "sales@colsec.co"
    const val PUBLIC_POLICY_URL = ""
}

@Composable
fun PrivacyPolicyLink(
    modifier: Modifier = Modifier
) {
    var open by rememberSaveable {
        mutableStateOf(false)
    }

    TextButton(
        onClick = { open = true },
        modifier = modifier
    ) {
        Text("Privacy policy")
    }

    if (open) {
        Dialog(
            onDismissRequest = { open = false },
            properties = DialogProperties(
                usePlatformDefaultWidth = false
            )
        ) {
            PrivacyPolicyScreen(
                onBack = { open = false }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyPolicyScreen(
    onBack: () -> Unit
) {
    val uriHandler = LocalUriHandler.current

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Privacy policy",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor =
                        MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Text(
                text = "SafeSite",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )

            PolicySection(
                title = "Information used by SafeSite",
                body = """
                    SafeSite processes account details, assigned roles and sites,
                    attendance records, safety checklists, task updates and photos,
                    PPE photos, hazard and incident reports, training records,
                    and records of administrative actions.

                    Incident reports may include information about injuries,
                    witnesses and other people involved. Include only information
                    needed for the site safety record.
                """.trimIndent()
            )

            PolicySection(
                title = "Why information is used",
                body = """
                    Information is used to provide account access, manage site
                    work and attendance, review safety submissions, record training,
                    investigate incidents, and maintain safety and administrative
                    records.
                """.trimIndent()
            )

            PolicySection(
                title = "Photos and artificial intelligence",
                body = """
                    When you submit a PPE photo, SafeSite sends the photo to
                    Google's Gemini service through Firebase AI Logic for an
                    automated PPE pre-screen.

                    The AI result is advisory. It does not confirm that a person
                    or site is safe. A supervisor makes the final approval or
                    rejection decision.

                    Messages you send to SafeAI are also processed by Google's
                    Gemini service. Do not include passwords or unnecessary
                    personal or sensitive information in chat messages.
                """.trimIndent()
            )

            PolicySection(
                title = "Storage and access",
                body = """
                    SafeSite uses Google Firebase services for authentication and
                    storage of application records. Photos submitted through the
                    app are stored with the relevant application records.

                    Access is intended to be restricted according to account role
                    and site responsibilities. Your organisation's authorised
                    administrators and safety personnel manage these records.
                """.trimIndent()
            )

            PolicySection(
                title = "Retention and privacy requests",
                body = """
                    Your organisation determines how long site and safety records
                    need to be retained, including any applicable record-keeping
                    obligations.

                    Contact your organisation's SafeSite administrator with
                    questions about your information or to request access,
                    correction or deletion. Deactivating an account does not
                    itself delete its historical records.
                """.trimIndent()
            )

            if (SafeSitePrivacy.CONTACT_EMAIL.isNotBlank()) {
                PolicySection(
                    title = "Privacy contact",
                    body = "Aventra\nPrimary: ${SafeSitePrivacy.CONTACT_EMAIL}\nSecondary: ${SafeSitePrivacy.SECONDARY_CONTACT_EMAIL}"
                )
            }

            if (
                SafeSitePrivacy.PUBLIC_POLICY_URL.startsWith(
                    "https://"
                )
            ) {
                Button(
                    onClick = {
                        uriHandler.openUri(
                            SafeSitePrivacy.PUBLIC_POLICY_URL
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Open published privacy policy")
                }
            }

            Text(
                text = """
                    Google services also operate under their applicable privacy
                    terms and service terms.
                """.trimIndent(),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            TextButton(
                onClick = {
                    uriHandler.openUri(
                        "https://policies.google.com/privacy"
                    )
                }
            ) {
                Text("Google privacy policy")
            }
        }
    }
}

@Composable
private fun PolicySection(
    title: String,
    body: String
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}