package com.example.comaventrasafesite.ui.safetyofficer

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.repository.SafetyOfficerSessionRepository
import com.example.comaventrasafesite.repository.SafetyOfficerSiteContext
import com.google.firebase.auth.FirebaseAuth

private sealed interface SafetyOfficerSiteState {
    data object Loading : SafetyOfficerSiteState

    data class Ready(
        val site: SafetyOfficerSiteContext
    ) : SafetyOfficerSiteState

    data object NoAssignment : SafetyOfficerSiteState

    data class Error(
        val message: String
    ) : SafetyOfficerSiteState
}

@Composable
fun SafetyOfficerSiteGate(
    selectedDestination: SafetyOfficerDestination,
    onNavigate: (SafetyOfficerDestination) -> Unit,
    content: @Composable (SafetyOfficerSiteContext) -> Unit
) {
    val repository = remember {
        SafetyOfficerSessionRepository()
    }

    val userId = remember {
        FirebaseAuth.getInstance().currentUser?.uid.orEmpty()
    }

    var refreshKey by remember {
        mutableIntStateOf(0)
    }

    var state by remember {
        mutableStateOf<SafetyOfficerSiteState>(
            SafetyOfficerSiteState.Loading
        )
    }

    LaunchedEffect(userId, refreshKey) {
        state = SafetyOfficerSiteState.Loading

        if (userId.isBlank()) {
            state = SafetyOfficerSiteState.Error(
                message = "Your signed-in account could not be found."
            )
            return@LaunchedEffect
        }

        state = runCatching {
            repository.getActiveSite(userId)
        }.fold(
            onSuccess = { site ->
                if (site == null) {
                    SafetyOfficerSiteState.NoAssignment
                } else {
                    SafetyOfficerSiteState.Ready(site)
                }
            },
            onFailure = { error ->
                SafetyOfficerSiteState.Error(
                    message = error.message
                        ?: "The assigned site could not be loaded."
                )
            }
        )
    }

    when (val currentState = state) {
        SafetyOfficerSiteState.Loading -> {
            GateScaffold(
                selectedDestination = selectedDestination,
                onNavigate = onNavigate
            ) {
                CircularProgressIndicator()

                Text(
                    text = "Loading assigned site…",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }

        SafetyOfficerSiteState.NoAssignment -> {
            GateScaffold(
                selectedDestination = selectedDestination,
                onNavigate = onNavigate
            ) {
                Icon(
                    imageVector = Icons.Filled.Warning,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )

                Text(
                    text = "No site assigned",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "An administrator must assign your account to an active site before you can access safety records.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                Button(
                    onClick = {
                        refreshKey++
                    }
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = null
                    )

                    Text(
                        text = "Try again",
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
            }
        }

        is SafetyOfficerSiteState.Error -> {
            GateScaffold(
                selectedDestination = selectedDestination,
                onNavigate = onNavigate
            ) {
                Icon(
                    imageVector = Icons.Filled.Warning,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error
                )

                Text(
                    text = "Unable to load site",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = currentState.message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                Button(
                    onClick = {
                        refreshKey++
                    }
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = null
                    )

                    Text(
                        text = "Retry",
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
            }
        }

        is SafetyOfficerSiteState.Ready -> {
            Scaffold(
                bottomBar = {
                    SafetyOfficerBottomBar(
                        selectedDestination = selectedDestination,
                        onNavigate = onNavigate
                    )
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    content(currentState.site)
                }
            }
        }
    }
}

@Composable
private fun GateScaffold(
    selectedDestination: SafetyOfficerDestination,
    onNavigate: (SafetyOfficerDestination) -> Unit,
    content: @Composable () -> Unit
) {
    Scaffold(
        bottomBar = {
            SafetyOfficerBottomBar(
                selectedDestination = selectedDestination,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                content()
            }
        }
    }
}