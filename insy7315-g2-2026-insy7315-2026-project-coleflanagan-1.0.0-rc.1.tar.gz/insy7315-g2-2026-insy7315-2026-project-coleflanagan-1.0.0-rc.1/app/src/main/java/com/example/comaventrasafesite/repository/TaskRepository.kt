package com.example.comaventrasafesite.repository

import android.content.Context
import android.net.Uri
import com.example.comaventrasafesite.model.AppUser
import com.example.comaventrasafesite.model.Task
import com.example.comaventrasafesite.util.FirestorePhoto
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldPath
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await

class TaskRepository {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val taskCollection = db.collection("tasks")

    suspend fun createTask(
        siteId: String,
        assigneeId: String,
        title: String,
        description: String,
        dueDate: Long
    ): Result<String> {
        return try {
            check(auth.currentUser != null) {
                "Please sign in again."
            }

            require(siteId.isNotBlank()) {
                "A site must be selected."
            }

            require(assigneeId.isNotBlank()) {
                "A worker must be selected."
            }

            require(title.isNotBlank()) {
                "Enter a task title."
            }

            require(title.trim().length <= 160) {
                "Keep the task title under 160 characters."
            }

            require(description.length <= 5000) {
                "Keep the description under 5,000 characters."
            }

            require(dueDate >= System.currentTimeMillis()) {
                "Choose a due date that has not passed."
            }

            val newDocument = taskCollection.document()

            val task = Task(
                assignmentId = AssignedSiteAccess.requireAssignment(siteId, assigneeId),
                id = newDocument.id,
                siteId = siteId,
                assigneeId = assigneeId,
                title = title.trim(),
                description = description.trim(),
                dueDate = dueDate,
                status = "not_started",
                createdAt = System.currentTimeMillis()
            )

            newDocument.set(task).await()

            Result.success(newDocument.id)
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Result.failure(error)
        }
    }

    suspend fun getMyTasks(
        workerId: String
    ): List<Task> {
        require(
            workerId.isNotBlank() &&
                    auth.currentUser?.uid == workerId
        ) {
            "Please sign in again."
        }

        val snapshot = taskCollection
            .whereEqualTo("assigneeId", workerId)
            .get(Source.SERVER)
            .await()

        return snapshot.documents.mapNotNull { document ->
            document.toObject(Task::class.java)
                ?.copy(id = document.id)
        }
    }

    suspend fun getSiteTasks(
        siteId: String
    ): List<Task> {
        require(siteId.isNotBlank()) {
            "An assigned site is required."
        }

        check(auth.currentUser != null) {
            "Please sign in again."
        }

        val snapshot = taskCollection
            .whereEqualTo("siteId", siteId)
            .get(Source.SERVER)
            .await()

        return snapshot.documents.mapNotNull { document ->
            document.toObject(Task::class.java)
                ?.copy(id = document.id)
        }
    }

    suspend fun getAssignableWorkers(
        siteId: String
    ): List<AppUser> {
        require(siteId.isNotBlank()) {
            "An assigned site is required."
        }

        check(auth.currentUser != null) {
            "Please sign in again."
        }

        val assignments = db.collection("site_assignments")
            .whereEqualTo("siteId", siteId)
            .get(Source.SERVER)
            .await()

        val today = ProjectRepository.today()

        val workerIds = assignments.documents
            .filter { document ->
                val endDate = document
                    .getString("endDate")
                    .orEmpty()

                val startDate = document
                    .getString("startDate")
                    .orEmpty()

                endDate.isBlank() &&
                        (
                                startDate.isBlank() ||
                                        startDate <= today
                                )
            }
            .mapNotNull { document ->
                document.getString("workerId")
                    ?.takeIf { it.isNotBlank() }
            }
            .distinct()

        if (workerIds.isEmpty()) {
            return emptyList()
        }

        val workers = mutableListOf<AppUser>()

        for (chunk in workerIds.chunked(30)) {
            val snapshot = db.collection("users")
                .whereIn(
                    FieldPath.documentId(),
                    chunk
                )
                .get(Source.SERVER)
                .await()

            workers += snapshot.documents.mapNotNull { document ->
                document.toObject(AppUser::class.java)
                    ?.copy(id = document.id)
            }
        }

        return workers
            .filter { user ->
                user.role == "WORKER" &&
                        user.status == "active"
            }
            .sortedBy {
                it.fullName.lowercase()
            }
    }

    suspend fun updateTaskProgress(
        taskId: String,
        status: String,
        progressNote: String,
        photoUri: Uri?,
        context: Context? = null
    ): Result<Unit> {
        return try {
            val workerId = auth.currentUser?.uid
                ?: error("Please sign in again.")

            require(taskId.isNotBlank()) {
                "The task could not be identified."
            }

            require(
                status in setOf(
                    "not_started",
                    "in_progress",
                    "completed",
                    "blocked"
                )
            ) {
                "Select a valid task status."
            }

            require(progressNote.length <= 5000) {
                "Keep the progress note under 5,000 characters."
            }

            val updates = mutableMapOf<String, Any>(
                "status" to status,
                "progressNote" to progressNote.trim()
            )

            if (photoUri != null) {
                val appContext = requireNotNull(context) {
                    "The photo could not be opened. Please try again."
                }.applicationContext

                updates["photoUrl"] = FirestorePhoto.encode(
                    context = appContext,
                    uri = photoUri
                )
            }

            val reference = taskCollection.document(taskId)

            db.runTransaction { transaction ->
                check(auth.currentUser?.uid == workerId) {
                    "Your signed-in account has changed. " +
                            "Please sign in again."
                }

                val document = transaction.get(reference)

                check(document.exists()) {
                    "This task no longer exists."
                }

                check(
                    document.getString("assigneeId") == workerId
                ) {
                    "This task is no longer assigned to your account."
                }

                transaction.update(
                    reference,
                    updates
                )

                Unit
            }.await()

            Result.success(Unit)
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Result.failure(error)
        }
    }
}