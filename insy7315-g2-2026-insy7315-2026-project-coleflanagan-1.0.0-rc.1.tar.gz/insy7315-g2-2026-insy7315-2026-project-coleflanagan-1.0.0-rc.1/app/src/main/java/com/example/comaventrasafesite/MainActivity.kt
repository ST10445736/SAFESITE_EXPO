package com.example.comaventrasafesite

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.comaventrasafesite.auth.AccountSessionObserver
import com.example.comaventrasafesite.navigation.SafeSiteNavGraph
import com.example.comaventrasafesite.ui.safeai.SafeAiHost
import com.example.comaventrasafesite.ui.theme.ComaventrasafesiteTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            ComaventrasafesiteTheme {
                val navController = rememberNavController()

                val backStackEntry by
                navController.currentBackStackEntryAsState()

                val currentRoute =
                    backStackEntry?.destination?.route

                val showAssistantButton = currentRoute in setOf(
                    "welcome",
                    "sign_in",
                    "role_hub/{roleName}"
                )

                AccountSessionObserver(
                    navController = navController
                )

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SafeAiHost(
                        showButton = showAssistantButton
                    ) {
                        SafeSiteNavGraph(
                            navController = navController
                        )
                    }
                }
            }
        }
    }
}