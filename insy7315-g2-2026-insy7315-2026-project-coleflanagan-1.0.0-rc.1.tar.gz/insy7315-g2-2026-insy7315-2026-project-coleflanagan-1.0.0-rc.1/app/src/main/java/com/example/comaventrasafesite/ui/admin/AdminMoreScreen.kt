package com.example.comaventrasafesite.ui.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.ui.privacy.PrivacyPolicyLink

@Composable
fun AdminMoreScreen(
    onNavigate: (AdminDestination) -> Unit,
    onSignOut: () -> Unit
) {
    Scaffold(
        bottomBar = {
            AdminBottomBar(
                selectedDestination =
                    AdminDestination.MORE,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Surface(
                color =
                    MaterialTheme.colorScheme
                        .primary,
                contentColor =
                    MaterialTheme.colorScheme
                        .onPrimary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(
                        horizontal = 20.dp,
                        vertical = 24.dp
                    )
                ) {
                    Text(
                        text = "More",
                        style =
                            MaterialTheme.typography
                                .headlineMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text =
                            "Account and application options",
                        style =
                            MaterialTheme.typography
                                .bodyMedium,
                        color =
                            MaterialTheme.colorScheme
                                .onPrimary
                                .copy(alpha = 0.75f)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding =
                    PaddingValues(20.dp),
                verticalArrangement =
                    Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = "ACCOUNT",
                        style =
                            MaterialTheme.typography
                                .labelMedium,
                        color =
                            MaterialTheme.colorScheme
                                .onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                }

                item {
                    ElevatedCard(
                        modifier =
                            Modifier.fillMaxWidth(),
                        shape =
                            RoundedCornerShape(16.dp),
                        elevation =
                            CardDefaults
                                .elevatedCardElevation(
                                    defaultElevation =
                                        1.dp
                                )
                    ) {
                        ListItem(
                            headlineContent = {
                                Text(
                                    "Company Administrator"
                                )
                            },
                            supportingContent = {
                                Text(
                                    "Manage SafeSite users, projects, sites, assignments and audit records."
                                )
                            },
                            leadingContent = {
                                Icon(
                                    imageVector =
                                        Icons.Filled.Info,
                                    contentDescription =
                                        null,
                                    tint =
                                        MaterialTheme
                                            .colorScheme
                                            .primary
                                )
                            }
                        )
                    }
                }

                item {
                    PrivacyPolicyLink()
                }

                item {
                    ElevatedCard(
                        onClick = onSignOut,
                        modifier =
                            Modifier.fillMaxWidth(),
                        shape =
                            RoundedCornerShape(16.dp),
                        elevation =
                            CardDefaults
                                .elevatedCardElevation(
                                    defaultElevation =
                                        1.dp
                                )
                    ) {
                        ListItem(
                            headlineContent = {
                                Text(
                                    text = "Sign out",
                                    color =
                                        MaterialTheme
                                            .colorScheme
                                            .error
                                )
                            },
                            supportingContent = {
                                Text(
                                    "Return to role selection"
                                )
                            },
                            leadingContent = {
                                Icon(
                                    imageVector =
                                        Icons.Filled
                                            .ExitToApp,
                                    contentDescription =
                                        null,
                                    tint =
                                        MaterialTheme
                                            .colorScheme
                                            .error
                                )
                            }
                        )
                    }
                }
            }
        }
    }
}