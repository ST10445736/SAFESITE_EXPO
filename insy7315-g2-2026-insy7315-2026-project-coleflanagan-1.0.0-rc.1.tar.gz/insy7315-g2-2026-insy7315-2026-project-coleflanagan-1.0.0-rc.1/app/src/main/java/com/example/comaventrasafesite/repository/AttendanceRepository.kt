package com.example.comaventrasafesite.repository

import com.example.comaventrasafesite.model.Attendance
import com.example.comaventrasafesite.model.Role
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldPath
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class AttendanceRepository {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val attendanceCollection = db.collection("attendance")

    companion object {
        // Local serialisation complements the server-validated attendance lock.
        private val attendanceMutex = Mutex()
    }

    suspend fun checkIn(
        siteId: String,
        workerId: String
    ): Result<String> {
        return try {
            val attendanceId = attendanceMutex.withLock {
                requireCurrentWorker(workerId)

                require(siteId.isNotBlank()) {
                    "An assigned site is required."
                }

                check(getOpenAttendance(workerId) == null) {
                    "You already have an open check-in. " +
                            "Refresh and check out before checking in again."
                }

                val assignmentId = validateCheckIn(
                    siteId = siteId,
                    workerId = workerId
                )

                requireCurrentWorker(workerId)

                val reference = attendanceCollection.document()

                val attendance = Attendance(
                    id = reference.id,
                    siteId = siteId,
                    workerId = workerId,
                    checkIn = System.currentTimeMillis(),
                    checkOut = null,
                    status = "checked_in",
                    assignmentId = assignmentId
                )

                val lock = db.collection("attendance_locks").document(workerId)
                val migration = db.collection("security_migrations")
                    .document("attendance_v1")

                db.runTransaction { transaction ->
                    requireCurrentWorker(workerId)
                    val setup = transaction.get(migration)
                    val currentLock = transaction.get(lock)

                    check(setup.getBoolean("ready") == true) {
                        "Attendance protection is being prepared. Please try again shortly."
                    }
                    check(
                        !currentLock.exists() ||
                            currentLock.getString("attendanceId") == ""
                    ) {
                        "You already have an open check-in. Refresh before continuing."
                    }

                    transaction.set(reference, attendance)
                    transaction.set(lock, mapOf(
                        "workerId" to workerId,
                        "attendanceId" to reference.id,
                        "siteId" to siteId
                    ))
                    Unit
                }.await()

                reference.id
            }

            Result.success(attendanceId)
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Result.failure(error)
        }
    }

    suspend fun checkOut(
        attendanceId: String
    ): Result<Unit> {
        return try {
            require(attendanceId.isNotBlank()) {
                "The attendance record could not be identified."
            }

            attendanceMutex.withLock {
                val workerId = auth.currentUser?.uid
                    ?: error("Please sign in again.")

                val reference = attendanceCollection
                    .document(attendanceId)

                val checkedOutAt = System.currentTimeMillis()

                db.runTransaction { transaction ->
                    check(auth.currentUser?.uid == workerId) {
                        "Your signed-in account has changed. " +
                                "Please sign in again."
                    }

                    val document = transaction.get(reference)

                    check(document.exists()) {
                        "This attendance record no longer exists."
                    }

                    check(
                        document.getString("workerId") == workerId
                    ) {
                        "This attendance record belongs to another account."
                    }

                    val status = document.getString("status")

                    if (status == "checked_out") {
                        return@runTransaction Unit
                    }

                    check(status == "checked_in") {
                        "This attendance record has an unexpected status. " +
                                "Contact your administrator."
                    }

                    val lock = db.collection("attendance_locks").document(workerId)
                    val currentLock = transaction.get(lock)
                    check(currentLock.getString("attendanceId") == attendanceId) {
                        "The attendance lock needs reconciliation. Contact your administrator."
                    }

                    transaction.update(
                        reference,
                        mapOf(
                            "checkOut" to checkedOutAt,
                            "status" to "checked_out"
                        )
                    )

                    transaction.set(lock, mapOf(
                        "workerId" to workerId,
                        "attendanceId" to "",
                        "siteId" to ""
                    ))
                    Unit
                }.await()
            }

            Result.success(Unit)
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Result.failure(error)
        }
    }

    suspend fun getOpenAttendance(
        workerId: String
    ): Attendance? {
        requireCurrentWorker(workerId)

        val snapshot = attendanceCollection
            .whereEqualTo("workerId", workerId)
            .whereEqualTo("status", "checked_in")
            .get(Source.SERVER)
            .await()

        check(snapshot.documents.size <= 1) {
            "Multiple open attendance records were found for this account. " +
                    "An administrator must reconcile them."
        }

        return snapshot.documents
            .firstOrNull()
            ?.let {
                decodeAttendance(it)
            }
    }

    suspend fun getSiteHeadcount(
        siteId: String
    ): List<Attendance> {
        require(siteId.isNotBlank()) {
            "An assigned site is required."
        }

        val snapshot = attendanceCollection
            .whereEqualTo("siteId", siteId)
            .whereEqualTo("status", "checked_in")
            .get(Source.SERVER)
            .await()

        val attendance = snapshot.documents.map {
            decodeAttendance(it)
        }

        check(
            attendance.map { it.workerId }.distinct().size ==
                    attendance.size
        ) {
            "Some workers have duplicate open attendance records. " +
                    "An administrator must reconcile them before " +
                    "the headcount can be confirmed."
        }

        return attendance.sortedBy {
            it.checkIn ?: 0L
        }
    }

    suspend fun getWorkerNames(
        workerIds: List<String>
    ): Map<String, String> {
        val uniqueIds = workerIds
            .filter { it.isNotBlank() }
            .distinct()

        if (uniqueIds.isEmpty()) {
            return emptyMap()
        }

        val names = mutableMapOf<String, String>()

        for (chunk in uniqueIds.chunked(30)) {
            val snapshot = db.collection("users")
                .whereIn(
                    FieldPath.documentId(),
                    chunk
                )
                .get(Source.SERVER)
                .await()

            snapshot.documents.forEach { document ->
                names[document.id] = document
                    .getString("fullName")
                    ?.takeIf { it.isNotBlank() }
                    ?: document.getString("email")
                        ?.takeIf { it.isNotBlank() }
                            ?: "Worker"
            }
        }

        return names
    }

    suspend fun getSiteName(
        siteId: String
    ): String? {
        require(siteId.isNotBlank()) {
            "The site could not be identified."
        }

        return db.collection("sites")
            .document(siteId)
            .get(Source.SERVER)
            .await()
            .getString("name")
            ?.takeIf { it.isNotBlank() }
    }

    private fun requireCurrentWorker(
        workerId: String
    ) {
        require(
            workerId.isNotBlank() &&
                    auth.currentUser?.uid == workerId
        ) {
            "Please sign in again."
        }
    }

    private suspend fun validateCheckIn(
        siteId: String,
        workerId: String
    ): String {
        val profile = db.collection("users")
            .document(workerId)
            .get(Source.SERVER)
            .await()

        check(
            profile.exists() &&
                    profile.getString("role") == Role.WORKER.name &&
                    profile.getString("status") == "active"
        ) {
            "An active Worker account is required to check in."
        }

        val site = db.collection("sites")
            .document(siteId)
            .get(Source.SERVER)
            .await()

        check(
            site.exists() &&
                    site.getString("status") == "active"
        ) {
            "This site is unavailable or inactive."
        }

        val projectId = site.getString("projectId").orEmpty()

        if (projectId.isNotBlank()) {
            val project = db.collection("projects")
                .document(projectId)
                .get(Source.SERVER)
                .await()

            check(
                project.exists() &&
                        project.getString("status") == "active"
            ) {
                "This site's project is unavailable or inactive."
            }
        }

        val today = SimpleDateFormat(
            "yyyy-MM-dd",
            Locale.US
        ).apply {
            timeZone = TimeZone.getTimeZone(
                "Africa/Johannesburg"
            )
        }.format(Date())

        val assignments = db.collection("site_assignments")
            .whereEqualTo("workerId", workerId)
            .get(Source.SERVER)
            .await()

        val assigned = assignments.documents.firstOrNull { document ->
            val startDate = document
                .getString("startDate")
                .orEmpty()

            document.getString("siteId") == siteId &&
                    document.getString("endDate").orEmpty().isBlank() &&
                    (
                            startDate.isBlank() ||
                                    startDate <= today
                            )
        }

        check(assigned != null) {
            "You are no longer assigned to this site. Contact your administrator."
        }
        return assigned.id
    }

    private fun decodeAttendance(
        document: DocumentSnapshot
    ): Attendance {
        val record = document.toObject(Attendance::class.java)
            ?: error("An attendance record could not be read.")

        check(
            record.workerId.isNotBlank() &&
                    record.siteId.isNotBlank()
        ) {
            "An attendance record is incomplete. " +
                    "Contact your administrator."
        }

        check(
            record.status != "checked_in" ||
                    record.checkOut == null
        ) {
            "An attendance record has conflicting check-in information. " +
                    "Contact your administrator."
        }

        return record.copy(
            id = document.id
        )
    }
}