package com.example.comaventrasafesite.model

data class Site(
    val id: String = "",
    val projectId: String = "",
    val name: String = "",
    val address: String = "",
    val status: String = "active"
)