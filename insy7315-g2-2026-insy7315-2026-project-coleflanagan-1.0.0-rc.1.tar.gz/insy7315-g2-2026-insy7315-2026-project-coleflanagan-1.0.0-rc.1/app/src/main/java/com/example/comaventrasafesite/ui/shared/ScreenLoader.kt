package com.example.comaventrasafesite.ui.shared

import android.util.Log
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withTimeoutOrNull

class ScreenLoader {

    var isLoading by mutableStateOf(true)
        private set

    var errorMessage by mutableStateOf<String?>(null)
        private set

    private val mutex = Mutex()

    suspend fun run(
        action: suspend () -> Unit
    ) {
        if (!mutex.tryLock()) return

        isLoading = true
        errorMessage = null

        try {
            val completed = withTimeoutOrNull(30_000L) {
                action()
                true
            } ?: false

            if (!completed) {
                errorMessage =
                    "The request took too long. Check your connection " +
                            "and try again."
            }
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Log.e(
                "SafeSiteLoad",
                "Screen information could not be loaded.",
                error
            )

            errorMessage = when {
                error is FirebaseFirestoreException &&
                        error.code ==
                        FirebaseFirestoreException.Code.PERMISSION_DENIED -> {
                    "Your account cannot access this information. " +
                            "Sign in again or contact your administrator."
                }

                error is FirebaseFirestoreException &&
                        error.code ==
                        FirebaseFirestoreException.Code.UNAVAILABLE -> {
                    "SafeSite could not connect. Check your internet " +
                            "connection and try again."
                }

                else -> {
                    "The information could not be loaded. Try again. " +
                            "If the problem continues, contact your administrator."
                }
            }
        } finally {
            isLoading = false
            mutex.unlock()
        }
    }
}

@Composable
fun rememberScreenLoader(): ScreenLoader {
    return remember {
        ScreenLoader()
    }
}

@Composable
fun ScreenLoadError(
    message: String,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.errorContainer
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Couldn't load information",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )

                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )

                Button(
                    onClick = onRetry,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Retry")
                }
            }
        }
    }
}