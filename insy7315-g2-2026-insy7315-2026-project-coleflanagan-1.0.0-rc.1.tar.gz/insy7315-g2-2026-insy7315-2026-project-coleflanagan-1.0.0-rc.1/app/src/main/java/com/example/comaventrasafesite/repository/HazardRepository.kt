package com.example.comaventrasafesite.repository

import com.example.comaventrasafesite.model.CorrectiveAction
import com.example.comaventrasafesite.model.Hazard
import com.example.comaventrasafesite.model.Role
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import com.google.firebase.firestore.Transaction
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull

class HazardRepository {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val hazards = db.collection("hazards")
    private val actions = db.collection("correctiveActions")

    companion object {
        private val managementRoles = setOf(
            Role.SAFETY_OFFICER.name,
            Role.ADMIN.name
        )

        private val severities = setOf(
            "LOW",
            "MEDIUM",
            "HIGH",
            "CRITICAL"
        )
    }

    suspend fun reportHazard(
        hazard: Hazard
    ): Result<String> {
        return try {
            val account = auth.currentUser
                ?: error("Please sign in again.")

            require(hazard.siteId.isNotBlank()) {
                "An assigned site is required."
            }

            require(hazard.title.isNotBlank()) {
                "Please give the hazard a title."
            }

            require(hazard.title.trim().length <= 160) {
                "Keep the hazard title under 160 characters."
            }

            require(hazard.category.isNotBlank()) {
                "Choose a hazard category."
            }

            require(hazard.severity in severities) {
                "Choose a valid hazard severity."
            }

            require(hazard.location.isNotBlank()) {
                "Enter where the hazard is located."
            }

            require(hazard.description.length <= 10000) {
                "Keep the description under 10,000 characters."
            }

            val reference = hazards.document()

            val savedHazard = hazard.copy(
                assignmentId = AssignedSiteAccess.forReport(hazard.siteId),
                id = reference.id,
                title = hazard.title.trim(),
                category = hazard.category.trim(),
                location = hazard.location.trim(),
                description = hazard.description.trim(),
                reportedBy = account.uid,
                reporterName = account.email
                    ?.takeIf { it.isNotBlank() }
                    ?: account.uid,
                status = "open",
                createdAt = System.currentTimeMillis(),
                closedAt = null,
                pendingActionIds = emptyList()
            )

            reference.set(savedHazard).await()

            logAudit(
                action = "HAZARD_REPORTED",
                hazardId = reference.id,
                siteId = savedHazard.siteId,
                summary = "Hazard reported: ${savedHazard.title} " +
                        "(${savedHazard.severity})"
            )

            Result.success(reference.id)
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Result.failure(error)
        }
    }

    suspend fun getHazardsForSite(
        siteId: String
    ): List<Hazard> {
        require(siteId.isNotBlank()) {
            "An assigned site is required."
        }

        val snapshot = hazards
            .whereEqualTo("siteId", siteId)
            .get(Source.SERVER)
            .await()

        return snapshot.documents
            .mapNotNull { document ->
                document.toObject(Hazard::class.java)
                    ?.copy(id = document.id)
            }
            .sortedByDescending {
                it.createdAt
            }
    }

    suspend fun getHazard(
        hazardId: String
    ): Hazard? {
        require(hazardId.isNotBlank()) {
            "The hazard could not be identified."
        }

        val document = hazards
            .document(hazardId)
            .get(Source.SERVER)
            .await()

        return document.toObject(Hazard::class.java)
            ?.copy(id = document.id)
    }

    suspend fun getCorrectiveActions(
        hazardId: String
    ): List<CorrectiveAction> {
        require(hazardId.isNotBlank()) {
            "The hazard could not be identified."
        }

        val snapshot = actions
            .whereEqualTo("hazardId", hazardId)
            .get(Source.SERVER)
            .await()

        return snapshot.documents
            .mapNotNull { document ->
                document.toObject(CorrectiveAction::class.java)
                    ?.copy(id = document.id)
            }
            .sortedBy {
                it.createdAt
            }
    }

    suspend fun canManageHazards(): Boolean {
        val account = auth.currentUser
            ?: error("Please sign in again.")

        val profile = db.collection("users")
            .document(account.uid)
            .get(Source.SERVER)
            .await()

        check(
            profile.exists() &&
                    profile.getString("status") == "active"
        ) {
            "Your account is unavailable or inactive. Please sign in again."
        }

        check(auth.currentUser?.uid == account.uid) {
            "Your signed-in account has changed. Please sign in again."
        }

        return profile.getString("role") in managementRoles
    }

    suspend fun addCorrectiveAction(
        action: CorrectiveAction
    ): Result<String> {
        return try {
            val account = auth.currentUser
                ?: error("Please sign in again.")

            require(action.hazardId.isNotBlank()) {
                "The hazard could not be identified."
            }

            require(action.description.isNotBlank()) {
                "Describe what needs to be done."
            }

            require(action.description.length <= 5000) {
                "Keep the corrective action under 5,000 characters."
            }

            require(action.assignedTo.length <= 200) {
                "Keep the assignment name under 200 characters."
            }

            require(action.dueDate > System.currentTimeMillis()) {
                "Choose a deadline that has not passed."
            }

            val actionReference = actions.document()
            val hazardReference = hazards.document(action.hazardId)

            val savedAction = action.copy(
                id = actionReference.id,
                description = action.description.trim(),
                assignedTo = action.assignedTo.trim(),
                createdBy = account.uid,
                status = "pending",
                createdAt = System.currentTimeMillis(),
                completedAt = null
            )

            val savedHazard = db.runTransaction { transaction ->
                requireManager(
                    transaction = transaction,
                    userId = account.uid
                )

                val document = transaction.get(hazardReference)
                check(document.contains("pendingActionIds")) {
                    "This hazard needs the security migration. Contact your administrator."
                }
                val current = document.toObject(Hazard::class.java)
                    ?: error("Hazard not found.")
                check(current.pendingActionIds.size < 2000) {
                    "This hazard has reached its supported pending-action limit."
                }

                check(
                    current.status == "open" ||
                            current.status == "in_progress"
                ) {
                    "This hazard is closed or unavailable for updates. " +
                            "Refresh before continuing."
                }

                transaction.set(
                    actionReference,
                    savedAction
                )

                transaction.update(
                    hazardReference,
                    mapOf(
                        "status" to "in_progress",
                        "pendingActionIds" to (current.pendingActionIds + actionReference.id)
                    )
                )

                current
            }.await()

            logAudit(
                action = "ACTION_ADDED",
                hazardId = action.hazardId,
                siteId = savedHazard.siteId,
                summary = "Corrective action on '${savedHazard.title}': " +
                        savedAction.description +
                        if (savedAction.assignedTo.isNotBlank()) {
                            " (assigned to ${savedAction.assignedTo})"
                        } else {
                            ""
                        }
            )

            Result.success(actionReference.id)
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Result.failure(error)
        }
    }

    suspend fun completeCorrectiveAction(
        actionId: String
    ): Result<Unit> {
        return try {
            require(actionId.isNotBlank()) {
                "The corrective action could not be identified."
            }

            val account = auth.currentUser
                ?: error("Please sign in again.")

            val actionReference = actions.document(actionId)
            val completedAt = System.currentTimeMillis()

            val savedRecords = db.runTransaction { transaction ->
                requireManager(
                    transaction = transaction,
                    userId = account.uid
                )

                val action = transaction
                    .get(actionReference)
                    .toObject(CorrectiveAction::class.java)
                    ?: error("Corrective action not found.")

                check(action.hazardId.isNotBlank()) {
                    "This corrective action has no linked hazard."
                }

                val hazardReference = hazards.document(action.hazardId)

                val hazardDocument = transaction.get(hazardReference)
                check(hazardDocument.contains("pendingActionIds")) {
                    "This hazard needs the security migration. Contact your administrator."
                }
                val hazard = hazardDocument.toObject(Hazard::class.java)
                    ?: error("Hazard not found.")
                check(actionId in hazard.pendingActionIds) {
                    "The hazard's pending actions need reconciliation. Contact your administrator."
                }

                check(hazard.status != "closed") {
                    "This hazard is already closed. Contact your administrator " +
                            "if its corrective actions need correction."
                }

                check(action.status == "pending") {
                    "This action has already changed. Refresh before continuing."
                }

                transaction.update(
                    actionReference,
                    mapOf(
                        "status" to "done",
                        "completedAt" to completedAt
                    )
                )

                transaction.update(
                    hazardReference,
                    "pendingActionIds",
                    hazard.pendingActionIds.filterNot { it == actionId }
                )
                action to hazard
            }.await()

            val savedAction = savedRecords.first
            val savedHazard = savedRecords.second

            logAudit(
                action = "ACTION_COMPLETED",
                hazardId = savedAction.hazardId,
                siteId = savedHazard.siteId,
                summary = "Corrective action done on " +
                        "'${savedHazard.title}': ${savedAction.description}"
            )

            Result.success(Unit)
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Result.failure(error)
        }
    }

    suspend fun closeHazard(
        hazardId: String
    ): Result<Unit> {
        return try {
            require(hazardId.isNotBlank()) {
                "The hazard could not be identified."
            }

            val account = auth.currentUser
                ?: error("Please sign in again.")

            val hazardReference = hazards.document(hazardId)
            val closedAt = System.currentTimeMillis()

            val savedHazard = db.runTransaction { transaction ->
                requireManager(
                    transaction = transaction,
                    userId = account.uid
                )

                val document = transaction.get(hazardReference)
                check(document.contains("pendingActionIds")) {
                    "This hazard needs the security migration. Contact your administrator."
                }
                val current = document.toObject(Hazard::class.java)
                    ?: error("Hazard not found.")
                check(current.status in listOf("open", "in_progress")) {
                    "This hazard has already changed. Refresh before continuing."
                }
                check(current.pendingActionIds.isEmpty()) {
                    "Finish all corrective actions before closing this hazard."
                }

                transaction.update(
                    hazardReference,
                    mapOf(
                        "status" to "closed",
                        "closedAt" to closedAt
                    )
                )

                current
            }.await()

            logAudit(
                action = "HAZARD_CLOSED",
                hazardId = hazardId,
                siteId = savedHazard.siteId,
                summary = "Hazard closed: ${savedHazard.title}"
            )

            Result.success(Unit)
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Result.failure(error)
        }
    }

    private fun requireManager(
        transaction: Transaction,
        userId: String
    ) {
        check(auth.currentUser?.uid == userId) {
            "Your signed-in account has changed. Please sign in again."
        }

        val profile = transaction.get(
            db.collection("users").document(userId)
        )

        check(
            profile.exists() &&
                    profile.getString("status") == "active" &&
                    profile.getString("role") in managementRoles
        ) {
            "An active Safety Officer or Administrator account " +
                    "is required to manage hazards."
        }
    }

    private suspend fun logAudit(
        action: String,
        hazardId: String,
        siteId: String,
        summary: String
    ) {
        withTimeoutOrNull(3_000L) {
            AuditLogger.log(
                action = action,
                entityType = "hazard",
                entityId = hazardId,
                summary = summary,
                siteId = siteId
            )
        }
    }
}