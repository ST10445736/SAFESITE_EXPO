package com.example.comaventrasafesite.ui.admin

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class AdminDestination(
    val label: String,
    val icon: ImageVector
) {
    DASHBOARD(
        "Dashboard",
        Icons.Filled.Home
    ),
    PEOPLE(
        "People",
        Icons.Filled.Person
    ),
    PROJECTS(
        "Projects",
        Icons.Filled.List
    ),
    REPORTS(
        "Reports",
        Icons.Filled.CheckCircle
    ),
    MORE(
        "More",
        Icons.Filled.MoreVert
    )
}

@Composable
fun AdminBottomBar(
    selectedDestination: AdminDestination,
    onNavigate: (AdminDestination) -> Unit
) {
    NavigationBar(
        containerColor =
            MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Spacer(
            modifier = androidx.compose.ui.Modifier
                .width(4.dp)
        )

        AdminDestination.entries.forEach {
                destination ->
            NavigationBarItem(
                selected =
                    destination ==
                            selectedDestination,
                onClick = {
                    onNavigate(destination)
                },
                icon = {
                    Icon(
                        imageVector =
                            destination.icon,
                        contentDescription =
                            destination.label
                    )
                },
                label = {
                    Text(
                        text = destination.label,
                        fontSize = 10.sp,
                        maxLines = 1,
                        overflow =
                            TextOverflow.Visible
                    )
                },
                colors =
                    NavigationBarItemDefaults
                        .colors(
                            selectedIconColor =
                                MaterialTheme
                                    .colorScheme
                                    .primary,
                            selectedTextColor =
                                MaterialTheme
                                    .colorScheme
                                    .primary,
                            indicatorColor =
                                MaterialTheme
                                    .colorScheme
                                    .primaryContainer,
                            unselectedIconColor =
                                MaterialTheme
                                    .colorScheme
                                    .onSurfaceVariant,
                            unselectedTextColor =
                                MaterialTheme
                                    .colorScheme
                                    .onSurfaceVariant
                        )
            )
        }

        Spacer(
            modifier = androidx.compose.ui.Modifier
                .width(4.dp)
        )
    }
}