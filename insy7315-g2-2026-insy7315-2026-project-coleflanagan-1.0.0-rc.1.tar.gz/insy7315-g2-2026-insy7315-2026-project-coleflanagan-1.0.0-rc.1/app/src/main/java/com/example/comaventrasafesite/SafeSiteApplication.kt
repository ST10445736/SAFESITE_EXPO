package com.example.comaventrasafesite

import android.app.Application
import com.google.firebase.FirebaseApp

class SafeSiteApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        FirebaseApp.initializeApp(this)
        AppCheckSetup.install()
    }
}