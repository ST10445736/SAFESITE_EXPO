package com.example.comaventrasafesite.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.exifinterface.media.ExifInterface
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.math.roundToInt

object FirestorePhoto {

    private const val MAX_SIDE = 1600
    private const val MAX_JPEG_BYTES = 450 * 1024

    suspend fun encode(context: Context, uri: Uri): String =
        withContext(Dispatchers.IO) {
            val resolver = context.applicationContext.contentResolver
            val bounds = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }

            val boundsStream = resolver.openInputStream(uri)
                ?: error("The selected photo could not be opened.")

            boundsStream.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }

            require(bounds.outWidth > 0 && bounds.outHeight > 0) {
                "The selected file is not a readable image."
            }

            var sampleSize = 1
            while (
                bounds.outWidth / sampleSize > MAX_SIDE ||
                bounds.outHeight / sampleSize > MAX_SIDE
            ) {
                sampleSize *= 2
            }

            val options = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }

            var bitmap = resolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, options)
            } ?: error("The selected photo could not be decoded.")

            try {
                val orientation = runCatching {
                    resolver.openInputStream(uri)?.use {
                        ExifInterface(it).getAttributeInt(
                            ExifInterface.TAG_ORIENTATION,
                            ExifInterface.ORIENTATION_NORMAL
                        )
                    } ?: ExifInterface.ORIENTATION_NORMAL
                }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)

                val matrix = Matrix().apply {
                    when (orientation) {
                        ExifInterface.ORIENTATION_FLIP_HORIZONTAL ->
                            setScale(-1f, 1f)

                        ExifInterface.ORIENTATION_ROTATE_180 ->
                            setRotate(180f)

                        ExifInterface.ORIENTATION_FLIP_VERTICAL ->
                            setScale(1f, -1f)

                        ExifInterface.ORIENTATION_TRANSPOSE -> {
                            setRotate(90f)
                            postScale(-1f, 1f)
                        }

                        ExifInterface.ORIENTATION_ROTATE_90 ->
                            setRotate(90f)

                        ExifInterface.ORIENTATION_TRANSVERSE -> {
                            setRotate(-90f)
                            postScale(-1f, 1f)
                        }

                        ExifInterface.ORIENTATION_ROTATE_270 ->
                            setRotate(-90f)
                    }
                }

                if (!matrix.isIdentity) {
                    val rotated = Bitmap.createBitmap(
                        bitmap,
                        0,
                        0,
                        bitmap.width,
                        bitmap.height,
                        matrix,
                        true
                    )

                    if (rotated !== bitmap) {
                        bitmap.recycle()
                        bitmap = rotated
                    }
                }

                var compressed: ByteArray? = null

                while (compressed == null) {
                    val bytes = ByteArrayOutputStream().use { output ->
                        check(
                            bitmap.compress(
                                Bitmap.CompressFormat.JPEG,
                                85,
                                output
                            )
                        ) {
                            "The photo could not be prepared."
                        }

                        output.toByteArray()
                    }

                    if (bytes.size <= MAX_JPEG_BYTES) {
                        compressed = bytes
                    } else {
                        require(
                            maxOf(bitmap.width, bitmap.height) > 640
                        ) {
                            "This photo is too large. Please choose another."
                        }

                        val smaller = Bitmap.createScaledBitmap(
                            bitmap,
                            (bitmap.width * 0.8f)
                                .roundToInt()
                                .coerceAtLeast(1),
                            (bitmap.height * 0.8f)
                                .roundToInt()
                                .coerceAtLeast(1),
                            true
                        )

                        if (smaller !== bitmap) {
                            bitmap.recycle()
                            bitmap = smaller
                        }
                    }
                }

                "data:image/jpeg;base64," +
                        Base64.encodeToString(
                            compressed,
                            Base64.NO_WRAP
                        )
            } finally {
                bitmap.recycle()
            }
        }
}