package com.example.comaventrasafesite.auth

import android.util.Log
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.example.comaventrasafesite.model.Role
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.MetadataChanges

@Composable
fun AccountSessionObserver(
    navController: NavHostController
) {
    val context = LocalContext.current

    val auth = remember {
        FirebaseAuth.getInstance()
    }

    val db = remember {
        FirebaseFirestore.getInstance()
    }

    var userId by remember {
        mutableStateOf(auth.currentUser?.uid)
    }

    var verifiedRole by remember(userId) {
        mutableStateOf<Role?>(null)
    }

    val backStackEntry by navController.currentBackStackEntryAsState()
    val route = backStackEntry?.destination?.route

    val protectedRoute = route != null &&
            route != "welcome" &&
            route != "sign_in"

    fun returnToSignIn() {
        val currentRoute = navController.currentDestination?.route

        if (
            currentRoute != null &&
            currentRoute != "welcome" &&
            currentRoute != "sign_in"
        ) {
            navController.navigate("sign_in") {
                popUpTo(0) {
                    inclusive = true
                }

                launchSingleTop = true
            }
        }
    }

    fun endSession(message: String) {
        verifiedRole = null
        auth.signOut()
        userId = null

        Toast.makeText(
            context,
            message,
            Toast.LENGTH_LONG
        ).show()

        returnToSignIn()
    }

    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener {
            userId = it.currentUser?.uid
        }

        auth.addAuthStateListener(listener)

        onDispose {
            auth.removeAuthStateListener(listener)
        }
    }

    DisposableEffect(userId, protectedRoute) {
        val observedUserId = userId

        if (
            observedUserId == null ||
            !protectedRoute
        ) {
            onDispose {}
        } else {
            val registration = db.collection("users")
                .document(observedUserId)
                .addSnapshotListener(
                    MetadataChanges.INCLUDE
                ) { snapshot, error ->
                    if (
                        auth.currentUser?.uid != observedUserId
                    ) {
                        return@addSnapshotListener
                    }

                    if (error != null) {
                        Log.e(
                            "SafeSiteSession",
                            "Account profile listener failed.",
                            error
                        )

                        endSession(
                            "Your account could not be verified. " +
                                    "Please sign in again."
                        )

                        return@addSnapshotListener
                    }

                    if (
                        snapshot == null ||
                        snapshot.metadata.isFromCache
                    ) {
                        return@addSnapshotListener
                    }

                    val role = Role.values().firstOrNull {
                        it.name == snapshot.getString("role")
                    }

                    if (
                        !snapshot.exists() ||
                        snapshot.getString("status") != "active" ||
                        role == null
                    ) {
                        endSession(
                            "Your account access has changed. " +
                                    "Contact your administrator."
                        )

                        return@addSnapshotListener
                    }

                    val previousRole = verifiedRole

                    if (
                        previousRole != null &&
                        previousRole != role
                    ) {
                        endSession(
                            "Your role has changed. Please sign in again."
                        )

                        return@addSnapshotListener
                    }

                    verifiedRole = role
                }

            onDispose {
                registration.remove()
            }
        }
    }

    LaunchedEffect(
        userId,
        backStackEntry,
        verifiedRole
    ) {
        if (!protectedRoute) {
            return@LaunchedEffect
        }

        if (userId == null) {
            returnToSignIn()
            return@LaunchedEffect
        }

        val accountRole = verifiedRole
            ?: return@LaunchedEffect

        val routeRole = backStackEntry
            ?.arguments
            ?.getString("roleName")

        if (
            routeRole != null &&
            routeRole != accountRole.name
        ) {
            endSession(
                "Your role has changed. Please sign in again."
            )
        }
    }
}