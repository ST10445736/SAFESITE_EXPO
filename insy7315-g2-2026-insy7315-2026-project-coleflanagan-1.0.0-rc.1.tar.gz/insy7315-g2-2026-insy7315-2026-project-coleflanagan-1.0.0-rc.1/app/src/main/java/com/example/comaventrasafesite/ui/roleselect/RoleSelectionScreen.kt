package com.example.comaventrasafesite.ui.roleselect

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.comaventrasafesite.model.Role
import com.example.comaventrasafesite.ui.theme.SafeSiteBackground
import com.example.comaventrasafesite.ui.theme.SafeSiteBorder
import com.example.comaventrasafesite.ui.theme.SafeSiteCharcoal
import com.example.comaventrasafesite.ui.theme.SafeSiteNavy
import com.example.comaventrasafesite.ui.theme.SafeSiteOlive
import com.example.comaventrasafesite.ui.theme.SafeSiteSuccess
import com.example.comaventrasafesite.ui.theme.SafeSiteTextMuted
import com.example.comaventrasafesite.ui.theme.SafeSiteTextSecondary

@Composable
fun RoleSelectionScreen(
    onRoleSelected: (Role) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SafeSiteBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {

        //header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    start = 24.dp,
                    end = 24.dp,
                    top = 34.dp,
                    bottom = 28.dp
                )
        ) {
            Text(
                text = "SafeSite",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold,
                color = SafeSiteCharcoal
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Choose how you’ll be using SafeSite",
                style = MaterialTheme.typography.bodyLarge,
                color = SafeSiteTextSecondary
            )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
        ) {

            Text(
                text = "CONTINUE AS",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = SafeSiteTextMuted,
                letterSpacing = 1.3.sp,
                modifier = Modifier.padding(
                    start = 4.dp,
                    bottom = 14.dp
                )
            )

            RoleOption(
                title = "Worker / Subcontractor",
                description = "View tasks, complete safety checks and report hazards.",
                initials = "W",
                accent = SafeSiteOlive,
                onClick = {
                    onRoleSelected(Role.WORKER)
                }
            )

            Spacer(modifier = Modifier.height(12.dp))

            RoleOption(
                title = "Site Supervisor / Manager",
                description = "Manage workers, tasks and daily site operations.",
                initials = "S",
                accent = SafeSiteNavy,
                onClick = {
                    onRoleSelected(Role.SUPERVISOR)
                }
            )

            Spacer(modifier = Modifier.height(12.dp))

            RoleOption(
                title = "Safety Officer / Manager",
                description = "Monitor compliance, hazards and safety performance.",
                initials = "SO",
                accent = SafeSiteSuccess,
                onClick = {
                    onRoleSelected(Role.SAFETY_OFFICER)
                }
            )

            Spacer(modifier = Modifier.height(12.dp))

            RoleOption(
                title = "Company Administrator",
                description = "Manage projects, sites, users and company access.",
                initials = "A",
                accent = SafeSiteNavy,
                onClick = {
                    onRoleSelected(Role.ADMIN)
                }
            )

            Spacer(modifier = Modifier.height(28.dp))

            Text(
                text = "Your account and role access are managed by your company administrator.",
                style = MaterialTheme.typography.bodySmall,
                color = SafeSiteTextMuted,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
            )
        }
    }
}

@Composable
private fun RoleOption(
    title: String,
    description: String,
    initials: String,
    accent: Color,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        border = BorderStroke(
            width = 1.dp,
            color = SafeSiteBorder
        ),
        shadowElevation = 1.dp
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(
                        color = accent.copy(alpha = 0.10f),
                        shape = RoundedCornerShape(14.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = initials,
                    color = accent,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Spacer(modifier = Modifier.size(14.dp))

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = SafeSiteCharcoal
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = SafeSiteTextSecondary,
                    lineHeight = 17.sp
                )
            }

            Spacer(modifier = Modifier.size(10.dp))

            Text(
                text = "›",
                color = SafeSiteTextMuted,
                fontSize = 28.sp,
                fontWeight = FontWeight.Light
            )
        }
    }
}