package com.example.comaventrasafesite.ui.signin

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.comaventrasafesite.R
import com.example.comaventrasafesite.auth.AuthManager
import com.example.comaventrasafesite.model.Role
import com.example.comaventrasafesite.ui.privacy.PrivacyPolicyLink
import com.example.comaventrasafesite.ui.theme.SafeSiteBackground
import com.example.comaventrasafesite.ui.theme.SafeSiteBorder
import com.example.comaventrasafesite.ui.theme.SafeSiteCharcoal
import com.example.comaventrasafesite.ui.theme.SafeSiteDanger
import com.example.comaventrasafesite.ui.theme.SafeSiteDangerLight
import com.example.comaventrasafesite.ui.theme.SafeSiteOlive
import com.example.comaventrasafesite.ui.theme.SafeSiteTextMuted
import com.example.comaventrasafesite.ui.theme.SafeSiteTextSecondary
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@Composable
fun SignInScreen(
    onSignInSuccess: (Role) -> Unit
) {
    var email by remember {
        mutableStateOf("")
    }

    var password by remember {
        mutableStateOf("")
    }

    var passwordVisible by remember {
        mutableStateOf(false)
    }

    var isLoading by remember {
        mutableStateOf(false)
    }

    var errorMessage by remember {
        mutableStateOf<String?>(null)
    }

    val authManager = remember {
        AuthManager()
    }

    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SafeSiteBackground)
            .imePadding()
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .background(Color(0xFF0C1409))
                .statusBarsPadding()
        ) {
            Image(
                painter = painterResource(
                    id = R.drawable.singo_logo
                ),
                contentDescription = "Singo Investment Holdings",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(
                        end = 8.dp,
                        top = 28.dp
                    )
                    .size(180.dp)
            )

            Column(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(
                        start = 24.dp,
                        end = 150.dp,
                        top = 36.dp
                    )
            ) {
                Text(
                    text = "SafeSite",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )

                Spacer(
                    modifier = Modifier.height(4.dp)
                )

                Text(
                    text = "CONSTRUCTION SAFETY",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = SafeSiteOlive,
                    letterSpacing = 1.4.sp
                )

                Spacer(
                    modifier = Modifier.height(14.dp)
                )

                Box(
                    modifier = Modifier
                        .size(
                            width = 38.dp,
                            height = 3.dp
                        )
                        .background(
                            color = SafeSiteOlive,
                            shape = RoundedCornerShape(10.dp)
                        )
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    horizontal = 22.dp,
                    vertical = 28.dp
                )
        ) {
            Text(
                text = "Sign in",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = SafeSiteCharcoal
            )

            Spacer(
                modifier = Modifier.height(10.dp)
            )

            Box(
                modifier = Modifier
                    .size(
                        width = 42.dp,
                        height = 3.dp
                    )
                    .background(
                        color = SafeSiteOlive,
                        shape = RoundedCornerShape(10.dp)
                    )
            )

            Spacer(
                modifier = Modifier.height(14.dp)
            )

            Text(
                text = "Enter your account details to continue.",
                style = MaterialTheme.typography.bodyMedium,
                color = SafeSiteTextSecondary
            )

            Spacer(
                modifier = Modifier.height(26.dp)
            )

            Text(
                text = "Email address",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = SafeSiteCharcoal
            )

            Spacer(
                modifier = Modifier.height(7.dp)
            )

            OutlinedTextField(
                value = email,
                onValueChange = {
                    email = it
                    errorMessage = null
                },
                enabled = !isLoading,
                placeholder = {
                    Text(
                        text = "name@company.co.za",
                        color = SafeSiteTextMuted
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email
                ),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = SafeSiteOlive,
                    unfocusedBorderColor = SafeSiteBorder,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                )
            )

            Spacer(
                modifier = Modifier.height(18.dp)
            )

            Text(
                text = "Password",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = SafeSiteCharcoal
            )

            Spacer(
                modifier = Modifier.height(7.dp)
            )

            OutlinedTextField(
                value = password,
                onValueChange = {
                    password = it
                    errorMessage = null
                },
                enabled = !isLoading,
                placeholder = {
                    Text(
                        text = "Enter your password",
                        color = SafeSiteTextMuted
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                visualTransformation = if (passwordVisible) {
                    VisualTransformation.None
                } else {
                    PasswordVisualTransformation()
                },
                trailingIcon = {
                    TextButton(
                        enabled = !isLoading,
                        onClick = {
                            passwordVisible = !passwordVisible
                        }
                    ) {
                        Text(
                            text = if (passwordVisible) {
                                "Hide"
                            } else {
                                "Show"
                            },
                            color = SafeSiteOlive,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password
                ),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = SafeSiteOlive,
                    unfocusedBorderColor = SafeSiteBorder,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                )
            )

            errorMessage?.let { message ->
                Spacer(
                    modifier = Modifier.height(14.dp)
                )

                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = SafeSiteDangerLight
                ) {
                    Text(
                        text = message,
                        style = MaterialTheme.typography.bodySmall,
                        color = SafeSiteDanger,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }

            Spacer(
                modifier = Modifier.height(26.dp)
            )

            Button(
                onClick = {
                    isLoading = true
                    errorMessage = null

                    scope.launch {
                        try {
                            authManager.signIn(
                                email = email.trim(),
                                password = password
                            ).onSuccess { role ->
                                password = ""
                                onSignInSuccess(role)
                            }.onFailure { error ->
                                errorMessage =
                                    error.message ?: "Sign in failed."
                            }
                        } catch (error: CancellationException) {
                            throw error
                        } catch (error: Exception) {
                            errorMessage =
                                error.message ?: "Sign in failed."
                        } finally {
                            isLoading = false
                        }
                    }
                },
                enabled = !isLoading &&
                        email.isNotBlank() &&
                        password.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = SafeSiteOlive,
                    contentColor = Color.White,
                    disabledContainerColor =
                        SafeSiteOlive.copy(alpha = 0.35f),
                    disabledContentColor =
                        Color.White.copy(alpha = 0.75f)
                )
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(21.dp),
                        strokeWidth = 2.dp,
                        color = Color.White
                    )
                } else {
                    Text(
                        text = "Sign In",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(
                modifier = Modifier.height(12.dp)
            )

            Text(
                text = "Your account access is managed by your company administrator.",
                style = MaterialTheme.typography.bodySmall,
                color = SafeSiteTextMuted,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            )

            Spacer(
                modifier = Modifier.height(8.dp)
            )

            PrivacyPolicyLink(
                modifier = Modifier.align(
                    Alignment.CenterHorizontally
                )
            )
        }
    }
}