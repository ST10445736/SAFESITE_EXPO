package com.example.comaventrasafesite.model

/**
 * A hazard reported on site (FR11). Default values are required so
 * Firestore's toObject() can build it from a document.
 */
data class Hazard(
    val id: String = "",
    val siteId: String = "",
    val title: String = "",
    val description: String = "",
    val category: String = "",          // e.g. "Working at height", "Electrical"
    val severity: String = "LOW",       // LOW / MEDIUM / HIGH / CRITICAL
    val location: String = "",          // where on site, e.g. "Block B, level 2"
    val photoUrl: String? = null,
    val reportedBy: String = "",        // user UID
    val reporterName: String = "",
    val status: String = "open",        // open / in_progress / closed
    val createdAt: Long = 0L,
    val closedAt: Long? = null,
    val pendingActionIds: List<String> = emptyList(),
    val assignmentId: String = ""
)