package com.example.comaventrasafesite.util

internal object CsvExport {

    fun cell(value: String): String {
        val firstMeaningfulCharacter = value.firstOrNull {
            !it.isWhitespace() && !it.isISOControl()
        }

        val startsWithControlCharacter =
            value.firstOrNull()?.let {
                it == '\t' || it == '\r' || it == '\n'
            } == true

        val couldBeFormula =
            firstMeaningfulCharacter in setOf('=', '+', '-', '@')

        val safeValue =
            if (couldBeFormula || startsWithControlCharacter) {
                "'$value"
            } else {
                value
            }

        return "\"" + safeValue.replace("\"", "\"\"") + "\""
    }

    fun document(
        header: List<String>,
        rows: List<List<String>>
    ): String {
        require(rows.all { it.size == header.size }) {
            "The export contains an incorrectly sized row."
        }

        return buildString {
            append('\uFEFF')
            append(header.joinToString(",") { cell(it) })

            rows.forEach { row ->
                append("\r\n")
                append(row.joinToString(",") { cell(it) })
            }

            append("\r\n")
        }
    }
}