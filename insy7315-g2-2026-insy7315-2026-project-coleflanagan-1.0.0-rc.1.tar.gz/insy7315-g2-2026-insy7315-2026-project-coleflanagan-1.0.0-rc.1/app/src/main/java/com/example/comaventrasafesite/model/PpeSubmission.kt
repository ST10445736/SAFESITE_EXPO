package com.example.comaventrasafesite.model

data class PpeSubmission(
    val id: String = "",
    val siteId: String = "",
    val workerId: String = "",
    val photoUrl: String = "",
    val decision: String = "pending", // "pending", "approved", "rejected"
    val submittedAt: Long = 0L,
    val reviewedAt: Long? = null,
    val aiVerdict: String = "",       // "compliant", "non_compliant", "unclear", "unavailable"
    val aiReason: String = "",
    val assignmentId: String = ""
)