package com.example.comaventrasafesite.ui.safeai

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SafeAiHost(
    showButton: Boolean = true,
    content: @Composable () -> Unit
) {
    var open by rememberSaveable {
        mutableStateOf(false)
    }

    LaunchedEffect(showButton) {
        if (!showButton) {
            open = false
        }
    }

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        content()

        if (open && showButton) {
            BackHandler {
                open = false
            }

            Surface(
                modifier = Modifier.fillMaxSize()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                ) {
                    SafeAiScreen(
                        onBack = {
                            open = false
                        }
                    )
                }
            }
        } else if (showButton) {
            FloatingActionButton(
                onClick = {
                    open = true
                },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(
                        end = 16.dp,
                        bottom = 96.dp
                    )
            ) {
                Text("AI")
            }
        }
    }
}