package com.example.comaventrasafesite.ui.worker

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.repository.WorkerSessionRepository
import com.example.comaventrasafesite.repository.WorkerSiteContext
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

@Composable
fun WorkerSafetyScreen(
    onNavigate: (WorkerDestination) -> Unit,
    onOpenChecklist: (String) -> Unit,
    onOpenPpe: (String) -> Unit,
    onReportHazard: (String) -> Unit,
    onReportIncident: (String) -> Unit
) {
    val repository = remember {
        WorkerSessionRepository()
    }

    val loader = rememberScreenLoader()
    val scope = rememberCoroutineScope()

    val workerId = FirebaseAuth.getInstance()
        .currentUser?.uid.orEmpty()

    var siteContext by remember(workerId) {
        mutableStateOf<WorkerSiteContext?>(null)
    }

    fun refresh() {
        scope.launch {
            loader.run {
                siteContext = repository.getActiveSite(workerId)
            }
        }
    }

    LaunchedEffect(workerId) {
        refresh()
    }

    val hasActiveSite = siteContext != null
    val loadError = loader.errorMessage

    val subtitle = when {
        loader.isLoading -> "Loading assigned site…"
        loadError != null -> "Assigned site unavailable"
        else -> siteContext?.siteName ?: "No active site assignment"
    }

    Scaffold(
        bottomBar = {
            WorkerBottomBar(
                selectedDestination = WorkerDestination.SAFETY,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            WorkerSiteHeader(
                title = "Safety",
                subtitle = subtitle,
                refreshEnabled = !loader.isLoading,
                onRefresh = {
                    refresh()
                }
            )

            when {
                loader.isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }

                loadError != null -> {
                    ScreenLoadError(
                        message = loadError,
                        onRetry = {
                            refresh()
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                else -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (!hasActiveSite) {
                            item {
                                WorkerActiveSiteCard(
                                    siteContext = null
                                )
                            }
                        }

                        item {
                            WorkerSectionLabel("Daily requirements")
                        }

                        item {
                            WorkerActionCard(
                                title = "Daily safety checklist",
                                description =
                                    "Complete the checklist before starting work",
                                icon = Icons.Filled.CheckCircle,
                                enabled = hasActiveSite,
                                onClick = {
                                    siteContext?.siteId?.let {
                                        onOpenChecklist(it)
                                    }
                                }
                            )
                        }

                        item {
                            WorkerActionCard(
                                title = "PPE verification",
                                description =
                                    "Submit a photo of your required PPE",
                                icon = Icons.Filled.Person,
                                enabled = hasActiveSite,
                                onClick = {
                                    siteContext?.siteId?.let {
                                        onOpenPpe(it)
                                    }
                                }
                            )
                        }

                        item {
                            WorkerSectionLabel(
                                text = "Reporting",
                                modifier = Modifier.padding(top = 12.dp)
                            )
                        }

                        item {
                            WorkerActionCard(
                                title = "Report a hazard",
                                description = "Report unsafe conditions " +
                                        "before someone is injured",
                                icon = Icons.Filled.Warning,
                                enabled = hasActiveSite,
                                onClick = {
                                    siteContext?.siteId?.let {
                                        onReportHazard(it)
                                    }
                                }
                            )
                        }

                        item {
                            WorkerActionCard(
                                title = "Report an incident",
                                description = "Record a near miss, injury " +
                                        "or equipment incident",
                                icon = Icons.Filled.Warning,
                                enabled = hasActiveSite,
                                onClick = {
                                    siteContext?.siteId?.let {
                                        onReportIncident(it)
                                    }
                                }
                            )
                        }

                        if (!hasActiveSite) {
                            item {
                                Text(
                                    text = "Ask an administrator to assign " +
                                            "you to an active site before " +
                                            "completing site actions.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color =
                                        MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(top = 12.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}