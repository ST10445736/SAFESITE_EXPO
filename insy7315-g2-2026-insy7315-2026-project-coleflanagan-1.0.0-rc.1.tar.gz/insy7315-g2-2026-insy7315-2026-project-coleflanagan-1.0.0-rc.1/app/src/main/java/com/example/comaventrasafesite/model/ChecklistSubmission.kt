package com.example.comaventrasafesite.model

data class ChecklistSubmission(
    val id: String = "",
    val siteId: String = "",
    val workerId: String = "",
    val answers: Map<String, Boolean> = emptyMap(),
    val submittedAt: Long = 0L,
    val status: String = "incomplete", // "complete" or "incomplete"
    val assignmentId: String = ""
)