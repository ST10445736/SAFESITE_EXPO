package com.example.comaventrasafesite.ui.incident

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.Incident
import com.example.comaventrasafesite.repository.IncidentRepository
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

private val reportIncidentTypes = listOf(
    "Injury",
    "Near miss",
    "Property damage",
    "Environmental",
    "Other"
)

private val reportIncidentSeverities = listOf(
    "MINOR",
    "MODERATE",
    "MAJOR",
    "CRITICAL"
)

private fun incidentSeverityLabelColor(
    severity: String
): Color = when (severity) {
    "MODERATE" -> Color(0xFF3E3200)
    else -> Color.White
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportIncidentScreen(
    siteId: String,
    onBack: () -> Unit,
    onSubmitted: () -> Unit
) {
    val repository = remember { IncidentRepository() }
    val scope = rememberCoroutineScope()

    val currentUser = remember {
        FirebaseAuth.getInstance().currentUser
    }

    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var injuredPerson by remember { mutableStateOf("") }
    var witnesses by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("") }
    var severity by remember { mutableStateOf("") }
    var isSaving by remember { mutableStateOf(false) }
    var errorMessage by remember {
        mutableStateOf<String?>(null)
    }

    fun submitIncident() {
        errorMessage = when {
            siteId.isBlank() ->
                "No assigned site was found."

            title.isBlank() ->
                "Enter a short title for the incident."

            type !in reportIncidentTypes ->
                "Choose an incident type."

            severity !in reportIncidentSeverities ->
                "Choose the incident severity."

            description.isBlank() ->
                "Describe what happened."

            location.isBlank() ->
                "Enter where the incident occurred."

            else ->
                null
        }

        if (errorMessage != null) {
            return
        }

        isSaving = true

        scope.launch {
            val incident = Incident(
                siteId = siteId,
                title = title.trim(),
                description = description.trim(),
                type = type,
                severity = severity,
                location = location.trim(),
                injuredPerson = injuredPerson.trim(),
                witnesses = witnesses.trim(),
                reportedBy = currentUser?.uid.orEmpty(),
                reporterName = currentUser?.email ?: "Unknown"
            )

            repository.reportIncident(incident)
                .onSuccess {
                    isSaving = false
                    onSubmitted()
                }
                .onFailure { error ->
                    isSaving = false
                    errorMessage = error.message
                        ?: "The incident could not be saved."
                }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Report Incident",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        enabled = !isSaving
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(
                    start = 20.dp,
                    top = 8.dp,
                    end = 20.dp,
                    bottom = 28.dp
                ),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            if (isSaving) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth()
                )
            }

            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surface
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(12.dp)
                        )
                    }

                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "Record the facts",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "Capture what happened while the details are still clear.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 3.dp)
                        )
                    }
                }
            }

            IncidentFormHeading(
                title = "Incident details",
                subtitle = "Provide a clear summary of the event."
            )

            OutlinedTextField(
                value = title,
                onValueChange = {
                    title = it
                    errorMessage = null
                },
                label = {
                    Text("Incident title")
                },
                placeholder = {
                    Text("Enter a short title")
                },
                supportingText = {
                    Text("${title.length}/80 characters")
                },
                singleLine = true,
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth()
            )

            IncidentFormHeading(
                title = "Incident type",
                subtitle = "Choose the category that best fits."
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                reportIncidentTypes.forEach { option ->
                    FilterChip(
                        selected = type == option,
                        onClick = {
                            type = option
                            errorMessage = null
                        },
                        enabled = !isSaving,
                        label = {
                            Text(option)
                        }
                    )
                }
            }

            IncidentFormHeading(
                title = "Severity",
                subtitle = "Select the actual or potential impact."
            )

            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                reportIncidentSeverities.chunked(2).forEach { rowOptions ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        rowOptions.forEach { option ->
                            FilterChip(
                                selected = severity == option,
                                onClick = {
                                    severity = option
                                    errorMessage = null
                                },
                                enabled = !isSaving,
                                label = {
                                    Text(
                                        text = option,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                },
                                modifier = Modifier.weight(1f),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = incidentSeverityColor(option),
                                    selectedLabelColor = incidentSeverityLabelColor(option)
                                )
                            )
                        }
                    }
                }
            }

            IncidentSeverityExplanation(
                severity = severity
            )

            OutlinedTextField(
                value = description,
                onValueChange = {
                    description = it
                    errorMessage = null
                },
                label = {
                    Text("What happened?")
                },
                placeholder = {
                    Text("Describe the events leading up to and immediately after the incident.")
                },
                minLines = 4,
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = location,
                onValueChange = {
                    location = it
                    errorMessage = null
                },
                label = {
                    Text("Location on site")
                },
                placeholder = {
                    Text("Describe the exact location")
                },
                singleLine = true,
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth()
            )

            HorizontalDivider()

            IncidentFormHeading(
                title = "People involved",
                subtitle = "These fields may be left blank when they do not apply."
            )

            OutlinedTextField(
                value = injuredPerson,
                onValueChange = {
                    injuredPerson = it
                },
                label = {
                    Text("Injured person")
                },
                placeholder = {
                    Text("Leave blank if nobody was injured")
                },
                singleLine = true,
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = witnesses,
                onValueChange = {
                    witnesses = it
                },
                label = {
                    Text("Witnesses")
                },
                placeholder = {
                    Text("Names of people who witnessed the event")
                },
                minLines = 2,
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth()
            )

            errorMessage?.let { message ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    contentColor = MaterialTheme.colorScheme.onErrorContainer
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Warning,
                            contentDescription = null
                        )

                        Text(
                            text = message,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Button(
                onClick = ::submitIncident,
                enabled = !isSaving,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                if (isSaving) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )

                    Text(
                        text = "Submitting…",
                        modifier = Modifier.padding(start = 10.dp)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null
                    )

                    Text(
                        text = "Submit Incident",
                        modifier = Modifier.padding(start = 10.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun IncidentFormHeading(
    title: String,
    subtitle: String
) {
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

@Composable
private fun IncidentSeverityExplanation(
    severity: String
) {
    val description = when (severity) {
        "CRITICAL" ->
            "Severe injury, fatality or major site-wide impact."

        "MAJOR" ->
            "Serious injury or significant operational impact."

        "MODERATE" ->
            "Medical treatment or a noticeable operational disruption."

        "MINOR" ->
            "Minor impact with limited or no injury."

        else ->
            "Select a severity to see its explanation."
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = if (severity.isBlank()) {
            MaterialTheme.colorScheme.surfaceVariant
        } else {
            incidentSeverityColor(severity).copy(alpha = 0.12f)
        }
    ) {
        Text(
            text = description,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(14.dp)
        )
    }
}