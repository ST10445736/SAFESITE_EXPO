package com.example.comaventrasafesite.model

data class Attendance(
    val id: String = "",
    val siteId: String = "",
    val workerId: String = "",
    val checkIn: Long? = null,
    val checkOut: Long? = null,
    val status: String = "checked_in",
    val assignmentId: String = ""
)