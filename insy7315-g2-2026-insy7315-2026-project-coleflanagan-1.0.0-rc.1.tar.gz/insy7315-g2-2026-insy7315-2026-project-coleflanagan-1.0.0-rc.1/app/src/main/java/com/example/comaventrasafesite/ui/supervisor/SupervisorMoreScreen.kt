package com.example.comaventrasafesite.ui.supervisor

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.ui.privacy.PrivacyPolicyLink
import com.google.firebase.auth.FirebaseAuth

@Composable
fun SupervisorMoreScreen(
    onNavigate: (SupervisorDestination) -> Unit,
    onSignOut: () -> Unit
) {
    val email = remember {
        FirebaseAuth.getInstance().currentUser?.email.orEmpty()
    }

    Scaffold(
        bottomBar = {
            SupervisorBottomBar(
                selectedDestination =
                    SupervisorDestination.MORE,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Surface(
                color = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(
                        horizontal = 20.dp,
                        vertical = 22.dp
                    )
                ) {
                    Text(
                        text = "More",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Supervisor account and application",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimary.copy(
                            alpha = 0.75f
                        )
                    )
                }
            }

            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                ElevatedCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "ACCOUNT",
                            style =
                                MaterialTheme.typography.labelMedium,
                            color = MaterialTheme
                                .colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = email,
                            style =
                                MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(top = 10.dp)
                        )
                        Text(
                            text = "Supervisor",
                            style =
                                MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme
                                .colorScheme.onSurfaceVariant
                        )
                    }
                }

                PrivacyPolicyLink()

                OutlinedButton(
                    onClick = onSignOut,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("Sign out")
                }

                Text(
                    text = "SafeSite v1.0",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme
                        .colorScheme.onSurfaceVariant
                )
            }
        }
    }
}