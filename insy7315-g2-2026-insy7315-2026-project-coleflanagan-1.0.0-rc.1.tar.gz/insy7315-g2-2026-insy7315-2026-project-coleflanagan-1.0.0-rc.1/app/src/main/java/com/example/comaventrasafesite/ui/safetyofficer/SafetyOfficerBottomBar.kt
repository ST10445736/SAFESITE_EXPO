package com.example.comaventrasafesite.ui.safetyofficer

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class SafetyOfficerDestination(
    val label: String
) {
    DASHBOARD("Dashboard"),
    HAZARDS("Hazards"),
    INCIDENTS("Incidents"),
    TRAINING("Training"),
    MORE("More")
}

@Composable
fun SafetyOfficerBottomBar(
    selectedDestination: SafetyOfficerDestination,
    onNavigate: (SafetyOfficerDestination) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Spacer(modifier = Modifier.width(4.dp))

        SafetyOfficerDestination.entries.forEach { destination ->
            val icon = when (destination) {
                SafetyOfficerDestination.DASHBOARD ->
                    Icons.Filled.Home

                SafetyOfficerDestination.HAZARDS ->
                    Icons.Filled.Warning

                SafetyOfficerDestination.INCIDENTS ->
                    Icons.Filled.Info

                SafetyOfficerDestination.TRAINING ->
                    Icons.Filled.List

                SafetyOfficerDestination.MORE ->
                    Icons.Filled.MoreVert
            }

            NavigationBarItem(
                selected = destination == selectedDestination,
                onClick = {
                    onNavigate(destination)
                },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = destination.label
                    )
                },
                label = {
                    Text(
                        text = destination.label,
                        fontSize = 10.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Visible
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor =
                        MaterialTheme.colorScheme.primary,
                    selectedTextColor =
                        MaterialTheme.colorScheme.primary,
                    indicatorColor =
                        MaterialTheme.colorScheme.primaryContainer,
                    unselectedIconColor =
                        MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor =
                        MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }

        Spacer(modifier = Modifier.width(4.dp))
    }
}