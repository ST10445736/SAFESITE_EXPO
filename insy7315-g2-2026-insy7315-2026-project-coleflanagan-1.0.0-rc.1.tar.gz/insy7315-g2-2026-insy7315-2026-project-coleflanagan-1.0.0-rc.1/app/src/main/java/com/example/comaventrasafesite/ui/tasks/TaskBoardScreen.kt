package com.example.comaventrasafesite.ui.tasks

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.comaventrasafesite.model.AppUser
import com.example.comaventrasafesite.model.Task
import com.example.comaventrasafesite.repository.TaskRepository
import com.example.comaventrasafesite.ui.shared.ScreenLoadError
import com.example.comaventrasafesite.ui.shared.rememberScreenLoader
import com.example.comaventrasafesite.ui.supervisor.SupervisorBottomBar
import com.example.comaventrasafesite.ui.supervisor.SupervisorDestination
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@Composable
fun TaskBoardScreen(
    siteId: String,
    onNavigate: (SupervisorDestination) -> Unit
) {
    val repository = remember {
        TaskRepository()
    }

    val scope = rememberCoroutineScope()
    val loader = rememberScreenLoader()

    var tasks by remember(siteId) {
        mutableStateOf<List<Task>>(emptyList())
    }

    var assignedWorkers by remember(siteId) {
        mutableStateOf<List<AppUser>>(emptyList())
    }

    var showCreateForm by rememberSaveable(siteId) {
        mutableStateOf(false)
    }

    var isCreating by remember {
        mutableStateOf(false)
    }

    fun refresh() {
        scope.launch {
            loader.run {
                val loadedTasks = repository
                    .getSiteTasks(siteId)
                    .sortedBy { it.dueDate }

                val loadedWorkers = repository
                    .getAssignableWorkers(siteId)

                tasks = loadedTasks
                assignedWorkers = loadedWorkers
            }
        }
    }

    LaunchedEffect(siteId) {
        refresh()
    }

    val workerNames = assignedWorkers.associate {
        it.id to it.fullName
    }

    Scaffold(
        bottomBar = {
            SupervisorBottomBar(
                selectedDestination = SupervisorDestination.TASKS,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Surface(
                color = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(
                            horizontal = 20.dp,
                            vertical = 20.dp
                        ),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "Task Board",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "Assign and track site work",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimary.copy(
                                alpha = 0.75f
                            )
                        )
                    }

                    IconButton(
                        onClick = {
                            refresh()
                        },
                        enabled = !loader.isLoading &&
                                !isCreating
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Refresh tasks",
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }

                    TextButton(
                        onClick = {
                            showCreateForm = !showCreateForm
                        },
                        enabled = !loader.isLoading &&
                                loader.errorMessage == null &&
                                !isCreating,
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                            disabledContentColor =
                                MaterialTheme.colorScheme.onPrimary.copy(
                                    alpha = 0.45f
                                )
                        )
                    ) {
                        Text(
                            text = if (showCreateForm) {
                                "Cancel"
                            } else {
                                "New task"
                            }
                        )
                    }
                }
            }

            val loadError = loader.errorMessage

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when {
                    loader.isLoading -> {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator()
                            }
                        }
                    }

                    loadError != null -> {
                        item {
                            ScreenLoadError(
                                message = loadError,
                                onRetry = {
                                    refresh()
                                },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    else -> {
                        if (showCreateForm) {
                            item {
                                CreateTaskForm(
                                    siteId = siteId,
                                    workers = assignedWorkers,
                                    repository = repository,
                                    onSavingChanged = {
                                        isCreating = it
                                    },
                                    onCreated = {
                                        showCreateForm = false
                                        refresh()
                                    }
                                )
                            }
                        }

                        if (tasks.isEmpty()) {
                            item {
                                Text(
                                    text = "No tasks created for this site.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color =
                                        MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(
                                        vertical = 20.dp
                                    )
                                )
                            }
                        } else {
                            items(
                                items = tasks,
                                key = { it.id }
                            ) { task ->
                                SupervisorTaskCard(
                                    task = task,
                                    workerName =
                                        workerNames[task.assigneeId]
                                            ?: "Assigned worker"
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SupervisorTaskCard(
    task: Task,
    workerName: String
) {
    val overdue = task.status != "completed" &&
            task.dueDate > 0L &&
            task.dueDate < System.currentTimeMillis()

    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )

                Spacer(
                    modifier = Modifier.width(12.dp)
                )

                Text(
                    text = task.status
                        .replace("_", " ")
                        .uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = when (task.status) {
                        "completed" -> {
                            MaterialTheme.colorScheme.primary
                        }

                        "blocked" -> {
                            MaterialTheme.colorScheme.error
                        }

                        else -> {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    }
                )
            }

            Text(
                text = workerName,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp)
            )

            if (task.description.isNotBlank()) {
                Text(
                    text = task.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            Text(
                text = "Due ${formatTaskDate(task.dueDate)}",
                style = MaterialTheme.typography.bodySmall,
                color = if (overdue) {
                    MaterialTheme.colorScheme.error
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
                modifier = Modifier.padding(top = 8.dp)
            )

            TaskProgressPhoto(
                photoUrl = task.photoUrl
            )

            if (task.progressNote.isNotBlank()) {
                Text(
                    text = task.progressNote,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CreateTaskForm(
    siteId: String,
    workers: List<AppUser>,
    repository: TaskRepository,
    onSavingChanged: (Boolean) -> Unit,
    onCreated: () -> Unit
) {
    val scope = rememberCoroutineScope()

    var title by rememberSaveable {
        mutableStateOf("")
    }

    var description by rememberSaveable {
        mutableStateOf("")
    }

    var selectedWorkerId by rememberSaveable {
        mutableStateOf<String?>(null)
    }

    var selectedDay by rememberSaveable {
        mutableStateOf<Long?>(null)
    }

    var showDatePicker by remember {
        mutableStateOf(false)
    }

    var isSaving by remember {
        mutableStateOf(false)
    }

    var errorMessage by remember {
        mutableStateOf<String?>(null)
    }

    val dueDate = selectedDay?.let {
        taskDeadlineFromPicker(it)
    }

    val selectedWorkerStillAvailable = workers.any {
        it.id == selectedWorkerId
    }

    if (showDatePicker) {
        val pickerState = rememberDatePickerState(
            initialSelectedDateMillis = selectedDay
        )

        val pickerDeadline = pickerState
            .selectedDateMillis
            ?.let {
                taskDeadlineFromPicker(it)
            }

        DatePickerDialog(
            onDismissRequest = {
                showDatePicker = false
            },
            confirmButton = {
                TextButton(
                    enabled = pickerDeadline != null &&
                            pickerDeadline >= System.currentTimeMillis(),
                    onClick = {
                        selectedDay = pickerState.selectedDateMillis
                        errorMessage = null
                        showDatePicker = false
                    }
                ) {
                    Text("Use date")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showDatePicker = false
                    }
                ) {
                    Text("Cancel")
                }
            }
        ) {
            DatePicker(
                state = pickerState
            )
        }
    }

    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Create Task",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            OutlinedTextField(
                value = title,
                onValueChange = {
                    title = it
                    errorMessage = null
                },
                label = {
                    Text("Task title")
                },
                supportingText = {
                    Text("${title.length}/160")
                },
                isError = title.length > 160,
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = description,
                onValueChange = {
                    description = it
                    errorMessage = null
                },
                label = {
                    Text("Description")
                },
                supportingText = {
                    Text("${description.length}/5000")
                },
                isError = description.length > 5000,
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )

            Text(
                text = "Due date",
                style = MaterialTheme.typography.labelLarge
            )

            OutlinedButton(
                onClick = {
                    showDatePicker = true
                },
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = if (dueDate == null) {
                        "Choose due date"
                    } else {
                        formatTaskDate(dueDate)
                    }
                )
            }

            Text(
                text = "Choose today or a later date. The task is due " +
                        "at the end of the selected day.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Text(
                text = "Assign to",
                style = MaterialTheme.typography.labelLarge
            )

            if (workers.isEmpty()) {
                Text(
                    text = "No active workers are assigned to this site.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    workers.forEach { worker ->
                        FilterChip(
                            selected = selectedWorkerId == worker.id,
                            onClick = {
                                selectedWorkerId = worker.id
                                errorMessage = null
                            },
                            enabled = !isSaving,
                            label = {
                                Text(
                                    text = worker.fullName.ifBlank {
                                        worker.email
                                    }
                                )
                            }
                        )
                    }
                }
            }

            errorMessage?.let { message ->
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            Button(
                onClick = {
                    val workerId =
                        selectedWorkerId ?: return@Button

                    val deadline =
                        dueDate ?: return@Button

                    isSaving = true
                    onSavingChanged(true)
                    errorMessage = null

                    scope.launch {
                        try {
                            repository.createTask(
                                siteId = siteId,
                                assigneeId = workerId,
                                title = title,
                                description = description,
                                dueDate = deadline
                            ).onSuccess {
                                onCreated()
                            }.onFailure { error ->
                                errorMessage =
                                    error.message ?: "Task creation failed."
                            }
                        } catch (error: CancellationException) {
                            throw error
                        } catch (error: Exception) {
                            errorMessage =
                                error.message ?: "Task creation failed."
                        } finally {
                            isSaving = false
                            onSavingChanged(false)
                        }
                    }
                },
                enabled = !isSaving &&
                        title.isNotBlank() &&
                        title.length <= 160 &&
                        description.length <= 5000 &&
                        selectedWorkerStillAvailable &&
                        dueDate != null &&
                        dueDate >= System.currentTimeMillis(),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) {
                if (isSaving) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                } else {
                    Text("Create task")
                }
            }
        }
    }
}

private fun taskDeadlineFromPicker(
    selectedDateMillis: Long
): Long {
    val selectedDate = Calendar.getInstance(
        TimeZone.getTimeZone("UTC")
    ).apply {
        timeInMillis = selectedDateMillis
    }

    val deadline = Calendar.getInstance(
        TimeZone.getTimeZone("Africa/Johannesburg")
    ).apply {
        clear()

        set(
            selectedDate.get(Calendar.YEAR),
            selectedDate.get(Calendar.MONTH),
            selectedDate.get(Calendar.DAY_OF_MONTH),
            0,
            0,
            0
        )

        add(Calendar.DAY_OF_MONTH, 1)
    }

    return deadline.timeInMillis - 1L
}

private fun formatTaskDate(
    timestamp: Long
): String {
    if (timestamp <= 0L) {
        return "not specified"
    }

    return SimpleDateFormat(
        "dd MMM yyyy",
        Locale.getDefault()
    ).apply {
        timeZone = TimeZone.getTimeZone(
            "Africa/Johannesburg"
        )
    }.format(Date(timestamp))
}