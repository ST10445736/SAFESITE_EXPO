package com.example.comaventrasafesite.model

/** One entry on an incident's timeline — every status change is logged. */
data class IncidentEvent(
    val id: String = "",
    val incidentId: String = "",
    val fromStatus: String = "",
    val toStatus: String = "",
    val note: String = "",
    val byUserId: String = "",
    val byName: String = "",
    val at: Long = 0L
)