package com.example.comaventrasafesite.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.exifinterface.media.ExifInterface
import android.net.Uri
import android.util.Base64
import android.util.Log
import com.example.comaventrasafesite.ai.AiService
import com.example.comaventrasafesite.model.PpeSubmission
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.Source
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import kotlin.math.roundToInt

class PpeRepository {

    private val db = FirebaseFirestore.getInstance()
    private val ppeCollection = db.collection("ppe_submissions")
    private val auth = FirebaseAuth.getInstance()

    companion object {
        private const val MAX_PHOTO_BYTES = 450 * 1024
        private const val MAX_PHOTO_SIDE = 1600
        private const val AI_TIMEOUT_MS = 45_000L
        private const val PENDING_PAGE_SIZE = 20L
    }

    suspend fun submitPpePhoto(
        siteId: String,
        workerId: String,
        photoUri: Uri,
        context: Context? = null
    ): Result<String> {
        return try {
            require(siteId.isNotBlank()) {
                "No assigned site was found."
            }

            require(
                workerId.isNotBlank() &&
                        auth.currentUser?.uid == workerId
            ) {
                "Please sign in again before submitting PPE."
            }

            val appContext = context?.applicationContext
                ?: error(
                    "The photo could not be opened. Please try again."
                )

            val imageBytes = preparePhoto(
                context = appContext,
                uri = photoUri
            )

            val encodedPhoto = Base64.encodeToString(
                imageBytes,
                Base64.NO_WRAP
            )

            val photoDataUrl =
                "data:image/jpeg;base64,$encodedPhoto"

            val ai = withTimeoutOrNull(
                AI_TIMEOUT_MS
            ) {
                AiService.checkPpe(imageBytes)
            }

            if (ai == null) {
                Log.w(
                    "PPE_AI",
                    "The PPE AI check exceeded its 45-second limit."
                )
            }

            check(auth.currentUser?.uid == workerId) {
                "Your signed-in account has changed. " +
                        "Please sign in again before submitting PPE."
            }

            val document = ppeCollection.document()

            val submission = PpeSubmission(
                assignmentId = AssignedSiteAccess.requireAssignment(siteId, workerId),
                id = document.id,
                siteId = siteId,
                workerId = workerId,
                photoUrl = photoDataUrl,
                decision = "pending",
                submittedAt = System.currentTimeMillis(),
                aiVerdict = ai?.verdict ?: "unavailable",
                aiReason = ai?.reason
                    ?: "AI check timed out. Supervisor review is required."
            )

            document.set(submission).await()

            Result.success(document.id)
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Log.e(
                "PPE",
                "PPE submission failed.",
                error
            )

            Result.failure(error)
        }
    }

    suspend fun getPendingSubmissions(
        siteId: String
    ): List<PpeSubmission> {
        require(siteId.isNotBlank()) {
            "No assigned site was found."
        }

        val snapshot = ppeCollection
            .whereEqualTo("siteId", siteId)
            .whereEqualTo("decision", "pending")
            .orderBy(
                "submittedAt",
                Query.Direction.ASCENDING
            )
            .limit(PENDING_PAGE_SIZE)
            .get(Source.SERVER)
            .await()

        return snapshot.documents.mapNotNull { document ->
            document.toObject(PpeSubmission::class.java)
                ?.copy(id = document.id)
        }
    }

    suspend fun reviewSubmission(
        submissionId: String,
        approved: Boolean
    ): Result<Unit> {
        return try {
            require(submissionId.isNotBlank()) {
                "The PPE submission could not be identified."
            }

            val reviewerId = auth.currentUser?.uid
                ?: error("Please sign in again.")

            val reference = ppeCollection.document(
                submissionId
            )

            val decision = if (approved) {
                "approved"
            } else {
                "rejected"
            }

            val reviewedAt = System.currentTimeMillis()

            db.runTransaction { transaction ->
                check(auth.currentUser?.uid == reviewerId) {
                    "Your signed-in account has changed. " +
                            "Please sign in again."
                }

                val document = transaction.get(reference)

                check(document.exists()) {
                    "This PPE submission no longer exists."
                }

                check(
                    document.getString("decision") == "pending"
                ) {
                    "This submission has already been reviewed. " +
                            "Refresh the list."
                }

                transaction.update(
                    reference,
                    mapOf(
                        "decision" to decision,
                        "reviewedAt" to reviewedAt
                    )
                )

                Unit
            }.await()

            Result.success(Unit)
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Log.e(
                "PPE",
                "PPE review failed.",
                error
            )

            Result.failure(error)
        }
    }

    private suspend fun preparePhoto(
        context: Context,
        uri: Uri
    ): ByteArray = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver

        val bounds = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }

        val boundsStream = resolver.openInputStream(uri)
            ?: error(
                "The selected photo could not be opened."
            )

        boundsStream.use { stream ->
            BitmapFactory.decodeStream(
                stream,
                null,
                bounds
            )
        }

        require(
            bounds.outWidth > 0 &&
                    bounds.outHeight > 0
        ) {
            "The selected file is not a readable image."
        }

        var sampleSize = 1

        while (
            bounds.outWidth / sampleSize > MAX_PHOTO_SIDE ||
            bounds.outHeight / sampleSize > MAX_PHOTO_SIDE
        ) {
            sampleSize *= 2
        }

        val options = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
        }

        val decoded = resolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(
                stream,
                null,
                options
            )
        } ?: error(
            "The selected photo could not be decoded."
        )

        var bitmap = decoded

        try {
            val orientation = runCatching {
                resolver.openInputStream(uri)?.use { stream ->
                    ExifInterface(stream).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION,
                        ExifInterface.ORIENTATION_NORMAL
                    )
                } ?: ExifInterface.ORIENTATION_NORMAL
            }.getOrDefault(
                ExifInterface.ORIENTATION_NORMAL
            )

            val matrix = Matrix()

            when (orientation) {
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> {
                    matrix.setScale(-1f, 1f)
                }

                ExifInterface.ORIENTATION_ROTATE_180 -> {
                    matrix.setRotate(180f)
                }

                ExifInterface.ORIENTATION_FLIP_VERTICAL -> {
                    matrix.setScale(1f, -1f)
                }

                ExifInterface.ORIENTATION_TRANSPOSE -> {
                    matrix.setRotate(90f)
                    matrix.postScale(-1f, 1f)
                }

                ExifInterface.ORIENTATION_ROTATE_90 -> {
                    matrix.setRotate(90f)
                }

                ExifInterface.ORIENTATION_TRANSVERSE -> {
                    matrix.setRotate(-90f)
                    matrix.postScale(-1f, 1f)
                }

                ExifInterface.ORIENTATION_ROTATE_270 -> {
                    matrix.setRotate(-90f)
                }
            }

            if (!matrix.isIdentity) {
                val oriented = Bitmap.createBitmap(
                    bitmap,
                    0,
                    0,
                    bitmap.width,
                    bitmap.height,
                    matrix,
                    true
                )

                if (oriented !== bitmap) {
                    bitmap.recycle()
                    bitmap = oriented
                }
            }

            while (true) {
                val bytes = ByteArrayOutputStream().use { output ->
                    check(
                        bitmap.compress(
                            Bitmap.CompressFormat.JPEG,
                            85,
                            output
                        )
                    ) {
                        "The photo could not be compressed."
                    }

                    output.toByteArray()
                }

                if (bytes.size <= MAX_PHOTO_BYTES) {
                    return@withContext bytes
                }

                if (
                    maxOf(
                        bitmap.width,
                        bitmap.height
                    ) <= 640
                ) {
                    error(
                        "This photo could not be reduced enough to save. " +
                                "Please choose another photo."
                    )
                }

                val resized = Bitmap.createScaledBitmap(
                    bitmap,
                    (bitmap.width * 0.8f)
                        .roundToInt()
                        .coerceAtLeast(1),
                    (bitmap.height * 0.8f)
                        .roundToInt()
                        .coerceAtLeast(1),
                    true
                )

                if (resized !== bitmap) {
                    bitmap.recycle()
                    bitmap = resized
                }
            }

            @Suppress("UNREACHABLE_CODE")
            error("Photo processing failed.")
        } finally {
            bitmap.recycle()
        }
    }
}