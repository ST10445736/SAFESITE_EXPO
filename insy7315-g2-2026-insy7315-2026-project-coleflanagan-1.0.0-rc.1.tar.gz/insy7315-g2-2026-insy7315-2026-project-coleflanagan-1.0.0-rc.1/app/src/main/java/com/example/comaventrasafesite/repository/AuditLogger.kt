package com.example.comaventrasafesite.repository

import com.example.comaventrasafesite.model.AuditLog
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

/**
 * Writes audit entries. Works out WHO from the signed-in user automatically,
 * so repositories only say what happened.
 */
object AuditLogger {

    suspend fun log(
        action: String,
        entityType: String,
        entityId: String,
        summary: String,
        siteId: String = ""
    ) {
        try {
            val user = FirebaseAuth.getInstance().currentUser
            val doc = FirebaseFirestore.getInstance().collection("auditLogs").document()
            doc.set(
                AuditLog(
                    id = doc.id,
                    action = action,
                    entityType = entityType,
                    entityId = entityId,
                    summary = summary,
                    siteId = siteId,
                    byUserId = user?.uid ?: "",
                    byName = user?.email ?: "Unknown",
                    at = System.currentTimeMillis()
                )
            ).await()
        } catch (e: Exception) {
            // Never let a logging failure break the real action
        }
    }
}