package com.example.comaventrasafesite.repository

import com.example.comaventrasafesite.model.Project
import com.example.comaventrasafesite.model.Role
import com.example.comaventrasafesite.model.Site
import com.example.comaventrasafesite.model.SiteAssignment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import com.google.firebase.firestore.Transaction
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull
import java.text.ParsePosition
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class ProjectRepository {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val projects = db.collection("projects")
    private val sites = db.collection("sites")
    private val assignments = db.collection("site_assignments")

    companion object {
        val PROJECT_STATUSES = listOf("active", "on_hold", "completed")

        fun label(status: String): String = when (status) {
            "active" -> "Active"
            "on_hold" -> "On hold"
            "completed" -> "Completed"
            "inactive" -> "Inactive"
            else -> status.ifBlank { "Unknown" }
        }

        private fun dateFormat() =
            SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                isLenient = false
                timeZone = TimeZone.getTimeZone("Africa/Johannesburg")
            }

        fun today(): String = dateFormat().format(Date())

        fun isValidDate(value: String): Boolean {
            if (!Regex("\\d{4}-\\d{2}-\\d{2}").matches(value)) return false

            val position = ParsePosition(0)
            val parsed = dateFormat().parse(value, position)

            return parsed != null && position.index == value.length
        }
    }

    private fun validId(value: String): String {
        require(value.isNotBlank() && !value.contains("/")) {
            "A valid record reference is required."
        }
        return value
    }

    private fun requiredText(
        value: String,
        label: String,
        maximum: Int
    ): String {
        val text = value.trim()
        require(text.isNotBlank()) { "Enter $label." }
        require(text.length <= maximum) {
            "$label must contain no more than $maximum characters."
        }
        return text
    }

    private fun projectFrom(document: DocumentSnapshot): Project =
        (document.toObject(Project::class.java)
            ?: error("A project could not be read.")).copy(
            id = document.id,
            status = document.getString("status").orEmpty()
        )

    private fun siteFrom(document: DocumentSnapshot): Site =
        (document.toObject(Site::class.java)
            ?: error("A site could not be read.")).copy(
            id = document.id,
            status = document.getString("status").orEmpty()
        )

    private fun assignmentFrom(document: DocumentSnapshot): SiteAssignment {
        val assignment = document.toObject(SiteAssignment::class.java)
            ?: error("An assignment could not be read.")

        check(assignment.siteId.isNotBlank() && assignment.workerId.isNotBlank()) {
            "An assignment has missing references. Ask an Administrator to review it."
        }

        return assignment.copy(id = document.id)
    }

    private fun requireAdministrator(
        transaction: Transaction,
        uid: String
    ) {
        check(auth.currentUser?.uid == uid) {
            "Your session changed. Sign in again."
        }

        val profile = transaction.get(db.collection("users").document(uid))

        check(
            profile.exists() &&
                    profile.getString("status") == "active" &&
                    profile.getString("role") == Role.ADMIN.name
        ) {
            "An active Administrator account is required."
        }
    }

    private suspend fun <T> adminTransaction(
        action: (Transaction) -> T
    ): T {
        val uid = auth.currentUser?.uid
            ?: error("Sign in before making changes.")

        return db.runTransaction { transaction ->
            requireAdministrator(transaction, uid)
            action(transaction)
        }.await()
    }

    private suspend fun <T> result(action: suspend () -> T): Result<T> =
        try {
            Result.success(action())
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Result.failure(error)
        }

    private suspend fun audit(
        action: String,
        type: String,
        id: String,
        summary: String,
        siteId: String = ""
    ) {
        withTimeoutOrNull(3_000L) {
            AuditLogger.log(
                action = action,
                entityType = type,
                entityId = id,
                summary = summary,
                siteId = siteId
            )
        }
    }

    suspend fun getProjects(): List<Project> =
        projects.get(Source.SERVER).await().documents
            .map(::projectFrom)
            .sortedBy { it.name.lowercase(Locale.ROOT) }

    suspend fun getProject(projectId: String): Project? {
        val document = projects.document(validId(projectId))
            .get(Source.SERVER).await()

        return if (document.exists()) projectFrom(document) else null
    }

    suspend fun getAllSites(): List<Site> =
        sites.get(Source.SERVER).await().documents
            .map(::siteFrom)
            .sortedBy { it.name.lowercase(Locale.ROOT) }

    suspend fun getSite(siteId: String): Site? {
        val document = sites.document(validId(siteId))
            .get(Source.SERVER).await()

        return if (document.exists()) siteFrom(document) else null
    }

    suspend fun getAssignments(siteId: String): List<SiteAssignment> =
        assignments.whereEqualTo("siteId", validId(siteId))
            .get(Source.SERVER).await().documents
            .map(::assignmentFrom)
            .sortedByDescending { it.startDate }

    suspend fun createProject(
        name: String,
        clientName: String,
        startDate: String
    ): Result<String> = result {
        val cleanName = requiredText(name, "a project name", 200)
        val cleanClient = requiredText(clientName, "the client name", 200)
        val cleanDate = startDate.trim()

        require(isValidDate(cleanDate)) {
            "Enter a real start date using YYYY-MM-DD."
        }

        val reference = projects.document()

        adminTransaction { transaction ->
            transaction.set(
                reference,
                Project(
                    id = reference.id,
                    name = cleanName,
                    clientName = cleanClient,
                    status = "active",
                    startDate = cleanDate
                )
            )
        }

        audit(
            "PROJECT_CREATED",
            "project",
            reference.id,
            "Project created: $cleanName for $cleanClient"
        )

        reference.id
    }

    suspend fun setProjectStatus(
        projectId: String,
        status: String
    ): Result<Unit> = result {
        require(status in PROJECT_STATUSES) { "Choose a valid project status." }
        val reference = projects.document(validId(projectId))

        val name = adminTransaction { transaction ->
            val document = transaction.get(reference)
            check(document.exists()) { "This project no longer exists." }

            transaction.update(reference, "status", status)
            document.getString("name").orEmpty().ifBlank { projectId }
        }

        audit(
            "PROJECT_STATUS_CHANGED",
            "project",
            projectId,
            "Project '$name' set to ${label(status)}"
        )
    }

    suspend fun createSite(
        projectId: String,
        name: String,
        address: String
    ): Result<String> = result {
        val projectReference = projects.document(validId(projectId))
        val cleanName = requiredText(name, "a site name", 200)
        val cleanAddress = requiredText(address, "the site address", 2000)
        val reference = sites.document()

        val projectName = adminTransaction { transaction ->
            val project = transaction.get(projectReference)
            check(project.exists() && project.getString("status") == "active") {
                "Sites can only be added to an active project."
            }

            transaction.set(
                reference,
                Site(
                    id = reference.id,
                    projectId = projectId,
                    name = cleanName,
                    address = cleanAddress,
                    status = "active"
                )
            )

            project.getString("name").orEmpty().ifBlank { projectId }
        }

        audit(
            "SITE_CREATED",
            "site",
            reference.id,
            "Site '$cleanName' added to project '$projectName'",
            reference.id
        )

        reference.id
    }

    suspend fun setSiteStatus(
        siteId: String,
        status: String
    ): Result<Unit> = result {
        require(status in listOf("active", "inactive")) {
            "Choose a valid site status."
        }

        val reference = sites.document(validId(siteId))

        val name = adminTransaction { transaction ->
            val site = transaction.get(reference)
            check(site.exists()) { "This site no longer exists." }

            val projectId = site.getString("projectId").orEmpty()

            if (status == "active" && projectId.isNotBlank()) {
                val project = transaction.get(
                    projects.document(validId(projectId))
                )
                check(
                    project.exists() &&
                            project.getString("status") == "active"
                ) {
                    "Activate the linked project before activating this site."
                }
            }

            transaction.update(reference, "status", status)
            site.getString("name").orEmpty().ifBlank { siteId }
        }

        audit(
            "SITE_STATUS_CHANGED",
            "site",
            siteId,
            "Site '$name' set to ${label(status)}",
            siteId
        )
    }

    suspend fun linkSiteToProject(
        siteId: String,
        projectId: String
    ): Result<Unit> = result {
        val siteReference = sites.document(validId(siteId))
        val projectReference = projects.document(validId(projectId))

        val names = adminTransaction { transaction ->
            val site = transaction.get(siteReference)
            val project = transaction.get(projectReference)

            check(site.exists()) { "This site no longer exists." }
            check(project.exists() && project.getString("status") == "active") {
                "Choose an active project."
            }

            transaction.update(siteReference, "projectId", projectId)

            site.getString("name").orEmpty().ifBlank { siteId } to
                    project.getString("name").orEmpty().ifBlank { projectId }
        }

        audit(
            "SITE_LINKED",
            "site",
            siteId,
            "Site '${names.first}' linked to project '${names.second}'",
            siteId
        )
    }

    suspend fun assignWorker(
        siteId: String,
        workerId: String
    ): Result<String> = result {
        val siteReference = sites.document(validId(siteId))
        val userReference = db.collection("users").document(validId(workerId))

        val existing = assignments
            .whereEqualTo("siteId", siteId)
            .whereEqualTo("workerId", workerId)
            .get(Source.SERVER).await()

        check(existing.documents.none {
            it.getString("endDate").isNullOrBlank()
        }) {
            "That person already has an open assignment at this site."
        }

        val reference = assignments.document()
        val startDate = today()

        val names = adminTransaction { transaction ->
            val site = transaction.get(siteReference)
            val user = transaction.get(userReference)

            check(site.exists() && site.getString("status") == "active") {
                "Activate this site before assigning people."
            }

            val projectId = site.getString("projectId").orEmpty()

            if (projectId.isNotBlank()) {
                val project = transaction.get(
                    projects.document(validId(projectId))
                )
                check(
                    project.exists() &&
                            project.getString("status") == "active"
                ) {
                    "The site's linked project must be active."
                }
            }

            check(
                user.exists() &&
                        user.getString("status") == "active" &&
                        Role.values().any {
                            it.name == user.getString("role")
                        }
            ) {
                "Choose an active user with a valid account role."
            }

            val previous = existing.documents.map {
                transaction.get(it.reference)
            }

            check(previous.none {
                it.exists() && it.getString("endDate").isNullOrBlank()
            }) {
                "That person already has an open assignment at this site."
            }

            transaction.set(
                reference,
                SiteAssignment(
                    id = reference.id,
                    siteId = siteId,
                    workerId = workerId,
                    startDate = startDate,
                    endDate = ""
                )
            )

            user.getString("fullName").orEmpty()
                .ifBlank { user.getString("email").orEmpty() }
                .ifBlank { workerId } to
                    site.getString("name").orEmpty().ifBlank { siteId }
        }

        audit(
            "ASSIGNMENT_STARTED",
            "assignment",
            reference.id,
            "${names.first} assigned to site '${names.second}'",
            siteId
        )

        reference.id
    }

    suspend fun endAssignment(assignmentId: String): Result<Unit> = result {
        val reference = assignments.document(validId(assignmentId))

        val details = adminTransaction { transaction ->
            val document = transaction.get(reference)
            check(document.exists()) { "This assignment no longer exists." }

            val assignment = assignmentFrom(document)
            val site = transaction.get(
                sites.document(validId(assignment.siteId))
            )
            val user = transaction.get(
                db.collection("users").document(validId(assignment.workerId))
            )

            if (assignment.endDate.isBlank()) {
                transaction.update(reference, "endDate", today())
            }

            Triple(
                assignment.siteId,
                user.getString("fullName").orEmpty()
                    .ifBlank { assignment.workerId },
                site.getString("name").orEmpty()
                    .ifBlank { assignment.siteId }
            )
        }

        audit(
            "ASSIGNMENT_ENDED",
            "assignment",
            assignmentId,
            "${details.second} removed from site '${details.third}'",
            details.first
        )
    }
}