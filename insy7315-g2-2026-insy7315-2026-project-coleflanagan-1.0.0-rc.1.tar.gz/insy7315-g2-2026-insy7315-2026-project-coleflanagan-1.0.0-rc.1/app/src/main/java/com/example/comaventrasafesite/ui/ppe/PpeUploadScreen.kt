package com.example.comaventrasafesite.ui.ppe

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import coil.compose.rememberAsyncImagePainter
import com.example.comaventrasafesite.repository.PpeRepository
import com.example.comaventrasafesite.ui.privacy.PrivacyPolicyLink
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun PpeUploadScreen(
    siteId: String,
    onBack: () -> Unit
) {
    val repository = remember {
        PpeRepository()
    }

    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val workerId = remember {
        FirebaseAuth.getInstance().currentUser?.uid.orEmpty()
    }

    var selectedUriString by rememberSaveable {
        mutableStateOf<String?>(null)
    }

    val selectedUri = selectedUriString?.let(
        Uri::parse
    )

    var pendingCameraUriString by rememberSaveable {
        mutableStateOf<String?>(null)
    }

    var pendingCameraFilePath by rememberSaveable {
        mutableStateOf<String?>(null)
    }

    var isSubmitting by remember {
        mutableStateOf(false)
    }

    var submitted by rememberSaveable {
        mutableStateOf(false)
    }

    var errorMessage by remember {
        mutableStateOf<String?>(null)
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        val cameraUri = pendingCameraUriString
        val cameraFilePath = pendingCameraFilePath

        if (success && cameraUri != null) {
            selectedUriString = cameraUri
            errorMessage = null
        } else {
            cameraFilePath?.let { path ->
                File(path).delete()
            }
        }

        pendingCameraUriString = null
        pendingCameraFilePath = null
    }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            selectedUriString = uri.toString()
            errorMessage = null
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
    ) {
        Surface(
            color = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(
                    horizontal = 8.dp,
                    vertical = 14.dp
                ),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack
                ) {
                    Icon(
                        imageVector = Icons.Filled.ArrowBack,
                        contentDescription = "Back"
                    )
                }

                Column {
                    Text(
                        text = "PPE Verification",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "Submit today's PPE photo",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimary.copy(
                            alpha = 0.75f
                        )
                    )
                }
            }
        }

        if (submitted) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(50.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .padding(20.dp)
                            .size(44.dp)
                    )
                }

                Text(
                    text = "Photo submitted",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(
                        top = 20.dp
                    )
                )

                Text(
                    text = "Your PPE verification is awaiting supervisor review.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(
                        top = 8.dp
                    )
                )

                Button(
                    onClick = onBack,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 24.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("Return to Safety")
                }
            }

            return@Column
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                elevation = CardDefaults.elevatedCardElevation(
                    defaultElevation = 1.dp
                )
            ) {
                if (selectedUri != null) {
                    Image(
                        painter = rememberAsyncImagePainter(
                            selectedUri
                        ),
                        contentDescription = "Selected PPE photo",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp)
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(50.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Person,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .padding(18.dp)
                                    .size(38.dp)
                            )
                        }

                        Text(
                            text = "No photo selected",
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(
                                top = 14.dp
                            )
                        )

                        Text(
                            text = "Choose a clear photo showing your required PPE.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(
                                top = 6.dp
                            )
                        )
                    }
                }
            }

            Button(
                onClick = {
                    try {
                        val cameraDirectory = File(
                            context.cacheDir,
                            "camera"
                        )

                        check(
                            cameraDirectory.isDirectory ||
                                    cameraDirectory.mkdirs()
                        ) {
                            "The camera folder could not be created."
                        }

                        val photoFile = File.createTempFile(
                            "ppe_",
                            ".jpg",
                            cameraDirectory
                        )

                        pendingCameraFilePath =
                            photoFile.absolutePath

                        val photoUri = FileProvider.getUriForFile(
                            context,
                            "${context.packageName}.fileprovider",
                            photoFile
                        )

                        pendingCameraUriString =
                            photoUri.toString()

                        errorMessage = null
                        cameraLauncher.launch(photoUri)
                    } catch (error: Exception) {
                        pendingCameraFilePath?.let { path ->
                            File(path).delete()
                        }

                        pendingCameraFilePath = null
                        pendingCameraUriString = null

                        errorMessage =
                            error.message ?: "Could not open the camera."
                    }
                },
                enabled = !isSubmitting &&
                        pendingCameraUriString == null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("Take photo")
            }

            OutlinedButton(
                onClick = {
                    try {
                        imagePicker.launch("image/*")
                    } catch (error: Exception) {
                        errorMessage =
                            error.message ?: "Could not open the image picker."
                    }
                },
                enabled = !isSubmitting &&
                        pendingCameraUriString == null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(
                    text = if (selectedUri == null) {
                        "Choose photo from gallery"
                    } else {
                        "Choose different photo from gallery"
                    }
                )
            }

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "About the AI photo check",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "Submitting sends this photo to Google Gemini " +
                                "for an advisory PPE check. The photo is saved " +
                                "in SafeSite for supervisor review. " +
                                "A supervisor makes the final decision.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    PrivacyPolicyLink()
                }
            }

            errorMessage?.let { message ->
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = message,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }

            Button(
                onClick = {
                    val photoUri = selectedUri ?: return@Button

                    isSubmitting = true
                    errorMessage = null

                    scope.launch {
                        try {
                            repository.submitPpePhoto(
                                siteId = siteId,
                                workerId = workerId,
                                photoUri = photoUri,
                                context = context
                            ).onSuccess {
                                submitted = true
                            }.onFailure { error ->
                                errorMessage =
                                    error.message ?: "Upload failed."
                            }
                        } catch (error: CancellationException) {
                            throw error
                        } catch (error: Exception) {
                            errorMessage =
                                error.message ?: "Upload failed."
                        } finally {
                            isSubmitting = false
                        }
                    }
                },
                enabled = selectedUri != null &&
                        !isSubmitting &&
                        pendingCameraUriString == null &&
                        workerId.isNotBlank() &&
                        siteId.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                if (isSubmitting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                } else {
                    Text("Submit for review")
                }
            }
        }
    }
}