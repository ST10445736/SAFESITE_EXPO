package com.example.comaventrasafesite.model

data class AppUser(
    val id: String = "",
    val fullName: String = "",
    val email: String = "",
    val role: String = "",
    val status: String = "active"
)