package com.example.comaventrasafesite.model

/**
 * An action assigned to fix a hazard (FR12). A hazard can have
 * several of these, and it can't be closed while any are still pending.
 */
data class CorrectiveAction(
    val id: String = "",
    val hazardId: String = "",
    val description: String = "",
    val assignedTo: String = "",        // who must fix it (name or UID)
    val dueDate: Long = 0L,
    val status: String = "pending",     // pending / done
    val createdBy: String = "",
    val createdAt: Long = 0L,
    val completedAt: Long? = null
)