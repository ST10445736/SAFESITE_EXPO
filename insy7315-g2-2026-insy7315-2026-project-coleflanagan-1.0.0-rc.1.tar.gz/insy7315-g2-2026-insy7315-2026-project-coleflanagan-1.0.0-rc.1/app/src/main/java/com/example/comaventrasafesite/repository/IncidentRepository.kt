package com.example.comaventrasafesite.repository

import com.example.comaventrasafesite.model.Incident
import com.example.comaventrasafesite.model.IncidentEvent
import com.example.comaventrasafesite.model.Role
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull

class IncidentRepository {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val incidents = db.collection("incidents")
    private val events = db.collection("incidentEvents")

    companion object {
        const val REPORTED = "reported"
        const val INVESTIGATING = "investigating"
        const val ACTIONS_PENDING = "actions_pending"
        const val CLOSED = "closed"

        private val incidentTypes = setOf(
            "Injury",
            "Near miss",
            "Property damage",
            "Environmental",
            "Other"
        )

        private val incidentSeverities = setOf(
            "MINOR",
            "MODERATE",
            "MAJOR",
            "CRITICAL"
        )

        private val managementRoles = setOf(
            Role.SAFETY_OFFICER.name,
            Role.ADMIN.name
        )

        fun label(status: String): String = when (status) {
            REPORTED -> "Reported"
            INVESTIGATING -> "Investigating"
            ACTIONS_PENDING -> "Actions pending"
            CLOSED -> "Closed"
            else -> status
        }
    }

    suspend fun reportIncident(
        incident: Incident
    ): Result<String> {
        return try {
            val account = auth.currentUser
                ?: error("Please sign in again.")

            require(incident.siteId.isNotBlank()) {
                "An assigned site is required."
            }

            require(incident.title.isNotBlank()) {
                "Please give the incident a title."
            }

            require(incident.title.trim().length <= 160) {
                "Keep the incident title under 160 characters."
            }

            require(incident.description.isNotBlank()) {
                "Please describe what happened."
            }

            require(incident.description.length <= 10000) {
                "Keep the description under 10,000 characters."
            }

            require(incident.location.isNotBlank()) {
                "Enter where the incident occurred."
            }

            require(incident.type in incidentTypes) {
                "Choose a valid incident type."
            }

            require(incident.severity in incidentSeverities) {
                "Choose a valid incident severity."
            }

            val now = System.currentTimeMillis()
            val incidentReference = incidents.document()
            val eventReference = events.document()

            val actorName = account.email
                ?.takeIf { it.isNotBlank() }
                ?: account.uid

            val savedIncident = incident.copy(
                assignmentId = AssignedSiteAccess.forReport(incident.siteId),
                id = incidentReference.id,
                title = incident.title.trim(),
                description = incident.description.trim(),
                location = incident.location.trim(),
                injuredPerson = incident.injuredPerson.trim(),
                witnesses = incident.witnesses.trim(),
                reportedBy = account.uid,
                reporterName = actorName,
                status = REPORTED,
                investigatorName = "",
                rootCause = "",
                findings = "",
                actionsRequired = "",
                closingNote = "",
                createdAt = now,
                closedAt = null,
                occurredAt = incident.occurredAt
                    .takeIf { it > 0L } ?: now
            )

            val initialEvent = IncidentEvent(
                id = eventReference.id,
                incidentId = incidentReference.id,
                fromStatus = "",
                toStatus = REPORTED,
                note = "Incident reported",
                byUserId = account.uid,
                byName = actorName,
                at = now
            )

            db.runBatch { batch ->
                batch.set(
                    incidentReference,
                    savedIncident
                )

                batch.set(
                    eventReference,
                    initialEvent
                )
            }.await()

            logAudit(
                incidentId = incidentReference.id,
                siteId = savedIncident.siteId,
                status = REPORTED,
                summary = "Incident reported: ${savedIncident.title}"
            )

            Result.success(incidentReference.id)
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Result.failure(error)
        }
    }

    suspend fun getIncidentsForSite(
        siteId: String
    ): List<Incident> {
        require(siteId.isNotBlank()) {
            "An assigned site is required."
        }

        val snapshot = incidents
            .whereEqualTo("siteId", siteId)
            .get(Source.SERVER)
            .await()

        return snapshot.documents
            .mapNotNull { document ->
                document.toObject(Incident::class.java)
                    ?.copy(id = document.id)
            }
            .sortedByDescending {
                it.createdAt
            }
    }

    suspend fun getIncident(
        incidentId: String
    ): Incident? {
        require(incidentId.isNotBlank()) {
            "The incident could not be identified."
        }

        val document = incidents
            .document(incidentId)
            .get(Source.SERVER)
            .await()

        return document.toObject(Incident::class.java)
            ?.copy(id = document.id)
    }

    suspend fun getEvents(
        incidentId: String
    ): List<IncidentEvent> {
        require(incidentId.isNotBlank()) {
            "The incident could not be identified."
        }

        val snapshot = events
            .whereEqualTo("incidentId", incidentId)
            .get(Source.SERVER)
            .await()

        return snapshot.documents
            .mapNotNull { document ->
                document.toObject(IncidentEvent::class.java)
                    ?.copy(id = document.id)
            }
            .sortedBy {
                it.at
            }
    }

    suspend fun canManageIncidents(): Boolean {
        val account = auth.currentUser
            ?: error("Please sign in again.")

        val profile = db.collection("users")
            .document(account.uid)
            .get(Source.SERVER)
            .await()

        check(
            profile.exists() &&
                    profile.getString("status") == "active"
        ) {
            "Your account is unavailable or inactive. Please sign in again."
        }

        check(auth.currentUser?.uid == account.uid) {
            "Your signed-in account has changed. Please sign in again."
        }

        return profile.getString("role") in managementRoles
    }

    suspend fun startInvestigation(
        incidentId: String,
        investigatorName: String,
        byUserId: String
    ): Result<Unit> {
        val cleanName = investigatorName.trim()

        if (cleanName.isBlank()) {
            return Result.failure(
                IllegalArgumentException(
                    "Enter the investigator's name."
                )
            )
        }

        if (cleanName.length > 200) {
            return Result.failure(
                IllegalArgumentException(
                    "Keep the investigator's name under 200 characters."
                )
            )
        }

        return moveStatus(
            incidentId = incidentId,
            expected = REPORTED,
            next = INVESTIGATING,
            updates = mapOf(
                "investigatorName" to cleanName
            ),
            note = "Investigation started. Investigator: $cleanName",
            byUserId = byUserId,
            byName = cleanName
        )
    }

    suspend fun submitFindings(
        incidentId: String,
        rootCause: String,
        findings: String,
        actionsRequired: String,
        byUserId: String,
        byName: String
    ): Result<Unit> {
        if (rootCause.isBlank()) {
            return Result.failure(
                IllegalArgumentException(
                    "Root cause is required."
                )
            )
        }

        if (actionsRequired.isBlank()) {
            return Result.failure(
                IllegalArgumentException(
                    "List the actions required."
                )
            )
        }

        if (
            rootCause.length > 5000 ||
            findings.length > 5000 ||
            actionsRequired.length > 5000
        ) {
            return Result.failure(
                IllegalArgumentException(
                    "Keep each findings field under 5,000 characters."
                )
            )
        }

        return moveStatus(
            incidentId = incidentId,
            expected = INVESTIGATING,
            next = ACTIONS_PENDING,
            updates = mapOf(
                "rootCause" to rootCause.trim(),
                "findings" to findings.trim(),
                "actionsRequired" to actionsRequired.trim()
            ),
            note = "Findings recorded. Root cause: ${rootCause.trim()}",
            byUserId = byUserId,
            byName = byName
        )
    }

    suspend fun closeIncident(
        incidentId: String,
        closingNote: String,
        byUserId: String,
        byName: String
    ): Result<Unit> {
        if (closingNote.isBlank()) {
            return Result.failure(
                IllegalArgumentException(
                    "Add a closing note confirming actions were completed."
                )
            )
        }

        if (closingNote.length > 5000) {
            return Result.failure(
                IllegalArgumentException(
                    "Keep the closing note under 5,000 characters."
                )
            )
        }

        return moveStatus(
            incidentId = incidentId,
            expected = ACTIONS_PENDING,
            next = CLOSED,
            updates = mapOf(
                "closingNote" to closingNote.trim(),
                "closedAt" to System.currentTimeMillis()
            ),
            note = "Closed: ${closingNote.trim()}",
            byUserId = byUserId,
            byName = byName
        )
    }

    private suspend fun moveStatus(
        incidentId: String,
        expected: String,
        next: String,
        updates: Map<String, Any>,
        note: String,
        byUserId: String,
        byName: String
    ): Result<Unit> {
        return try {
            require(incidentId.isNotBlank()) {
                "The incident could not be identified."
            }

            val account = auth.currentUser
                ?: error("Please sign in again.")

            check(account.uid == byUserId) {
                "Your signed-in account has changed. Please sign in again."
            }

            val incidentReference = incidents.document(incidentId)
            val eventReference = events.document()
            val profileReference = db.collection("users")
                .document(account.uid)

            val now = System.currentTimeMillis()

            val savedIncident = db.runTransaction { transaction ->
                check(auth.currentUser?.uid == account.uid) {
                    "Your signed-in account has changed."
                }

                val profile = transaction.get(profileReference)
                val document = transaction.get(incidentReference)

                check(
                    profile.exists() &&
                            profile.getString("status") == "active" &&
                            profile.getString("role") in managementRoles
                ) {
                    "An active Safety Officer or Administrator account " +
                            "is required to manage incidents."
                }

                val current = document
                    .toObject(Incident::class.java)
                    ?: error("Incident not found.")

                check(current.status == expected) {
                    "This incident has changed. Refresh before continuing."
                }

                val actorName = profile.getString("fullName")
                    ?.takeIf { it.isNotBlank() }
                    ?: account.email
                    ?: byName.ifBlank {
                        account.uid
                    }

                transaction.update(
                    incidentReference,
                    updates + ("status" to next)
                )

                transaction.set(
                    eventReference,
                    IncidentEvent(
                        id = eventReference.id,
                        incidentId = incidentId,
                        fromStatus = expected,
                        toStatus = next,
                        note = note,
                        byUserId = account.uid,
                        byName = actorName,
                        at = now
                    )
                )

                current
            }.await()

            logAudit(
                incidentId = incidentId,
                siteId = savedIncident.siteId,
                status = next,
                summary = "Incident '${savedIncident.title}' → " +
                        "${label(next)}: $note"
            )

            Result.success(Unit)
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Result.failure(error)
        }
    }

    private suspend fun logAudit(
        incidentId: String,
        siteId: String,
        status: String,
        summary: String
    ) {
        // The incident and its timeline have already committed together.
        // This optional general audit entry must not hold the UI indefinitely.
        withTimeoutOrNull(3_000L) {
            AuditLogger.log(
                action = "INCIDENT_${status.uppercase()}",
                entityType = "incident",
                entityId = incidentId,
                summary = summary,
                siteId = siteId
            )
        }
    }
}