package com.example.comaventrasafesite

import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory

internal object AppCheckSetup {

    fun install(
        app: FirebaseApp = FirebaseApp.getInstance()
    ) {
        val appCheck = FirebaseAppCheck.getInstance(app)

        appCheck.installAppCheckProviderFactory(
            DebugAppCheckProviderFactory.getInstance()
        )

        appCheck.getAppCheckToken(false)
            .addOnSuccessListener {
                Log.d(
                    "SafeSiteAppCheck",
                    "App Check token obtained for ${app.name}."
                )
            }
            .addOnFailureListener { error ->
                Log.e(
                    "SafeSiteAppCheck",
                    "App Check token could not be obtained for ${app.name}.",
                    error
                )
            }
    }
}