package com.example.comaventrasafesite

import com.example.comaventrasafesite.util.CsvExport
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class CsvExportTest {

    @Test
    fun emptyCellIsQuoted() {
        assertEquals("\"\"", CsvExport.cell(""))
    }

    @Test
    fun ordinaryTextIsPreserved() {
        assertEquals("\"Site inspection\"", CsvExport.cell("Site inspection"))
    }

    @Test
    fun commaRemainsInsideQuotedCell() {
        assertEquals("\"Boots, gloves\"", CsvExport.cell("Boots, gloves"))
    }

    @Test
    fun quotationMarksAreEscaped() {
        assertEquals("\"He said \"\"safe\"\"\"", CsvExport.cell("He said \"safe\""))
    }

    @Test
    fun embeddedNewlineIsPreserved() {
        assertEquals("\"Line one\nLine two\"", CsvExport.cell("Line one\nLine two"))
    }

    @Test
    fun equalsFormulaIsNeutralised() {
        assertEquals("\"'=1+1\"", CsvExport.cell("=1+1"))
    }

    @Test
    fun plusFormulaIsNeutralised() {
        assertEquals("\"'+1+1\"", CsvExport.cell("+1+1"))
    }

    @Test
    fun minusFormulaIsNeutralised() {
        assertEquals("\"'-1+1\"", CsvExport.cell("-1+1"))
    }

    @Test
    fun atFormulaIsNeutralised() {
        assertEquals("\"'@SUM(A1:A2)\"", CsvExport.cell("@SUM(A1:A2)"))
    }

    @Test
    fun whitespaceCannotHideFormula() {
        assertEquals("\"'  =1+1\"", CsvExport.cell("  =1+1"))
    }

    @Test
    fun leadingTabIsNeutralised() {
        assertEquals("\"'\tText\"", CsvExport.cell("\tText"))
    }

    @Test
    fun leadingCarriageReturnIsNeutralised() {
        assertEquals("\"'\rText\"", CsvExport.cell("\rText"))
    }

    @Test
    fun leadingLineFeedIsNeutralised() {
        assertEquals("\"'\nText\"", CsvExport.cell("\nText"))
    }

    @Test
    fun incorrectlySizedRowIsRejected() {
        assertThrows(IllegalArgumentException::class.java) {
            CsvExport.document(
                header = listOf("Name", "Status"),
                rows = listOf(listOf("Worker"))
            )
        }
    }

    @Test
    fun documentUsesBomCrLfAndProtectsHeadersAndRows() {
        assertEquals(
            "\uFEFF\"'=Header\",\"Status\"\r\n" +
                    "\"'@SUM(A1:A2)\",\"Complete\"\r\n",
            CsvExport.document(
                header = listOf("=Header", "Status"),
                rows = listOf(listOf("@SUM(A1:A2)", "Complete"))
            )
        )
    }
}