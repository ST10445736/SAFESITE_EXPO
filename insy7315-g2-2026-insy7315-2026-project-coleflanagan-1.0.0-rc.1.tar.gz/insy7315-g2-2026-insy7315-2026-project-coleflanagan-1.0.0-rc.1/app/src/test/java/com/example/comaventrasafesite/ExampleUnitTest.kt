package com.example.comaventrasafesite

import com.example.comaventrasafesite.auth.AccountAccess
import com.example.comaventrasafesite.model.Role
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class AccountAccessTest {

    @Test
    fun activeWorkerIsAccepted() {
        assertEquals(
            Role.WORKER,
            AccountAccess.requireRole(true, "active", "WORKER")
        )
    }

    @Test
    fun activeSupervisorIsAccepted() {
        assertEquals(
            Role.SUPERVISOR,
            AccountAccess.requireRole(true, "active", "SUPERVISOR")
        )
    }

    @Test
    fun activeSafetyOfficerIsAccepted() {
        assertEquals(
            Role.SAFETY_OFFICER,
            AccountAccess.requireRole(true, "active", "SAFETY_OFFICER")
        )
    }

    @Test
    fun activeAdminIsAccepted() {
        assertEquals(
            Role.ADMIN,
            AccountAccess.requireRole(true, "active", "ADMIN")
        )
    }

    @Test
    fun missingProfileIsRejected() {
        assertThrows(IllegalStateException::class.java) {
            AccountAccess.requireRole(false, "active", "ADMIN")
        }
    }

    @Test
    fun inactiveAccountIsRejected() {
        assertThrows(IllegalStateException::class.java) {
            AccountAccess.requireRole(true, "inactive", "WORKER")
        }
    }

    @Test
    fun missingStatusIsRejected() {
        assertThrows(IllegalStateException::class.java) {
            AccountAccess.requireRole(true, null, "WORKER")
        }
    }

    @Test
    fun unknownRoleIsRejected() {
        assertThrows(IllegalStateException::class.java) {
            AccountAccess.requireRole(true, "active", "OWNER")
        }
    }

    @Test
    fun missingRoleIsRejected() {
        assertThrows(IllegalStateException::class.java) {
            AccountAccess.requireRole(true, "active", null)
        }
    }

    @Test
    fun incorrectlyCasedRoleIsRejected() {
        assertThrows(IllegalStateException::class.java) {
            AccountAccess.requireRole(true, "active", "admin")
        }
    }
}